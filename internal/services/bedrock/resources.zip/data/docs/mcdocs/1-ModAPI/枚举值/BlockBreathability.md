 BlockBreathability
==========

class in mod.common.minecraftEnum

* 描述

  方块的可呼吸性

```
class BlockBreathability(object):
	Solid = 0	# 固体
	Air = 1		# 空气

```