 API索引表
==========

---

 物理
----------

* [物理](#%E7%89%A9%E7%90%86-2)

 通用
----------

* [Component](#component)
* [System](#system)
* [事件](#%E4%BA%8B%E4%BB%B6)
* [本地设备](#%E6%9C%AC%E5%9C%B0%E8%AE%BE%E5%A4%87)
* [本地存储](#%E6%9C%AC%E5%9C%B0%E5%AD%98%E5%82%A8)
* [数学](#%E6%95%B0%E5%AD%A6)
* [工具](#%E5%B7%A5%E5%85%B7)
* [调试](#%E8%B0%83%E8%AF%95)

 世界
----------

* [地图](#%E5%9C%B0%E5%9B%BE)
* [实体管理](#%E5%AE%9E%E4%BD%93%E7%AE%A1%E7%90%86)
* [方块管理](#%E6%96%B9%E5%9D%97%E7%AE%A1%E7%90%86)
* [生物生成](#%E7%94%9F%E7%89%A9%E7%94%9F%E6%88%90)
* [配方](#%E9%85%8D%E6%96%B9)
* [方块组合](#%E6%96%B9%E5%9D%97%E7%BB%84%E5%90%88)
* [渲染](#%E6%B8%B2%E6%9F%93)
* [时间](#%E6%97%B6%E9%97%B4)
* [天气](#%E5%A4%A9%E6%B0%94)
* [游戏规则](#%E6%B8%B8%E6%88%8F%E8%A7%84%E5%88%99)
* [自定义数据](#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%95%B0%E6%8D%AE)
* [指令](#%E6%8C%87%E4%BB%A4)
* [消息](#%E6%B6%88%E6%81%AF)
* [记分板](#%E8%AE%B0%E5%88%86%E6%9D%BF)
* [行为](#%E8%A1%8C%E4%B8%BA)

 实体
----------

* [实体类型](#%E5%AE%9E%E4%BD%93%E7%B1%BB%E5%9E%8B)
* [附加值](#%E9%99%84%E5%8A%A0%E5%80%BC)
* [属性](#%E5%B1%9E%E6%80%A7)
* [行为](#%E8%A1%8C%E4%B8%BA1)
* [状态效果](#%E7%8A%B6%E6%80%81%E6%95%88%E6%9E%9C)
* [渲染](#%E6%B8%B2%E6%9F%931)
* [背包](#%E8%83%8C%E5%8C%85)
* [自定义属性](#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%B1%9E%E6%80%A7)
* [自定义数据](#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%95%B0%E6%8D%AE1)
* [molang](#molang)
* [标签](#%E6%A0%87%E7%AD%BE)
* [抛射物](#%E6%8A%9B%E5%B0%84%E7%89%A9)
* [经验球](#%E7%BB%8F%E9%AA%8C%E7%90%83)
* [官方伙伴](#%E5%AE%98%E6%96%B9%E4%BC%99%E4%BC%B4)
* [官方聊天扩展](#%E5%AE%98%E6%96%B9%E8%81%8A%E5%A4%A9%E6%89%A9%E5%B1%95)
* [魔法指令](#%E9%AD%94%E6%B3%95%E6%8C%87%E4%BB%A4)

 玩家
----------

* [属性](#%E5%B1%9E%E6%80%A71)
* [行为](#%E8%A1%8C%E4%B8%BA2)
* [渲染](#%E6%B8%B2%E6%9F%932)
* [背包](#%E8%83%8C%E5%8C%851)
* [摄像机](#%E6%91%84%E5%83%8F%E6%9C%BA)
* [动画](#%E5%8A%A8%E7%94%BB)
* [游戏模式](#%E6%B8%B8%E6%88%8F%E6%A8%A1%E5%BC%8F)
* [权限](#%E6%9D%83%E9%99%90)
* [导航](#%E5%AF%BC%E8%88%AA)

 方块
----------

* [方块状态与附加值](#%E6%96%B9%E5%9D%97%E7%8A%B6%E6%80%81%E4%B8%8E%E9%99%84%E5%8A%A0%E5%80%BC)
* [属性](#%E5%B1%9E%E6%80%A72)
* [方块实体](#%E6%96%B9%E5%9D%97%E5%AE%9E%E4%BD%93)
* [方块几何体模型](#%E6%96%B9%E5%9D%97%E5%87%A0%E4%BD%95%E4%BD%93%E6%A8%A1%E5%9E%8B)
* [方块调色板](#%E6%96%B9%E5%9D%97%E8%B0%83%E8%89%B2%E6%9D%BF)
* [渲染](#%E6%B8%B2%E6%9F%933)
* [容器](#%E5%AE%B9%E5%99%A8)
* [红石](#%E7%BA%A2%E7%9F%B3)
* [告示牌](#%E5%91%8A%E7%A4%BA%E7%89%8C)
* [床](#%E5%BA%8A)

 物品
----------

* [物品](#%E7%89%A9%E5%93%81-2)

 特效
----------

* [通用](#%E9%80%9A%E7%94%A81)
* [文字面板](#%E6%96%87%E5%AD%97%E9%9D%A2%E6%9D%BF)
* [序列帧](#%E5%BA%8F%E5%88%97%E5%B8%A7)
* [粒子](#%E7%B2%92%E5%AD%90)
* [模型特效](#%E6%A8%A1%E5%9E%8B%E7%89%B9%E6%95%88)
* [微软粒子](#%E5%BE%AE%E8%BD%AF%E7%B2%92%E5%AD%90)

 模型
----------

* [模型](#%E6%A8%A1%E5%9E%8B-2)

 原生UI
----------

* [原生UI](#%E5%8E%9F%E7%94%9Fui-2)

 自定义UI
----------

* [通用](#%E9%80%9A%E7%94%A82)
* [自定义书本](#%E8%87%AA%E5%AE%9A%E4%B9%89%E4%B9%A6%E6%9C%AC)
* [自定义成就系统](#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%88%90%E5%B0%B1%E7%B3%BB%E7%BB%9F)
* [UI界面](#ui%E7%95%8C%E9%9D%A2)
* [UI控件](#ui%E6%8E%A7%E4%BB%B6)
* [通用设置](#%E9%80%9A%E7%94%A8%E8%AE%BE%E7%BD%AE)

 音效
----------

* [音效](#%E9%9F%B3%E6%95%88-2)

 控制
----------

* [控制](#%E6%8E%A7%E5%88%B6-2)

 游戏设置
----------

* [游戏设置](#%E6%B8%B8%E6%88%8F%E8%AE%BE%E7%BD%AE-2)

 虚拟世界
----------

* [世界](#%E4%B8%96%E7%95%8C1)
* [相机](#%E7%9B%B8%E6%9C%BA)
* [模型](#%E6%A8%A1%E5%9E%8B1)
* [其它对象](#%E5%85%B6%E5%AE%83%E5%AF%B9%E8%B1%A1)

 后处理
----------

* [渐晕](#%E6%B8%90%E6%99%95)
* [模糊](#%E6%A8%A1%E7%B3%8A)
* [色彩](#%E8%89%B2%E5%BD%A9)
* [镜头效果](#%E9%95%9C%E5%A4%B4%E6%95%88%E6%9E%9C)
* [自定义](#%E8%87%AA%E5%AE%9A%E4%B9%89)

 联机大厅
----------

* [联机大厅](#%E8%81%94%E6%9C%BA%E5%A4%A7%E5%8E%85-2)

 成就
----------

* [成就](#%E6%88%90%E5%B0%B1-2)

 商城
----------

* [商城](#%E5%95%86%E5%9F%8E-2)

 山头服务器
----------

* [山头服务器](#%E5%B1%B1%E5%A4%B4%E6%9C%8D%E5%8A%A1%E5%99%A8-2)

 渲染
----------

* [渲染](#%E6%B8%B2%E6%9F%93-2)

####  物理 ####

|                                                 接口                                                 |   |                         描述                         |
|----------------------------------------------------------------------------------------------------|---|----------------------------------------------------|
|          [AddBoxGeometry](./1-ModAPI/接口/物理.md#addboxgeometry)          |服务端|                   给自定义刚体创建盒形碰撞体                    |
|           [AddBoxTrigger](./1-ModAPI/接口/物理.md#addboxtrigger)           |服务端|                   给自定义刚体创建盒子形触发器                   |
|      [AddCapsuleGeometry](./1-ModAPI/接口/物理.md#addcapsulegeometry)      |服务端|                   给自定义刚体创建胶囊形碰撞体                   |
|                [AddForce](./1-ModAPI/接口/物理.md#addforce)                |服务端|               对自定义刚体的质心添加力，对运动学刚体无效                |
|           [AddForceAtPos](./1-ModAPI/接口/物理.md#addforceatpos)           |服务端|              对自定义刚体的指定位置添加力，对运动学刚体无效               |
|      [AddForceAtPosLocal](./1-ModAPI/接口/物理.md#addforceatposlocal)      |服务端|              对自定义刚体的指定位置添加力，对运动学刚体无效               |
|       [AddSphereGeometry](./1-ModAPI/接口/物理.md#addspheregeometry)       |服务端|                   给自定义刚体创建球形碰撞体                    |
|           [CreatePxActor](./1-ModAPI/接口/物理.md#createpxactor)           |服务端|                     给实体创建自定义刚体                     |
|           [GetQuaternion](./1-ModAPI/接口/物理.md#getquaternion)           |服务端|                   获取自定义刚体的四元数旋转                    |
|           [GetQuaternion](./1-ModAPI/接口/物理.md#getquaternion)           |客户端|                   获取自定义刚体的四元数旋转                    |
|                 [Raycast](./1-ModAPI/接口/物理.md#raycast)                 |服务端|           射线检测，获取与射线相交的碰撞体。目前仅支持获取自定义刚体            |
|                 [Raycast](./1-ModAPI/接口/物理.md#raycast)                 |客户端|           射线检测，获取与射线相交的碰撞体。目前仅支持获取自定义刚体            |
|            [SetActorFlag](./1-ModAPI/接口/物理.md#setactorflag)            |服务端|                    设置物理实体的行为开关                     |
|           [SetGlobalPose](./1-ModAPI/接口/物理.md#setglobalpose)           |服务端|                  设置自定义刚体的变换（直接瞬移）                  |
|      [SetKinematicTarget](./1-ModAPI/接口/物理.md#setkinematictarget)      |服务端|设置运动学刚体的目标变换，仅对开启了PxRigidBodyFlag.eKINEMATIC的自定义刚体生效|
|        [SetRigidBodyFlag](./1-ModAPI/接口/物理.md#setrigidbodyflag)        |服务端|                    设置自定义刚体的行为开关                    |
|[SetRigidDynamicLockFlags](./1-ModAPI/接口/物理.md#setrigiddynamiclockflags)|服务端|                     设置自定义刚体的约束                     |

####  Component ####

|                                                  接口                                                  |   |                       描述                        |
|------------------------------------------------------------------------------------------------------|---|-------------------------------------------------|
|     [CreateComponent](./1-ModAPI/接口/通用/Component.md#createcomponent)     |服务端|                   给实体创建服务端组件                    |
|     [CreateComponent](./1-ModAPI/接口/通用/Component.md#createcomponent)     |客户端|                   给实体创建客户端组件                    |
|    [DestroyComponent](./1-ModAPI/接口/通用/Component.md#destroycomponent)    |服务端|                   删除实体的服务端组件                    |
|    [DestroyComponent](./1-ModAPI/接口/通用/Component.md#destroycomponent)    |客户端|                   删除实体的客户端组件                    |
|        [GetComponent](./1-ModAPI/接口/通用/Component.md#getcomponent)        |服务端|获取实体的服务端组件。一般用来判断某个组件是否创建过，其他情况请使用CreateComponent|
|        [GetComponent](./1-ModAPI/接口/通用/Component.md#getcomponent)        |客户端|获取实体的客户端组件。一般用来判断某个组件是否创建过，其他情况请使用CreateComponent|
|     [GetComponentCls](./1-ModAPI/接口/通用/Component.md#getcomponentcls)     |服务端|  用于获取服务器component基类。实现新的component时，需要继承该接口返回的类  |
|     [GetComponentCls](./1-ModAPI/接口/通用/Component.md#getcomponentcls)     |客户端|  用于获取客户端component基类。实现新的component时，需要继承该接口返回的类  |
|[GetEngineCompFactory](./1-ModAPI/接口/通用/Component.md#getenginecompfactory)|服务端|           获取引擎组件的工厂，通过工厂可以创建服务端的引擎组件            |
|[GetEngineCompFactory](./1-ModAPI/接口/通用/Component.md#getenginecompfactory)|客户端|           获取引擎组件的工厂，通过工厂可以创建客户端的引擎组件            |
|   [RegisterComponent](./1-ModAPI/接口/通用/Component.md#registercomponent)   |服务端|                   用于将组件注册到引擎中                   |
|   [RegisterComponent](./1-ModAPI/接口/通用/Component.md#registercomponent)   |客户端|                   用于将组件注册到引擎中                   |

####  System ####

|                                              接口                                               |   |                                       描述                                       |
|-----------------------------------------------------------------------------------------------|---|--------------------------------------------------------------------------------|
|[GetClientSystemCls](./1-ModAPI/接口/通用/System.md#getclientsystemcls)|客户端|                    用于获取客户端system基类。实现新的system时，需要继承该接口返回的类                     |
|[GetServerSystemCls](./1-ModAPI/接口/通用/System.md#getserversystemcls)|服务端|                    用于获取服务器system基类。实现新的system时，需要继承该接口返回的类                     |
|         [GetSystem](./1-ModAPI/接口/通用/System.md#getsystem)         |服务端|                                    获取已注册的系统                                    |
|         [GetSystem](./1-ModAPI/接口/通用/System.md#getsystem)         |客户端|                                   用于获取其他系统实例                                   |
|    [RegisterSystem](./1-ModAPI/接口/通用/System.md#registersystem)    |服务端|用于将系统注册到引擎中，引擎会创建一个该系统的实例，并在退出游戏时回收。系统可以执行我们引擎赋予的基本逻辑，例如监听事件、执行Tick函数、与客户端进行通讯等。|
|    [RegisterSystem](./1-ModAPI/接口/通用/System.md#registersystem)    |客户端|用于将系统注册到引擎中，引擎会创建一个该系统的实例，并在退出游戏时回收。系统可以执行我们引擎赋予的基本逻辑，例如监听事件、执行Tick函数、与服务端进行通讯等。|

####  事件 ####

|                                              接口                                               |             |                                                                                                                               描述                                                                                                                               |
|-----------------------------------------------------------------------------------------------|-------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|      [BroadcastEvent](./1-ModAPI/接口/通用/事件.md#broadcastevent)      |服务端  <br/>客户端|                                                                                                本地广播事件，客户端system广播的事件仅客户端system能监听，服务器system广播的事件仅服务端system能监听。                                                                                                 |
|[BroadcastToAllClient](./1-ModAPI/接口/通用/事件.md#broadcasttoallclient)|     服务端     |                                                                                                                         服务器广播事件到所有客户端                                                                                                                          |
|     [CreateEventData](./1-ModAPI/接口/通用/事件.md#createeventdata)     |服务端  <br/>客户端|                                                                                      创建自定义事件的数据，eventData用于发送事件。创建的eventData可以理解为一个dict，可以嵌套赋值dict,list和基本数据类型，但不支持tuple                                                                                       |
|  [GetEngineNamespace](./1-ModAPI/接口/通用/事件.md#getenginenamespace)  |     服务端     |                                                                                                         获取引擎事件的命名空间。监听引擎事件时，namespace传该接口返回的namespace                                                                                                          |
|  [GetEngineNamespace](./1-ModAPI/接口/通用/事件.md#getenginenamespace)  |     客户端     |                                                                                                         获取引擎事件的命名空间。监听引擎事件时，namespace传该接口返回的namespace                                                                                                          |
| [GetEngineSystemName](./1-ModAPI/接口/通用/事件.md#getenginesystemname) |     服务端     |                                                                                                          获取引擎系统名。监听引擎事件时，systemName传该接口返回的systemName                                                                                                           |
| [GetEngineSystemName](./1-ModAPI/接口/通用/事件.md#getenginesystemname) |     客户端     |                                                                                                          获取引擎系统名。监听引擎事件时，systemName传该接口返回的systemName                                                                                                           |
|      [ListenForEvent](./1-ModAPI/接口/通用/事件.md#listenforevent)      |服务端  <br/>客户端|                                                                     注册监听某个系统抛出的事件。若监听引擎事件时，namespace和systemName分别为GetEngineNamespace()和GetEngineSystemName()。具体每个事件的详细事件data可以参考"事件"分类下的内容                                                                     |
|      [NotifyToClient](./1-ModAPI/接口/通用/事件.md#notifytoclient)      |     服务端     |                                                                                                                         服务器发送事件到指定客户端                                                                                                                          |
|[NotifyToMultiClients](./1-ModAPI/接口/通用/事件.md#notifytomulticlients)|     服务端     |                                                                                                         服务器发送事件到指定一批客户端，相比于在for循环内使用NotifyToClient性能更好                                                                                                         |
|      [NotifyToServer](./1-ModAPI/接口/通用/事件.md#notifytoserver)      |     客户端     |                                                                                                                          客户端发送事件到服务器                                                                                                                           |
|   [UnListenAllEvents](./1-ModAPI/接口/通用/事件.md#unlistenallevents)   |服务端  <br/>客户端|                                                                                                                    反注册监听某个系统抛出的所有事件，即不再监听。                                                                                                                     |
|    [UnListenForEvent](./1-ModAPI/接口/通用/事件.md#unlistenforevent)    |服务端  <br/>客户端|反注册监听某个系统抛出的事件，即不再监听。若是引擎事件，则namespace和systemName分别为[GetEngineNamespace](./1-ModAPI/接口/通用/事件.md#getenginenamespace)和[GetEngineSystemName](./1-ModAPI/接口/通用/事件.md#getenginesystemname)。与ListenForEvent对应。|

####  本地设备 ####

|                                              接口                                               |   |          描述           |
|-----------------------------------------------------------------------------------------------|---|-----------------------|
|   [GetEngineVersion](./1-ModAPI/接口/通用/本地设备.md#getengineversion)   |客户端|      获取游戏版本-客户端。      |
|              [GetIP](./1-ModAPI/接口/通用/本地设备.md#getip)              |客户端|      获取本地玩家的ip地址      |
|[GetMinecraftVersion](./1-ModAPI/接口/通用/本地设备.md#getminecraftversion)|服务端|  获取Minecraft版本-服务端。   |
|[GetMinecraftVersion](./1-ModAPI/接口/通用/本地设备.md#getminecraftversion)|客户端|  获取Minecraft版本-客户端。   |
|        [GetPlatform](./1-ModAPI/接口/通用/本地设备.md#getplatform)        |服务端|       获取脚本运行的平台       |
|        [GetPlatform](./1-ModAPI/接口/通用/本地设备.md#getplatform)        |客户端|       获取脚本运行的平台       |
|         [IsInApollo](./1-ModAPI/接口/通用/本地设备.md#isinapollo)         |服务端|返回当前游戏Mod是否运行在Apollo网络服|
|         [IsInServer](./1-ModAPI/接口/通用/本地设备.md#isinserver)         |服务端|   获取当前游戏是否跑在服务器环境下    |

####  本地存储 ####

|                                        接口                                         |   |      描述      |
|-----------------------------------------------------------------------------------|---|--------------|
|[GetConfigData](./1-ModAPI/接口/通用/本地存储.md#getconfigdata)|客户端|获取本地配置文件中存储的数据|
|[SetConfigData](./1-ModAPI/接口/通用/本地存储.md#setconfigdata)|客户端|以本地配置文件的方式存储数据|

####  数学 ####

|                                              接口                                               |   |             描述              |
|-----------------------------------------------------------------------------------------------|---|-----------------------------|
|       [GetDirFromRot](./1-ModAPI/接口/通用/数学.md#getdirfromrot)       |服务端|         通过旋转角度获取朝向          |
|       [GetDirFromRot](./1-ModAPI/接口/通用/数学.md#getdirfromrot)       |客户端|         通过旋转角度获取朝向          |
|           [GetIntPos](./1-ModAPI/接口/通用/数学.md#getintpos)           |服务端|获取坐标所在方块的位置，即浮点数坐标向下取整后的整数坐标。|
|           [GetIntPos](./1-ModAPI/接口/通用/数学.md#getintpos)           |客户端|获取坐标所在方块的位置，即浮点数坐标向下取整后的整数坐标。|
|[GetLocalPosFromWorld](./1-ModAPI/接口/通用/数学.md#getlocalposfromworld)|服务端|     获取基于实体的世界坐标对应的局部坐标      |
|[GetLocalPosFromWorld](./1-ModAPI/接口/通用/数学.md#getlocalposfromworld)|客户端|     获取基于实体的世界坐标对应的局部坐标      |
|       [GetRotFromDir](./1-ModAPI/接口/通用/数学.md#getrotfromdir)       |服务端|         通过朝向获取旋转角度          |
|       [GetRotFromDir](./1-ModAPI/接口/通用/数学.md#getrotfromdir)       |客户端|         通过朝向获取旋转角度          |
|[GetWorldPosFromLocal](./1-ModAPI/接口/通用/数学.md#getworldposfromlocal)|服务端|     获取基于实体的局部坐标对应的世界坐标      |
|[GetWorldPosFromLocal](./1-ModAPI/接口/通用/数学.md#getworldposfromlocal)|客户端|     获取基于实体的局部坐标对应的世界坐标      |

####  工具 ####

|                                             接口                                              |   |                                                      描述                                                      |
|---------------------------------------------------------------------------------------------|---|--------------------------------------------------------------------------------------------------------------|
|   [AddRepeatedTimer](./1-ModAPI/接口/通用/工具.md#addrepeatedtimer)   |服务端|                                               添加服务端触发的定时器，重复执行                                               |
|   [AddRepeatedTimer](./1-ModAPI/接口/通用/工具.md#addrepeatedtimer)   |客户端|                                               添加客户端触发的定时器，重复执行                                               |
|           [AddTimer](./1-ModAPI/接口/通用/工具.md#addtimer)           |服务端|                                               添加服务端触发的定时器，非重复                                                |
|           [AddTimer](./1-ModAPI/接口/通用/工具.md#addtimer)           |客户端|                                               添加客户端触发的定时器，非重复                                                |
|        [CancelTimer](./1-ModAPI/接口/通用/工具.md#canceltimer)        |服务端|                                                    取消定时器                                                     |
|        [CancelTimer](./1-ModAPI/接口/通用/工具.md#canceltimer)        |客户端|                                                    取消定时器                                                     |
|     [CheckNameValid](./1-ModAPI/接口/通用/工具.md#checknamevalid)     |服务端|                                               检查昵称是否合法，即不包含敏感词                                               |
|     [CheckNameValid](./1-ModAPI/接口/通用/工具.md#checknamevalid)     |客户端|                                               检查昵称是否合法，即不包含敏感词                                               |
|    [CheckWordsValid](./1-ModAPI/接口/通用/工具.md#checkwordsvalid)    |服务端|                                               检查语句是否合法，即不包含敏感词                                               |
|    [CheckWordsValid](./1-ModAPI/接口/通用/工具.md#checkwordsvalid)    |客户端|                                               检查语句是否合法，即不包含敏感词                                               |
|         [GetChinese](./1-ModAPI/接口/通用/工具.md#getchinese)         |服务端|获取langStr对应的中文，可参考PC开发包中\\handheld\\localization\\handheld\\data\\resource\_packs\\vanilla\\texts\\zh\_CN.lang|
|         [GetChinese](./1-ModAPI/接口/通用/工具.md#getchinese)         |客户端|获取langStr对应的中文，可参考PC开发包中\\handheld\\localization\\handheld\\data\\resource\_packs\\vanilla\\texts\\zh\_CN.lang|
|[GetClipboardContent](./1-ModAPI/接口/通用/工具.md#getclipboardcontent)|客户端|                                                  获取系统剪贴板内容                                                   |
|             [GetFps](./1-ModAPI/接口/通用/工具.md#getfps)             |客户端|                                                    获取fps                                                     |
|    [GetHostPlayerId](./1-ModAPI/接口/通用/工具.md#gethostplayerid)    |服务端|                                                获取房主的entityId                                                 |
|    [GetHostPlayerId](./1-ModAPI/接口/通用/工具.md#gethostplayerid)    |客户端|                                                获取房主的entityId                                                 |
|   [GetMinecraftEnum](./1-ModAPI/接口/通用/工具.md#getminecraftenum)   |服务端|                      用于获取[枚举值文档](./1-ModAPI/枚举值/索引.md)中的枚举值                      |
|   [GetMinecraftEnum](./1-ModAPI/接口/通用/工具.md#getminecraftenum)   |客户端|                      用于获取[枚举值文档](./1-ModAPI/枚举值/索引.md)中的枚举值                      |
|   [GetModConfigJson](./1-ModAPI/接口/通用/工具.md#getmodconfigjson)   |服务端|                             以字典形式返回指定路径的json格式配置文件的内容，文件必须放置在行为包的/modconfigs目录下                              |
|   [GetModConfigJson](./1-ModAPI/接口/通用/工具.md#getmodconfigjson)   |客户端|                             以字典形式返回指定路径的json格式配置文件的内容，文件必须放置在资源包的/modconfigs目录下                              |
|  [GetServerTickTime](./1-ModAPI/接口/通用/工具.md#getserverticktime)  |服务端|                                               获取服务端引擎上一帧的帧消耗时间                                               |
|       [ImportModule](./1-ModAPI/接口/通用/工具.md#importmodule)       |服务端|                         使用字符串路径导入模块，作用与importlib.import\_module类似，但只能导入当前加载的mod中的模块                          |
|       [ImportModule](./1-ModAPI/接口/通用/工具.md#importmodule)       |客户端|                         使用字符串路径导入模块，作用与importlib.import\_module类似，但只能导入当前加载的mod中的模块                          |
|[SetClipboardContent](./1-ModAPI/接口/通用/工具.md#setclipboardcontent)|客户端|                                                  设置系统剪贴板内容                                                   |
|     [StartCoroutine](./1-ModAPI/接口/通用/工具.md#startcoroutine)     |服务端|                                    开启服务端协程，实现函数分段式执行，可用于缓解复杂逻辑计算导致游戏卡顿问题                                     |
|     [StartCoroutine](./1-ModAPI/接口/通用/工具.md#startcoroutine)     |客户端|                                    开启客户端协程，实现函数分段式执行，可用于缓解复杂逻辑计算导致游戏卡顿问题                                     |
|      [StopCoroutine](./1-ModAPI/接口/通用/工具.md#stopcoroutine)      |服务端|                                                     停止协程                                                     |
|      [StopCoroutine](./1-ModAPI/接口/通用/工具.md#stopcoroutine)      |客户端|                                                   停止客户端协程                                                    |

####  调试 ####

|                                                     接口                                                      |      |                                                                                                                          描述                                                                                                                          |
|-------------------------------------------------------------------------------------------------------------|------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|  [GetEnableReconnectNetgame](./1-ModAPI/接口/通用/调试.md#getenablereconnectnetgame)  | 客户端  |                                                                                                                      获取是否允许断线重连                                                                                                                      |
|[GetKeepResourceWhenTransfer](./1-ModAPI/接口/通用/调试.md#getkeepresourcewhentransfer)| 客户端  |                                                                                                                       获取快速切服设置                                                                                                                       |
|    [GetMcpModLogCanPostDump](./1-ModAPI/接口/通用/调试.md#getmcpmodlogcanpostdump)    | 服务端  |                                                                                                              获取是否可以打印错误信息到McpModLog日志。                                                                                                               |
|    [GetMcpModLogCanPostDump](./1-ModAPI/接口/通用/调试.md#getmcpmodlogcanpostdump)    | 客户端  |                                                                                                              获取是否可以打印错误信息到McpModLog日志。                                                                                                               |
|        [GetResourceFastload](./1-ModAPI/接口/通用/调试.md#getresourcefastload)        | 客户端  |                                                                                                                      获取资源快速加载设置                                                                                                                      |
|             [PostMcpModDump](./1-ModAPI/接口/通用/调试.md#postmcpmoddump)             | 服务端  |                                                                                            主动打印信息到McpModLog日志，需要先调用 SetMcpModLogCanPostDump 接口进行设置，才能生效。                                                                                             |
|             [PostMcpModDump](./1-ModAPI/接口/通用/调试.md#postmcpmoddump)             | 客户端  |                                                                                            主动打印信息到McpModLog日志，需要先调用 SetMcpModLogCanPostDump 接口进行设置，才能生效。                                                                                             |
|         [ReloadAllMaterials](./1-ModAPI/接口/通用/调试.md#reloadallmaterials)         | 客户端  |                                                                                                                      重新加载所有材质文件                                                                                                                      |
|           [ReloadAllShaders](./1-ModAPI/接口/通用/调试.md#reloadallshaders)           | 客户端  |                                                                                                                    重新加载所有Shader文件                                                                                                                    |
|            [ReloadOneShader](./1-ModAPI/接口/通用/调试.md#reloadoneshader)            | 客户端  |                                                                                                                    重新加载某个Shader文件                                                                                                                    |
|  [SetEnableReconnectNetgame](./1-ModAPI/接口/通用/调试.md#setenablereconnectnetgame)  | 客户端  |                                                                                                                      设置是否允许断线重连                                                                                                                      |
|[SetKeepResourceWhenTransfer](./1-ModAPI/接口/通用/调试.md#setkeepresourcewhentransfer)| 客户端  |                                                                                                                        设置快速切服                                                                                                                        |
|    [SetMcpModLogCanPostDump](./1-ModAPI/接口/通用/调试.md#setmcpmodlogcanpostdump)    | 服务端  |                                                                                                              设置是否可以打印错误信息到McpModLog日志。                                                                                                               |
|    [SetMcpModLogCanPostDump](./1-ModAPI/接口/通用/调试.md#setmcpmodlogcanpostdump)    | 客户端  |                                                                                                              设置是否可以打印错误信息到McpModLog日志。                                                                                                               |
|        [SetResourceFastload](./1-ModAPI/接口/通用/调试.md#setresourcefastload)        | 客户端  |                                                                                                                       设置资源快速加载                                                                                                                       |
|            [StartMemProfile](./1-ModAPI/接口/通用/调试.md#startmemprofile)            | 服务端  |                                          开始启动服务端脚本内存分析，启动后调用[StopMemProfile](./1-ModAPI/接口/通用/调试.md#stopMemProfile)即可在路径fileName生成函数内存火焰图，此接口只支持PC端。生成的火焰图可以用浏览器打开，推荐chrome浏览器。                                          |
|            [StartMemProfile](./1-ModAPI/接口/通用/调试.md#startmemprofile)            | 客户端  |                                          开始启动客户端脚本内存分析，启动后调用[StopMemProfile](./1-ModAPI/接口/通用/调试.md#stopMemProfile)即可在路径fileName生成函数内存火焰图，此接口只支持PC端。生成的火焰图可以用浏览器打开，推荐chrome浏览器。                                          |
|          [StartMultiProfile](./1-ModAPI/接口/通用/调试.md#startmultiprofile)          | 服务端  |开始启动服务端与客户端双端脚本性能分析，启动后调用[StopMultiProfile](./1-ModAPI/接口/通用/调试.md#stopmultiprofile)即可在路径fileName生成函数性能火焰图。双端采集时数据误差较大，建议优先使用[StartProfile](./1-ModAPI/接口/通用/调试.md#startprofile)单端版本，此接口只支持PC端|
|          [StartMultiProfile](./1-ModAPI/接口/通用/调试.md#startmultiprofile)          | 客户端  |开始启动服务端与客户端双端脚本性能分析，启动后调用[StopMultiProfile](./1-ModAPI/接口/通用/调试.md#stopmultiprofile)即可在路径fileName生成函数性能火焰图。双端采集时数据误差较大，建议优先使用[StartProfile](./1-ModAPI/接口/通用/调试.md#startprofile)单端版本，此接口只支持PC端|
|               [StartProfile](./1-ModAPI/接口/通用/调试.md#startprofile)               | 服务端  |                                             开始启动服务端脚本性能分析，启动后调用[StopProfile](./1-ModAPI/接口/通用/调试.md#stopprofile)即可在路径fileName生成函数性能火焰图，此接口只支持PC端。生成的火焰图可以用浏览器打开，推荐chrome浏览器。                                             |
|               [StartProfile](./1-ModAPI/接口/通用/调试.md#startprofile)               | 客户端  |                                             开始启动客户端脚本性能分析，启动后调用[StopProfile](./1-ModAPI/接口/通用/调试.md#stopprofile)即可在路径fileName生成函数性能火焰图，此接口只支持PC端。生成的火焰图可以用浏览器打开，推荐chrome浏览器。                                             |
|           [StartRecordEvent](./1-ModAPI/接口/通用/调试.md#startrecordevent)           |Apollo|                                         开始启动服务端与客户端之间的脚本事件收发统计，启动后调用[StopRecordEvent](./1-ModAPI/接口/通用/调试.md#stoprecordevent)即可获取两个函数调用之间脚本事件收发的统计信息，仅支持租赁服与Apollo网络服环境（不支持单机环境）                                         |
|          [StartRecordPacket](./1-ModAPI/接口/通用/调试.md#startrecordpacket)          |Apollo|                                         开始启动服务端与客户端之间的引擎收发包统计，启动后调用[StopRecordPacket](./1-ModAPI/接口/通用/调试.md#stoprecordpacket)即可获取两个函数调用之间引擎收发包的统计信息，仅支持租赁服与Apollo网络服环境（不支持单机环境）                                         |
|             [StopMemProfile](./1-ModAPI/接口/通用/调试.md#stopmemprofile)             | 服务端  |                                                                停止服务端脚本内存分析并生成火焰图，与[StartMemProfile](./1-ModAPI/接口/通用/调试.md#startMemProfile)配合使用，此接口只支持PC端                                                                |
|             [StopMemProfile](./1-ModAPI/接口/通用/调试.md#stopmemprofile)             | 客户端  |                                                                停止客户端脚本内存分析并生成火焰图，与[StartMemProfile](./1-ModAPI/接口/通用/调试.md#startMemProfile)配合使用，此接口只支持PC端                                                                |
|           [StopMultiProfile](./1-ModAPI/接口/通用/调试.md#stopmultiprofile)           | 服务端  |                                                              停止双端脚本性能分析并生成火焰图，与[StartMultiProfile](./1-ModAPI/接口/通用/调试.md#startmultiprofile)配合使用，此接口只支持PC端                                                               |
|           [StopMultiProfile](./1-ModAPI/接口/通用/调试.md#stopmultiprofile)           | 客户端  |                                                              停止双端脚本性能分析并生成火焰图，与[StartMultiProfile](./1-ModAPI/接口/通用/调试.md#startmultiprofile)配合使用，此接口只支持PC端                                                               |
|                [StopProfile](./1-ModAPI/接口/通用/调试.md#stopprofile)                | 服务端  |                                                                   停止服务端脚本性能分析并生成火焰图，与[StartProfile](./1-ModAPI/接口/通用/调试.md#startprofile)配合使用，此接口只支持PC端                                                                   |
|                [StopProfile](./1-ModAPI/接口/通用/调试.md#stopprofile)                | 客户端  |                                                                   停止客户端脚本性能分析并生成火焰图，与[StartProfile](./1-ModAPI/接口/通用/调试.md#startprofile)配合使用，此接口只支持PC端                                                                   |
|            [StopRecordEvent](./1-ModAPI/接口/通用/调试.md#stoprecordevent)            |Apollo|                               停止服务端与客户端之间的脚本事件收发统计并输出结果，与[StartRecordEvent](./1-ModAPI/接口/通用/调试.md#startrecordevent)配合使用，输出结果为字典，key为网络包名，value字典中记录收发信息，具体见示例，仅支持租赁服与Apollo网络服环境（不支持单机环境）                               |
|           [StopRecordPacket](./1-ModAPI/接口/通用/调试.md#stoprecordpacket)           |Apollo|                              停止服务端与客户端之间的引擎收发包统计并输出结果，与[StartRecordPacket](./1-ModAPI/接口/通用/调试.md#startrecordpacket)配合使用，输出结果为字典，key为网络包名，value字典中记录收发信息，具体见示例，仅支持租赁服与Apollo网络服环境（不支持单机环境）                               |

####  地图 ####

|                                                                接口                                                                 |   |                                                                                          描述                                                                                          |
|-----------------------------------------------------------------------------------------------------------------------------------|---|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                [CanSee](./1-ModAPI/接口/世界/地图.md#cansee)                                |服务端|                                                                            判断起始对象是否可看见目标对象,基于对象的Head位置判断                                                                             |
|                                [CanSee](./1-ModAPI/接口/世界/地图.md#cansee)                                |客户端|                                                                            判断起始对象是否可看见目标对象,基于对象的Head位置判断                                                                             |
|                       [CheckBlockToPos](./1-ModAPI/接口/世界/地图.md#checkblocktopos)                       |服务端|                                                                                     判断位置之间是否有方块                                                                                      |
|                       [CheckChunkState](./1-ModAPI/接口/世界/地图.md#checkchunkstate)                       |服务端|                                                                                  判断指定位置的chunk是否加载完成                                                                                  |
|                       [CreateDimension](./1-ModAPI/接口/世界/地图.md#createdimension)                       |服务端|                                                                                    创建新的dimension                                                                                     |
|                       [CreateExplosion](./1-ModAPI/接口/世界/地图.md#createexplosion)                       |服务端|                                                                                        用于生成爆炸                                                                                        |
|                         [DeleteAllArea](./1-ModAPI/接口/世界/地图.md#deleteallarea)                         |服务端|                                                                                      删除所有常加载区域                                                                                       |
|                            [DeleteArea](./1-ModAPI/接口/世界/地图.md#deletearea)                            |服务端|                                                                                      删除一个常加载区域                                                                                       |
|                       [DetectStructure](./1-ModAPI/接口/世界/地图.md#detectstructure)                       |服务端|                                                                                      检测自定义门的结构                                                                                       |
|                    [DoTaskOnChunkAsync](./1-ModAPI/接口/世界/地图.md#dotaskonchunkasync)                    |服务端|                                                                              异步加载指定范围区块，加载完成后调用输入的回调函数。                                                                              |
|                        [GetAllAreaKeys](./1-ModAPI/接口/世界/地图.md#getallareakeys)                        |服务端|                                                                                    获取所有常加载区域名称列表                                                                                     |
|                          [GetBiomeInfo](./1-ModAPI/接口/世界/地图.md#getbiomeinfo)                          |服务端|                                                                                      获取群系天气相关参数                                                                                      |
|                          [GetBiomeName](./1-ModAPI/接口/世界/地图.md#getbiomename)                          |服务端|                                                                                   获取某一位置所属的生物群系信息                                                                                    |
|                          [GetBiomeName](./1-ModAPI/接口/世界/地图.md#getbiomename)                          |客户端|                                                                             获取客户端当前维度已加载区域某一位置所属的生物群系信息                                                                              |
|                    [GetBlockLightLevel](./1-ModAPI/接口/世界/地图.md#getblocklightlevel)                    |服务端|                                                                                     获取方块位置的光照等级                                                                                      |
|                       [GetChunkEntites](./1-ModAPI/接口/世界/地图.md#getchunkentites)                       |服务端|                                                                               获取指定位置的区块中，全部的实体和玩家的ID列表                                                                               |
|                        [GetChunkMaxPos](./1-ModAPI/接口/世界/地图.md#getchunkmaxpos)                        |服务端|                                                                                     获取某区块最大点的坐标                                                                                      |
|                        [GetChunkMinPos](./1-ModAPI/接口/世界/地图.md#getchunkminpos)                        |服务端|                                                                                     获取某区块最小点的坐标                                                                                      |
|                        [GetChunkMobNum](./1-ModAPI/接口/世界/地图.md#getchunkmobnum)                        |服务端|                                                                              获取某区块中的生物数量（不包括玩家，但包括盔甲架）                                                                               |
|               [GetChunkPosFromBlockPos](./1-ModAPI/接口/世界/地图.md#getchunkposfromblockpos)               |服务端|                                                                                  通过方块坐标获得该方块所在区块坐标                                                                                   |
|               [GetChunkPosFromBlockPos](./1-ModAPI/接口/世界/地图.md#getchunkposfromblockpos)               |客户端|                                                                                  通过方块坐标获得该方块所在区块坐标                                                                                   |
|                   [GetCurrentDimension](./1-ModAPI/接口/世界/地图.md#getcurrentdimension)                   |客户端|                                                                                      获取客户端当前维度                                                                                       |
|                     [GetEntitiesAround](./1-ModAPI/接口/世界/地图.md#getentitiesaround)                     |服务端|                                                                                    获取区域内的entity列表                                                                                    |
|                     [GetEntitiesAround](./1-ModAPI/接口/世界/地图.md#getentitiesaround)                     |客户端|                                                                                    获取区域内的entity列表                                                                                    |
|               [GetEntitiesAroundByType](./1-ModAPI/接口/世界/地图.md#getentitiesaroundbytype)               |服务端|                                                                                  获取区域内的某类型的entity列表                                                                                  |
|               [GetEntitiesAroundByType](./1-ModAPI/接口/世界/地图.md#getentitiesaroundbytype)               |客户端|                                                                                  获取区域内的某类型的entity列表                                                                                  |
|      [GetEntitiesAroundForClientEntity](./1-ModAPI/接口/世界/地图.md#getentitiesaroundforcliententity)      |客户端|                                                                                    获取区域内的客户端实体列表                                                                                     |
|               [GetEntitiesInSquareArea](./1-ModAPI/接口/世界/地图.md#getentitiesinsquarearea)               |服务端|                                                                                    获取区域内的entity列表                                                                                    |
|               [GetEntitiesInSquareArea](./1-ModAPI/接口/世界/地图.md#getentitiesinsquarearea)               |客户端|                                                                                    获取区域内的entity列表                                                                                    |
|[GetEntitiesInSquareAreaForClientEntity](./1-ModAPI/接口/世界/地图.md#getentitiesinsquareareaforcliententity)|客户端|                                                                                    获取区域内的客户端实体列表                                                                                     |
|                            [GetLevelId](./1-ModAPI/接口/世界/地图.md#getlevelid)                            |服务端|                                                             获取levelId。某些组件需要levelId创建，可以用此接口获取levelId。其中level即为当前地图的游戏。                                                              |
|                            [GetLevelId](./1-ModAPI/接口/世界/地图.md#getlevelid)                            |客户端|                                                             获取levelId。某些组件需要levelId创建，可以用此接口获取levelId。其中level即为当前地图的游戏。                                                              |
|                       [GetLoadedChunks](./1-ModAPI/接口/世界/地图.md#getloadedchunks)                       |服务端|                                                                               获取指定维度当前已经加载完毕的全部区块的坐标列表                                                                               |
|                     [GetSpawnDimension](./1-ModAPI/接口/世界/地图.md#getspawndimension)                     |服务端|                                                                                       获取世界出生维度                                                                                       |
|                      [GetSpawnPosition](./1-ModAPI/接口/世界/地图.md#getspawnposition)                      |服务端|                                                                                      获取世界出生点坐标                                                                                       |
|                      [GetStructureSize](./1-ModAPI/接口/世界/地图.md#getstructuresize)                      |服务端|                                                                                      获取结构体的长宽高                                                                                       |
|                      [IsChunkGenerated](./1-ModAPI/接口/世界/地图.md#ischunkgenerated)                      |服务端|                                                                                     获取某个区块是否生成过。                                                                                     |
|                          [IsSlimeChunk](./1-ModAPI/接口/世界/地图.md#isslimechunk)                          |服务端|                                                                                   获取某个区块是否是史莱姆区块。                                                                                    |
|              [LocateNeteaseFeatureRule](./1-ModAPI/接口/世界/地图.md#locateneteasefeaturerule)              |服务端|与[/locate指令 (opens new window)](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/locate)相似，用于定位[网易自定义特征规则](../../../mcguide/20-玩法开发/15-自定义游戏内容/4-自定义维度/4-自定义特征.html#特征规则（feature-rules）)|
|                [LocateStructureFeature](./1-ModAPI/接口/世界/地图.md#locatestructurefeature)                |服务端|                                   与[/locate指令 (opens new window)](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/locate)相似，用于定位原版的部分结构，如海底神殿、末地城等。                                   |
|                              [MayPlace](./1-ModAPI/接口/世界/地图.md#mayplace)                              |服务端|                                                                                      判断方块是否可以放置                                                                                      |
|                            [MayPlaceOn](./1-ModAPI/接口/世界/地图.md#mayplaceon)                            |服务端|                                                                                   判断物品是否可以放到指定的位置上                                                                                   |
|                       [MirrorDimension](./1-ModAPI/接口/世界/地图.md#mirrordimension)                       |服务端|                                                                                   复制不同dimension的地形                                                                                   |
|             [OpenClientChunkGeneration](./1-ModAPI/接口/世界/地图.md#openclientchunkgeneration)             |服务端|                开启/关闭客户端区块生成功能，需要在LoadServerAddonScriptsAfter事件触发时调用。开启客户端区块生成功能时，如果使用了netease:structure\_feature或修改了大部分地图，会导致客户端和服务端地图不一致的问题。此时可以通过关闭客户端区块生成功能解决该问题。                 |
|                          [PlaceFeature](./1-ModAPI/接口/世界/地图.md#placefeature)                          |服务端|                                      放置特征，与[/placefeature指令 (opens new window)](https://zh.minecraft.wiki/w/%E5%91%BD%E4%BB%A4/placefeature)相似                                       |
|              [PlaceNeteaseLargeFeature](./1-ModAPI/接口/世界/地图.md#placeneteaselargefeature)              |服务端|                                                  放置[网易版大型结构特征](../../../mcguide/20-玩法开发/15-自定义游戏内容/4-自定义维度/6-自定义大型特征.html#自定义大型特征)                                                   |
|                        [PlaceStructure](./1-ModAPI/接口/世界/地图.md#placestructure)                        |服务端|                                                                                         放置结构                                                                                         |
|                            [SetAddArea](./1-ModAPI/接口/世界/地图.md#setaddarea)                            |服务端|                                                                                       设置区块的常加载                                                                                       |
|                         [SetBiomeByPos](./1-ModAPI/接口/世界/地图.md#setbiomebypos)                         |服务端|                                                                                   设置某一位置所属的生物群系信息                                                                                    |
|                     [SetBiomeByPosList](./1-ModAPI/接口/世界/地图.md#setbiomebyposlist)                     |服务端|                                                                                  设置所有列表中位置所属的生物群系信息                                                                                  |
|                      [SetBiomeByVolume](./1-ModAPI/接口/世界/地图.md#setbiomebyvolume)                      |服务端|                                                                                  设置长方体空间中所属的生物群系信息                                                                                   |
|                          [SetBiomeInfo](./1-ModAPI/接口/世界/地图.md#setbiomeinfo)                          |服务端|                                                                                      设置群系天气相关参数                                                                                      |
|               [SetMergeSpawnItemRadius](./1-ModAPI/接口/世界/地图.md#setmergespawnitemradius)               |服务端|                                                                                     设置新生成的物品是否合堆                                                                                     |
|          [SetSpawnDimensionAndPosition](./1-ModAPI/接口/世界/地图.md#setspawndimensionandposition)          |服务端|                                                                                     设置世界出生点维度与坐标                                                                                     |
|            [UpgradeMapDimensionVersion](./1-ModAPI/接口/世界/地图.md#upgrademapdimensionversion)            |服务端|                                           提升指定地图维度的版本号，版本号不符的维度，地图存档信息将被废弃。使用后存档的地图版本均会同步提升至最新版本，假如希望使用此接口清理指定维度的地图存档，需要在保证该维度区块都没有被加载时调用。                                           |

####  实体管理 ####

|                                                      接口                                                       |   |                                               描述                                                |
|---------------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------------------------|
|[CreateClientEntityByTypeStr](./1-ModAPI/接口/世界/实体管理.md#createcliententitybytypestr)|客户端|                                             创建客户端实体                                             |
|    [CreateEngineEntityByNBT](./1-ModAPI/接口/世界/实体管理.md#createengineentitybynbt)    |服务端|                                           根据nbt数据创建实体                                           |
|[CreateEngineEntityByTypeStr](./1-ModAPI/接口/世界/实体管理.md#createengineentitybytypestr)|服务端|                                        创建指定identifier的实体                                        |
|     [CreateEngineItemEntity](./1-ModAPI/接口/世界/实体管理.md#createengineitementity)     |服务端|                                 用于创建物品实体（即掉落物），返回物品实体的entityId                                  |
|            [CreateEntityAOI](./1-ModAPI/接口/世界/实体管理.md#createentityaoi)            |服务端|                                  注册感应区域，有实体进入时和离开时会触发回调函数func                                   |
|        [CreateExperienceOrb](./1-ModAPI/接口/世界/实体管理.md#createexperienceorb)        |服务端|                                             创建专属经验球                                             |
|     [CreateProjectileEntity](./1-ModAPI/接口/世界/实体管理.md#createprojectileentity)     |服务端|                                           创建抛射物（直接发射）                                           |
|            [DeleteEntityAOI](./1-ModAPI/接口/世界/实体管理.md#deleteentityaoi)            |服务端|删除使用[CreateEntityAOI](./1-ModAPI/接口/世界/实体管理.md#createentityaoi)注册的感应区|
|        [DestroyClientEntity](./1-ModAPI/接口/世界/实体管理.md#destroycliententity)        |客户端|                                             销毁客户端实体                                             |
|              [DestroyEntity](./1-ModAPI/接口/世界/实体管理.md#destroyentity)              |服务端|                                              销毁实体                                               |
|             [GetDroppedItem](./1-ModAPI/接口/世界/实体管理.md#getdroppeditem)             |服务端|                                           获取掉落物的物品信息                                            |
|             [GetEngineActor](./1-ModAPI/接口/世界/实体管理.md#getengineactor)             |服务端|                                     获取所有维度中已加载的所有实体（不包含玩家）。                                     |
|             [GetEngineActor](./1-ModAPI/接口/世界/实体管理.md#getengineactor)             |客户端|                                   获取客户端当前维度中已加载的所有实体（不包含玩家）。                                    |
|           [GetLocalPlayerId](./1-ModAPI/接口/世界/实体管理.md#getlocalplayerid)           |客户端|                                            获取本地玩家的id                                            |
|               [GetLootItems](./1-ModAPI/接口/世界/实体管理.md#getlootitems)               |服务端|                                 指定战利品表获取一次战利品，返回的物品与json定义的概率有关                                 |
|              [GetPlayerList](./1-ModAPI/接口/世界/实体管理.md#getplayerlist)              |服务端|                                        获取所有维度中的全部玩家的id列表                                        |
|              [GetPlayerList](./1-ModAPI/接口/世界/实体管理.md#getplayerlist)              |客户端|                                        获取所有维度中的全部玩家的id列表                                        |
|                  [HasEntity](./1-ModAPI/接口/世界/实体管理.md#hasentity)                  |客户端|                                         判断 entity 是否存在                                          |
|              [IsEntityAlive](./1-ModAPI/接口/世界/实体管理.md#isentityalive)              |服务端|                                      判断生物实体是否存活或非生物实体是否存在                                       |
|              [IsEntityAlive](./1-ModAPI/接口/世界/实体管理.md#isentityalive)              |客户端|                                      判断生物实体是否存活或非生物实体是否存在                                       |
|                 [KillEntity](./1-ModAPI/接口/世界/实体管理.md#killentity)                 |服务端|                                           杀死某个Entity                                            |
|             [SpawnLootTable](./1-ModAPI/接口/世界/实体管理.md#spawnloottable)             |服务端|                                使用生物类型模拟一次随机掉落，生成的物品与json定义的概率有关                                 |
|    [SpawnLootTableWithActor](./1-ModAPI/接口/世界/实体管理.md#spawnloottablewithactor)    |服务端|                                使用生物实例模拟一次随机掉落，生成的物品与json定义的概率有关                                 |
|             [SpawnResources](./1-ModAPI/接口/世界/实体管理.md#spawnresources)             |服务端|                                      产生方块随机掉落（该方法不适用于实体方块）                                      |
|  [SpawnResourcesSilkTouched](./1-ModAPI/接口/世界/实体管理.md#spawnresourcessilktouched)  |服务端|                                           模拟方块精准采集掉落                                            |
|  [getEntitiesOrBlockFromRay](./1-ModAPI/接口/世界/实体管理.md#getentitiesorblockfromray)  |服务端|                                    从指定位置发射一条射线，获取与射线相交的实体和方块                                    |
|  [getEntitiesOrBlockFromRay](./1-ModAPI/接口/世界/实体管理.md#getentitiesorblockfromray)  |客户端|                                    从指定位置发射一条射线，获取与射线相交的实体和方块                                    |

####  方块管理 ####

|                                              接口                                               |   |                                             描述                                              |
|-----------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------------------------|
|           [GetBlock](./1-ModAPI/接口/世界/方块管理.md#getblock)           |客户端|                                        获取某一位置的block                                         |
|       [GetBlockClip](./1-ModAPI/接口/世界/方块管理.md#getblockclip)       |服务端|获取某一位置方块当前[clip的aabb](../../../mcguide/20-玩法开发/15-自定义游戏内容/2-自定义方块/1-JSON组件.html#netease-aabb)|
|       [GetBlockClip](./1-ModAPI/接口/世界/方块管理.md#getblockclip)       |客户端|                                     获取指定位置方块当前clip的aabb                                     |
|  [GetBlockCollision](./1-ModAPI/接口/世界/方块管理.md#getblockcollision)  |服务端|                                  获取某一位置方块当前collision的aabb                                   |
|  [GetBlockCollision](./1-ModAPI/接口/世界/方块管理.md#getblockcollision)  |客户端|                                  获取指定位置方块当前collision的aabb                                   |
|        [GetBlockNew](./1-ModAPI/接口/世界/方块管理.md#getblocknew)        |服务端|                                        获取某一位置的block                                         |
|[GetDestroyTotalTime](./1-ModAPI/接口/世界/方块管理.md#getdestroytotaltime)|服务端|                                       获取使用物品破坏方块需要的时间                                       |
|[GetDestroyTotalTime](./1-ModAPI/接口/世界/方块管理.md#getdestroytotaltime)|客户端|                                       获取使用物品破坏方块需要的时间                                       |
|     [GetLiquidBlock](./1-ModAPI/接口/世界/方块管理.md#getliquidblock)     |服务端|                                      获取某个位置的方块所含流体的信息                                       |
|  [GetTopBlockHeight](./1-ModAPI/接口/世界/方块管理.md#gettopblockheight)  |服务端|                                      获取某一位置最高的非空气方块的高度                                      |
|  [GetTopBlockHeight](./1-ModAPI/接口/世界/方块管理.md#gettopblockheight)  |客户端|                                    获取当前维度某一位置最高的非空气方块的高度                                    |
|        [SetBlockNew](./1-ModAPI/接口/世界/方块管理.md#setblocknew)        |服务端|                                          设置某一位置的方块                                          |
|     [SetJigsawBlock](./1-ModAPI/接口/世界/方块管理.md#setjigsawblock)     |服务端|                                         在某一位置放置拼图方块                                         |
|     [SetLiquidBlock](./1-ModAPI/接口/世界/方块管理.md#setliquidblock)     |服务端|                               设置某一位置的方块的extraBlock，可在此设置方块含水等                               |
|       [SetSnowBlock](./1-ModAPI/接口/世界/方块管理.md#setsnowblock)       |服务端|                                         设置某一位置的方块含雪                                         |

####  生物生成 ####

|                                            接口                                             |   |                                                      描述                                                      |
|-------------------------------------------------------------------------------------------|---|--------------------------------------------------------------------------------------------------------------|
|   [GetEntityLimit](./1-ModAPI/接口/世界/生物生成.md#getentitylimit)   |服务端|获取世界最大可生成实体数量上限。可生成实体的含义见[SetEntityLimit](./1-ModAPI/接口/世界/生物生成.md#setentitylimit)|
|   [SetEntityLimit](./1-ModAPI/接口/世界/生物生成.md#setentitylimit)   |服务端|              设置世界最大可生成实体数量上限。可生成实体指具有spawnrule的实体。当前世界上被加载的可生成实体数量超过这个上限时，生物就不会再通过spawnrule刷出。               |
|[SpawnCustomModule](./1-ModAPI/接口/世界/生物生成.md#spawncustommodule)|服务端|                                                   设置自定义刷怪                                                    |

####  配方 ####

|                                             接口                                              |   |                                        描述                                        |
|---------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------|
|  [AddBrewingRecipes](./1-ModAPI/接口/世界/配方.md#addbrewingrecipes)  |服务端|                                    添加酿造台配方的接口                                    |
|          [AddRecipe](./1-ModAPI/接口/世界/配方.md#addrecipe)          |服务端|动态注册配方，支持配方类型详见[[配方类型说明]](../../../mcguide/20-玩法开发/15-自定义游戏内容/5-自定义配方.html#配方类型说明)|
|[GetRecipeByRecipeId](./1-ModAPI/接口/世界/配方.md#getrecipebyrecipeid)|服务端|                                  根据配方id查询配方内容。                                   |
|[GetRecipeByRecipeId](./1-ModAPI/接口/世界/配方.md#getrecipebyrecipeid)|客户端|                                  根据配方id查询配方内容。                                   |
|    [GetRecipeResult](./1-ModAPI/接口/世界/配方.md#getreciperesult)    |服务端|                               根据配方id获取配方结果。仅支持合成配方                               |
|  [GetRecipesByInput](./1-ModAPI/接口/世界/配方.md#getrecipesbyinput)  |服务端|                                    通过输入物品查询配方                                    |
|  [GetRecipesByInput](./1-ModAPI/接口/世界/配方.md#getrecipesbyinput)  |客户端|                                    通过输入物品查询配方                                    |
| [GetRecipesByResult](./1-ModAPI/接口/世界/配方.md#getrecipesbyresult) |服务端|                                通过输出物品查询配方所需要的输入材料                                |
| [GetRecipesByResult](./1-ModAPI/接口/世界/配方.md#getrecipesbyresult) |客户端|                                通过输出物品查询配方所需要的输入材料                                |
|       [RemoveRecipe](./1-ModAPI/接口/世界/配方.md#removerecipe)       |服务端|                                      动态禁用配方                                      |

####  方块组合 ####

|                                                     接口                                                      |   |                                                 描述                                                  |
|-------------------------------------------------------------------------------------------------------------|---|-----------------------------------------------------------------------------------------------------|
|    [CreateMicroBlockResStr](./1-ModAPI/接口/世界/方块组合.md#createmicroblockresstr)    |服务端|                                           生成微缩方块资源Json字符串                                           |
|      [GetBlankBlockPalette](./1-ModAPI/接口/世界/方块组合.md#getblankblockpalette)      |服务端|                                            获取一个空白的方块调色板。                                            |
|      [GetBlankBlockPalette](./1-ModAPI/接口/世界/方块组合.md#getblankblockpalette)      |客户端|                                            获取一个空白的方块调色板。                                            |
| [GetBlockPaletteBetweenPos](./1-ModAPI/接口/世界/方块组合.md#getblockpalettebetweenpos) |服务端|            根据输入的两个方块位置创建并获取一个方块调色板，方块调色板用于描述和记录世界中的多个方块的组合。这个方块调色板包含了这两个位置之间的所有方块及其相对位置。            |
| [GetBlockPaletteBetweenPos](./1-ModAPI/接口/世界/方块组合.md#getblockpalettebetweenpos) |客户端|根据输入的两个位置创建并获取一个方块调色板，该接口会搜索这两个位置之间的所有方块创建方块调色板，方块调色板用于描述和记录世界中的多个方块的组合。这个方块调色板包含了这两个位置之间的所有方块及其相对位置。|
|[GetBlockPaletteFromPosList](./1-ModAPI/接口/世界/方块组合.md#getblockpalettefromposlist)|服务端|           根据输入的方块位置列表创建并获取一个方块调色板，方块调色板用于描述和记录世界中的多个方块的组合。创建的方块调色板包含了这个位置列表中的所有方块及其相对位置。            |
|[GetBlockPaletteFromPosList](./1-ModAPI/接口/世界/方块组合.md#getblockpalettefromposlist)|客户端|           根据输入的方块位置列表创建并获取一个方块调色板，方块调色板用于描述和记录世界中的多个方块的组合。创建的方块调色板包含了这个位置列表中的所有方块及其相对位置。            |
|     [RegisterBlockPatterns](./1-ModAPI/接口/世界/方块组合.md#registerblockpatterns)     |服务端|                                              注册特殊方块组合                                               |
|    [SetBlockByBlockPalette](./1-ModAPI/接口/世界/方块组合.md#setblockbyblockpalette)    |服务端|                                 根据输入的方块调色板内容，将调色板内记录的所有方块设置为实际的方块。                                  |

####  渲染 ####

|                                                            接口                                                             |   |                        描述                        |
|---------------------------------------------------------------------------------------------------------------------------|---|--------------------------------------------------|
|   [AddTerrainDestroyParticleEffect](./1-ModAPI/接口/世界/渲染.md#addterraindestroyparticleeffect)   |客户端|           在指定位置播放指定方块被开始破坏时的粒子效果（如果有）。           |
|          [AddUseItemParticleEffect](./1-ModAPI/接口/世界/渲染.md#adduseitemparticleeffect)          |客户端|           在指定位置播放指定物品被开始使用时的粒子效果（如果有）。           |
|              [GetAmbientBrightness](./1-ModAPI/接口/世界/渲染.md#getambientbrightness)              |客户端|            获取环境光亮度，影响天空亮度，不影响实体与方块光照             |
|                       [GetFogColor](./1-ModAPI/接口/世界/渲染.md#getfogcolor)                       |客户端|                     获取当前雾效颜色                     |
|                      [GetFogLength](./1-ModAPI/接口/世界/渲染.md#getfoglength)                      |客户端|                      获取雾效范围                      |
|                        [GetMoonRot](./1-ModAPI/接口/世界/渲染.md#getmoonrot)                        |客户端|                      获取月亮角度                      |
|                       [GetSkyColor](./1-ModAPI/接口/世界/渲染.md#getskycolor)                       |客户端|                      获取天空颜色                      |
|                    [GetSkyTextures](./1-ModAPI/接口/世界/渲染.md#getskytextures)                    |客户端|               获取当前维度天空盒贴图，天空盒共6张贴图               |
|                 [GetStarBrightness](./1-ModAPI/接口/世界/渲染.md#getstarbrightness)                 |客户端|                      获取星星亮度                      |
|                         [GetSunRot](./1-ModAPI/接口/世界/渲染.md#getsunrot)                         |客户端|                      获取太阳角度                      |
|           [GetUseAmbientBrightness](./1-ModAPI/接口/世界/渲染.md#getuseambientbrightness)           |客户端|                 判断是否在mod设置了环境光亮度                 |
|                    [GetUseFogColor](./1-ModAPI/接口/世界/渲染.md#getusefogcolor)                    |客户端|   判断当前是否开启设置雾效颜色，该值默认为False，使用mod传入的颜色值后为True    |
|                   [GetUseFogLength](./1-ModAPI/接口/世界/渲染.md#getusefoglength)                   |客户端|   判断当前是否开启设置雾效范围,该值默认为False，使用mod传入的范围值后为True    |
|                     [GetUseMoonRot](./1-ModAPI/接口/世界/渲染.md#getusemoonrot)                     |客户端|                 判断是否在mod设置了月亮角度                  |
|                    [GetUseSkyColor](./1-ModAPI/接口/世界/渲染.md#getuseskycolor)                    |客户端|                 判断是否在mod设置了天空颜色                  |
|              [GetUseStarBrightness](./1-ModAPI/接口/世界/渲染.md#getusestarbrightness)              |客户端|                 判断是否在mod设置了星星亮度                  |
|                      [GetUseSunRot](./1-ModAPI/接口/世界/渲染.md#getusesunrot)                      |客户端|                 判断是否在mod设置了太阳角度                  |
|                       [HideNameTag](./1-ModAPI/接口/世界/渲染.md#hidenametag)                       |客户端|    隐藏场景内所有名字，包括玩家名字，生物的自定义名称，物品展示框与命令方块的悬浮文本等    |
|                     [IsHideNameTag](./1-ModAPI/接口/世界/渲染.md#ishidenametag)                     |客户端|                  获取是否隐藏场景内所有名字                   |
|[RemoveTerrainDestroyParticleEffect](./1-ModAPI/接口/世界/渲染.md#removeterraindestroyparticleeffect)|客户端|             停止指定位置播放的方块被开始破坏时的粒子效果。              |
|       [RemoveUseItemParticleEffect](./1-ModAPI/接口/世界/渲染.md#removeuseitemparticleeffect)       |客户端|             停止指定位置播放的物品被开始使用时的粒子效果。              |
|            [ResetAmbientBrightness](./1-ModAPI/接口/世界/渲染.md#resetambientbrightness)            |客户端|                     重置环境光亮度                      |
|                     [ResetFogColor](./1-ModAPI/接口/世界/渲染.md#resetfogcolor)                     |客户端|                      重置雾效颜色                      |
|                    [ResetFogLength](./1-ModAPI/接口/世界/渲染.md#resetfoglength)                    |客户端|                      重置雾效范围                      |
|                      [ResetMoonRot](./1-ModAPI/接口/世界/渲染.md#resetmoonrot)                      |客户端|                      重置月亮角度                      |
|                     [ResetSkyColor](./1-ModAPI/接口/世界/渲染.md#resetskycolor)                     |客户端|                      重置天空颜色                      |
|                  [ResetSkyTextures](./1-ModAPI/接口/世界/渲染.md#resetskytextures)                  |客户端|重置当前维度天空盒贴图。如果有使用addon配置贴图则会使用配置的贴图，否则为游戏内默认无贴图的情况|
|               [ResetStarBrightness](./1-ModAPI/接口/世界/渲染.md#resetstarbrightness)               |客户端|                      重置星星亮度                      |
|                       [ResetSunRot](./1-ModAPI/接口/世界/渲染.md#resetsunrot)                       |客户端|                      重置太阳角度                      |
|              [SetAmbientBrightness](./1-ModAPI/接口/世界/渲染.md#setambientbrightness)              |客户端|            设置环境光亮度，影响天空亮度，不影响实体与方块光照             |
|                       [SetFogColor](./1-ModAPI/接口/世界/渲染.md#setfogcolor)                       |客户端|                      设置雾效颜色                      |
|                      [SetFogLength](./1-ModAPI/接口/世界/渲染.md#setfoglength)                      |客户端|                      设置雾效范围                      |
|                        [SetMoonRot](./1-ModAPI/接口/世界/渲染.md#setmoonrot)                        |客户端|                     设置月亮所在角度                     |
|                       [SetSkyColor](./1-ModAPI/接口/世界/渲染.md#setskycolor)                       |客户端|                      设置天空颜色                      |
|                    [SetSkyTextures](./1-ModAPI/接口/世界/渲染.md#setskytextures)                    |客户端|              设置当前维度天空盒贴图，天空盒需要6张贴图               |
|                 [SetStarBrightness](./1-ModAPI/接口/世界/渲染.md#setstarbrightness)                 |客户端|                 设置星星亮度，白天也可以显示星星                 |
|                         [SetSunRot](./1-ModAPI/接口/世界/渲染.md#setsunrot)                         |客户端|                     设置太阳所在角度                     |
|                       [SkyTextures](./1-ModAPI/接口/世界/渲染.md#skytextures)                       |客户端|     修改太阳、月亮、云层分布、天空盒的贴图。使用addon配置，非python接口。     |

####  时间 ####

|                                                 接口                                                  |   |                      描述                       |
|-----------------------------------------------------------------------------------------------------|---|-----------------------------------------------|
|[GetLocalDoDayNightCycle](./1-ModAPI/接口/世界/时间.md#getlocaldodaynightcycle)|服务端|                 获取维度是否打开昼夜更替                  |
|           [GetLocalTime](./1-ModAPI/接口/世界/时间.md#getlocaltime)           |服务端|                    获取维度的时间                    |
|           [GetLocalTime](./1-ModAPI/接口/世界/时间.md#getlocaltime)           |客户端|                   获取当前维度的时间                   |
|                [GetTime](./1-ModAPI/接口/世界/时间.md#gettime)                |服务端|                   获取当前世界时间                    |
|                [GetTime](./1-ModAPI/接口/世界/时间.md#gettime)                |客户端|                   获取当前世界时间                    |
|        [GetUseLocalTime](./1-ModAPI/接口/世界/时间.md#getuselocaltime)        |服务端|              获取某个维度是否设置了使用局部时间规则              |
|[SetLocalDoDayNightCycle](./1-ModAPI/接口/世界/时间.md#setlocaldodaynightcycle)|服务端|             设置使用局部时间规则的维度是否打开昼夜更替             |
|           [SetLocalTime](./1-ModAPI/接口/世界/时间.md#setlocaltime)           |服务端|                设置使用局部时间规则维度的时间                |
|      [SetLocalTimeOfDay](./1-ModAPI/接口/世界/时间.md#setlocaltimeofday)      |服务端|             设置使用局部时间规则维度在一天内所在的时间             |
|                [SetTime](./1-ModAPI/接口/世界/时间.md#settime)                |服务端|                   设置当前世界时间                    |
|           [SetTimeOfDay](./1-ModAPI/接口/世界/时间.md#settimeofday)           |服务端|                设置当前世界在一天内所在的时间                |
|        [SetUseLocalTime](./1-ModAPI/接口/世界/时间.md#setuselocaltime)        |服务端|让某个维度拥有自己的局部时间规则，开启后该维度可以拥有与其他维度不同的时间与是否昼夜更替的规则|

####  天气 ####

|                                                         接口                                                          |   |                               描述                               |
|---------------------------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------|
|   [GetDimensionLocalWeatherInfo](./1-ModAPI/接口/世界/天气.md#getdimensionlocalweatherinfo)   |服务端|  获取独立维度天气信息(必须先使用SetDimensionUseLocalWeather接口设置此维度拥有自己的独立天气)  |
|    [GetDimensionUseLocalWeather](./1-ModAPI/接口/世界/天气.md#getdimensionuselocalweather)    |服务端|                       获取某个维度是否拥有自己的天气规则                        |
|                      [IsRaining](./1-ModAPI/接口/世界/天气.md#israining)                      |服务端|                             获取是否下雨                             |
|                      [IsThunder](./1-ModAPI/接口/世界/天气.md#isthunder)                      |服务端|                             获取是否打雷                             |
|[SetDimensionLocalDoWeatherCycle](./1-ModAPI/接口/世界/天气.md#setdimensionlocaldoweathercycle)|服务端|设置某个维度是否开启天气循环(必须先使用SetDimensionUseLocalWeather接口设置此维度拥有自己的独立天气)|
|          [SetDimensionLocalRain](./1-ModAPI/接口/世界/天气.md#setdimensionlocalrain)          |服务端|   设置某个维度下雨(必须先使用SetDimensionUseLocalWeather接口设置此维度拥有自己的独立天气)   |
|       [SetDimensionLocalThunder](./1-ModAPI/接口/世界/天气.md#setdimensionlocalthunder)       |服务端|   设置某个维度打雷(必须先使用SetDimensionUseLocalWeather接口设置此维度拥有自己的独立天气)   |
|    [SetDimensionUseLocalWeather](./1-ModAPI/接口/世界/天气.md#setdimensionuselocalweather)    |服务端|          设置某个维度拥有自己的天气规则，开启后该维度可以拥有与其他维度不同的天气和天气更替的规则          |
|                     [SetRaining](./1-ModAPI/接口/世界/天气.md#setraining)                     |服务端|                             设置是否下雨                             |
|                     [SetThunder](./1-ModAPI/接口/世界/天气.md#setthunder)                     |服务端|                             设置是否打雷                             |

####  游戏规则 ####

|                                                          接口                                                           |      |                                                                                                                          描述                                                                                                                           |
|-----------------------------------------------------------------------------------------------------------------------|------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                  [AddBannedItem](./1-ModAPI/接口/世界/游戏规则.md#addbanneditem)                  | 服务端  |                                                                                                                        增加禁用物品                                                                                                                         |
|           [AddBlockProtectField](./1-ModAPI/接口/世界/游戏规则.md#addblockprotectfield)           |Apollo|                                                                                                                  设置一个方块无法被玩家/实体破坏的区域                                                                                                                  |
|         [CleanBlockProtectField](./1-ModAPI/接口/世界/游戏规则.md#cleanblockprotectfield)         |Apollo|                                                                                                                取消全部已设置的方块无法被玩家/实体破坏的区域                                                                                                                |
|               [ClearBannedItems](./1-ModAPI/接口/世界/游戏规则.md#clearbanneditems)               | 服务端  |                                                                                                                        清空禁用物品                                                                                                                         |
|         [DisableVineBlockSpread](./1-ModAPI/接口/世界/游戏规则.md#disablevineblockspread)         | 服务端  |                                                                                                                     设置是否禁用藤曼蔓延生长                                                                                                                      |
|               [ForbidLiquidFlow](./1-ModAPI/接口/世界/游戏规则.md#forbidliquidflow)               | 服务端  |                                                                                                                     禁止/允许地图中的流体流动                                                                                                                     |
|              [GetBannedItemList](./1-ModAPI/接口/世界/游戏规则.md#getbanneditemlist)              | 服务端  |                                                                                                                       获取禁用物品列表                                                                                                                        |
|               [GetGameDiffculty](./1-ModAPI/接口/世界/游戏规则.md#getgamediffculty)               | 服务端  |                                                                                                                        获取游戏难度                                                                                                                         |
|         [GetGameRulesInfoServer](./1-ModAPI/接口/世界/游戏规则.md#getgamerulesinfoserver)         | 服务端  |                                                                                                                        获取游戏规则                                                                                                                         |
|                    [GetGameType](./1-ModAPI/接口/世界/游戏规则.md#getgametype)                    | 服务端  |                                                                                                                       获取默认游戏模式                                                                                                                        |
|                [GetLevelGravity](./1-ModAPI/接口/世界/游戏规则.md#getlevelgravity)                | 服务端  |                                                                                                                        获取重力因子                                                                                                                         |
|   [GetPistonMaxInteractionCount](./1-ModAPI/接口/世界/游戏规则.md#getpistonmaxinteractioncount)   | 服务端  |                                                                                                        获取活塞/粘性活塞最多推动的方块数量，默认为12个方块，可能被其他开发者修改。                                                                                                        |
|   [GetPistonMaxInteractionCount](./1-ModAPI/接口/世界/游戏规则.md#getpistonmaxinteractioncount)   | 客户端  |                                                                                                        获取活塞/粘性活塞最多推动的方块数量，默认为12个方块，可能被其他开发者修改。                                                                                                        |
|                        [GetSeed](./1-ModAPI/接口/世界/游戏规则.md#getseed)                        | 服务端  |                                                                                                                        获取存档种子                                                                                                                         |
|       [IsDisableCommandMinecart](./1-ModAPI/接口/世界/游戏规则.md#isdisablecommandminecart)       | 服务端  |                                                                                                         获取当前是否允许运行命令方块矿车内置逻辑指令，当前仅Apollo网络服可用                                                                                                         |
|               [IsLockDifficulty](./1-ModAPI/接口/世界/游戏规则.md#islockdifficulty)               | 服务端  |                                                                                                                   获取当前世界的游戏难度是否被锁定                                                                                                                    |
|            [IsLockGameRulesInfo](./1-ModAPI/接口/世界/游戏规则.md#islockgamerulesinfo)            | 服务端  |                                                                                                                   获取当前世界的游戏规则是否被锁定                                                                                                                    |
|                 [IsLockGameType](./1-ModAPI/接口/世界/游戏规则.md#islockgametype)                 | 服务端  |                                                                                                           获取当前世界的游戏类型是否被锁定，包括默认游戏类型和个人游戏类型                                                                                                            |
|                 [LockDifficulty](./1-ModAPI/接口/世界/游戏规则.md#lockdifficulty)                 | 服务端  |                                                                                                   锁定当前世界游戏难度（仅本次游戏有效），锁定后任何玩家在游戏内都无法通过指令或暂停菜单修改游戏难度                                                                                                   |
|              [LockGameRulesInfo](./1-ModAPI/接口/世界/游戏规则.md#lockgamerulesinfo)              | 服务端  |                                             锁定当前世界游戏规则（仅本次游戏有效），玩家无法通过指令、游戏菜单或api修改游戏规则（包括[SetGameRulesInfoServer](./1-ModAPI/接口/世界/游戏规则.md#setgamerulesinfoserver)示例中列举的规则）                                              |
|                   [LockGameType](./1-ModAPI/接口/世界/游戏规则.md#lockgametype)                   | 服务端  |锁定当前世界游戏类型（仅本次游戏有效），玩家无法通过指令、游戏菜单或相关api如[SetPlayerGameType](./1-ModAPI/接口/玩家/游戏模式.md#setplayergametype)和[SetDefaultGameType](./1-ModAPI/接口/世界/游戏规则.md#setdefaultgametype)修改游戏类型，包括默认游戏类型和个人游戏类型|
|                [OpenCityProtect](./1-ModAPI/接口/世界/游戏规则.md#opencityprotect)                |Apollo|                                                                                         开启城市保护，包括禁止破坏方块，禁止对方块使用物品，禁止怪物攻击玩家，禁止玩家之间互相攻击，禁止日夜切换，禁止天气变化，禁止怪物群落刷新                                                                                          |
|               [RemoveBannedItem](./1-ModAPI/接口/世界/游戏规则.md#removebanneditem)               | 服务端  |                                                                                                                        移除禁用物品                                                                                                                         |
|        [RemoveBlockProtectField](./1-ModAPI/接口/世界/游戏规则.md#removeblockprotectfield)        |Apollo|                                                                                                                  取消一个方块无法被玩家/实体破坏的区域                                                                                                                  |
|[SetCanActorSetOnFireByLightning](./1-ModAPI/接口/世界/游戏规则.md#setcanactorsetonfirebylightning)| 服务端  |                                                                                                                      禁止/允许闪电点燃实体                                                                                                                      |
|[SetCanBlockSetOnFireByLightning](./1-ModAPI/接口/世界/游戏规则.md#setcanblocksetonfirebylightning)| 服务端  |                                                                                                                      禁止/允许闪电点燃方块                                                                                                                      |
|             [SetDefaultGameType](./1-ModAPI/接口/世界/游戏规则.md#setdefaultgametype)             | 服务端  |                                                                                                                       设置默认游戏模式                                                                                                                        |
|      [SetDisableCommandMinecart](./1-ModAPI/接口/世界/游戏规则.md#setdisablecommandminecart)      | 服务端  |                                                                                                         设置停止/开启运行命令方块矿车内置逻辑指令，当前仅Apollo网络服可用                                                                                                          |
|           [SetDisableContainers](./1-ModAPI/接口/世界/游戏规则.md#setdisablecontainers)           | 服务端  |                                                                                            禁止所有容器界面的打开，包括玩家背包，各种包含背包界面的容器方块如工作台与箱子，以及包含背包界面的实体交互如马背包与村民交易                                                                                             |
|             [SetDisableDropItem](./1-ModAPI/接口/世界/游戏规则.md#setdisabledropitem)             | 服务端  |                                                                                                                       设置禁止丢弃物品                                                                                                                        |
|      [SetDisableGravityInLiquid](./1-ModAPI/接口/世界/游戏规则.md#setdisablegravityinliquid)      | 服务端  |                                                                                                                 是否屏蔽所有实体在液体（水、岩浆）中的重力                                                                                                                 |
|               [SetDisableHunger](./1-ModAPI/接口/世界/游戏规则.md#setdisablehunger)               | 服务端  |                                                                                                                       设置是否屏蔽饥饿度                                                                                                                       |
|              [SetGameDifficulty](./1-ModAPI/接口/世界/游戏规则.md#setgamedifficulty)              | 服务端  |                                                                                                                        设置游戏难度                                                                                                                         |
|         [SetGameRulesInfoServer](./1-ModAPI/接口/世界/游戏规则.md#setgamerulesinfoserver)         | 服务端  |                                                                                                                    设置游戏规则。所有参数均可选。                                                                                                                    |
|                      [SetHurtCD](./1-ModAPI/接口/世界/游戏规则.md#sethurtcd)                      | 服务端  |                                                                                                                      设置全局受击间隔CD                                                                                                                       |
|                [SetLevelGravity](./1-ModAPI/接口/世界/游戏规则.md#setlevelgravity)                | 服务端  |                                                                                                                        设置重力因子                                                                                                                         |
|   [SetPistonMaxInteractionCount](./1-ModAPI/接口/世界/游戏规则.md#setpistonmaxinteractioncount)   | 服务端  |                                                                                                          设置活塞/粘性活塞最多推动的方块数量，默认为12个方块。该设置不存档。                                                                                                          |

####  自定义数据 ####

|                                             接口                                             |   |                                    描述                                     |
|--------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------|
|   [CleanExtraData](./1-ModAPI/接口/世界/自定义数据.md#cleanextradata)   |服务端|       清除实体的自定义数据或者世界的自定义数据，清除实体数据时使用对应实体id创建组件，清除世界数据时使用levelId创建组件       |
|     [GetExtraData](./1-ModAPI/接口/世界/自定义数据.md#getextradata)     |服务端|  获取实体的自定义数据或者世界的自定义数据，某个键所对应的值。获取实体数据时使用对应实体id创建组件，获取世界数据时使用levelId创建组件   |
|[GetWholeExtraData](./1-ModAPI/接口/世界/自定义数据.md#getwholeextradata)|服务端|     获取完整的实体的自定义数据或者世界的自定义数据，获取实体数据时使用对应实体id创建组件，获取世界数据时使用levelId创建组件      |
|    [SaveExtraData](./1-ModAPI/接口/世界/自定义数据.md#saveextradata)    |服务端|                          用于保存实体的自定义数据或者世界的自定义数据                           |
|     [SetExtraData](./1-ModAPI/接口/世界/自定义数据.md#setextradata)     |服务端|用于设置实体的自定义数据或者世界的自定义数据，数据以键值对的形式保存。设置实体数据时使用对应实体id创建组件，设置世界数据时使用levelId创建组件|

####  指令 ####

|                                                         接口                                                          |   |                                 描述                                  |
|---------------------------------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------|
|      [GetCommandPermissionLevel](./1-ModAPI/接口/世界/指令.md#getcommandpermissionlevel)      |服务端|   返回设定使用/op命令时OP的权限等级（对应server.properties中的op-permission-level配置）   |
|[GetDefaultPlayerPermissionLevel](./1-ModAPI/接口/世界/指令.md#getdefaultplayerpermissionlevel)|服务端|返回新玩家加入时的权限身份（对应server.properties中的default-player-permission-level配置）|
|                     [SetCommand](./1-ModAPI/接口/世界/指令.md#setcommand)                     |服务端|                               使用游戏内指令                               |
|      [SetCommandPermissionLevel](./1-ModAPI/接口/世界/指令.md#setcommandpermissionlevel)      |服务端|  设置当玩家使用/op命令时OP的权限等级（对应server.properties中的op-permission-level配置）   |
|[SetDefaultPlayerPermissionLevel](./1-ModAPI/接口/世界/指令.md#setdefaultplayerpermissionlevel)|服务端|设置新玩家加入时的权限身份（对应server.properties中的default-player-permission-level配置）|

####  消息 ####

|                                             接口                                              |   |                                    描述                                     |
|---------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------|
|   [NotifyOneMessage](./1-ModAPI/接口/世界/消息.md#notifyonemessage)   |服务端|                               给指定玩家发送聊天框消息                                |
|            [SendMsg](./1-ModAPI/接口/世界/消息.md#sendmsg)            |服务端|                              模拟玩家给所有人发送聊天栏消息                              |
|    [SendMsgToPlayer](./1-ModAPI/接口/世界/消息.md#sendmsgtoplayer)    |服务端|                             模拟玩家给另一个玩家发送聊天栏消息                             |
|[SetLeftCornerNotify](./1-ModAPI/接口/世界/消息.md#setleftcornernotify)|客户端|                               客户端设置左上角通知信息                                |
|       [SetNotifyMsg](./1-ModAPI/接口/世界/消息.md#setnotifymsg)       |服务端|                                  设置消息通知                                   |
|  [SetOnePopupNotice](./1-ModAPI/接口/世界/消息.md#setonepopupnotice)  |服务端|在具体某个玩家的物品栏上方弹出popup类型通知，位置位于tip类型消息下方，此功能更建议客户端使用game组件的对应接口SetPopupNotice|
|   [SetOneTipMessage](./1-ModAPI/接口/世界/消息.md#setonetipmessage)   |服务端|在具体某个玩家的物品栏上方弹出tip类型通知，位置位于popup类型通知上方，此功能更建议在客户端使用game组件的对应接口SetTipMessage|
|     [SetPopupNotice](./1-ModAPI/接口/世界/消息.md#setpopupnotice)     |服务端|                    在所有玩家物品栏上方弹出popup类型通知，位置位于tip类型消息下方                    |
|     [SetPopupNotice](./1-ModAPI/接口/世界/消息.md#setpopupnotice)     |客户端|                   在本地玩家的物品栏上方弹出popup类型通知，位置位于tip类型消息下方                    |
|      [SetPopupState](./1-ModAPI/接口/世界/消息.md#setpopupstate)      |客户端|                               设置Popup消息栏状态                                |
|      [SetTipMessage](./1-ModAPI/接口/世界/消息.md#settipmessage)      |服务端|                    在所有玩家物品栏上方弹出tip类型通知，位置位于popup类型通知上方                    |
|      [SetTipMessage](./1-ModAPI/接口/世界/消息.md#settipmessage)      |客户端|                   在本地玩家的物品栏上方弹出tip类型通知，位置位于popup类型通知上方                    |

####  记分板 ####

|                                                        接口                                                        |   |   描述   |
|------------------------------------------------------------------------------------------------------------------|---|--------|
|[GetAllPlayerScoreboardObjects](./1-ModAPI/接口/世界/记分板.md#getallplayerscoreboardobjects)|服务端|获取玩家记分项 |
|[GetAllPlayerScoreboardObjects](./1-ModAPI/接口/世界/记分板.md#getallplayerscoreboardobjects)|客户端|获取玩家记分项 |
|      [GetAllScoreboardObjects](./1-ModAPI/接口/世界/记分板.md#getallscoreboardobjects)      |服务端|获取所有记分板项|
|      [GetAllScoreboardObjects](./1-ModAPI/接口/世界/记分板.md#getallscoreboardobjects)      |客户端|获取所有记分板项|

####  行为 ####

|                                             接口                                              |   |     描述      |
|---------------------------------------------------------------------------------------------|---|-------------|
|[UseItemAttackEntity](./1-ModAPI/接口/世界/行为.md#useitemattackentity)|服务端|使用指定物品攻击某个实体。|
|    [UseItemToEntity](./1-ModAPI/接口/世界/行为.md#useitemtoentity)    |服务端|模拟对某个实体使用物品。 |
|       [UseItemToPos](./1-ModAPI/接口/世界/行为.md#useitemtopos)       |服务端|对某个方块使用指定物品。 |

####  实体类型 ####

|                                               接口                                                |   |            描述             |
|-------------------------------------------------------------------------------------------------|---|---------------------------|
|       [GetEngineType](./1-ModAPI/接口/实体/实体类型.md#getenginetype)       |服务端|获取实体类型，主要用于判断实体是否属于某一类型的生物。|
|       [GetEngineType](./1-ModAPI/接口/实体/实体类型.md#getenginetype)       |客户端|获取实体类型，主要用于判断实体是否属于某一类型的生物。|
|    [GetEngineTypeStr](./1-ModAPI/接口/实体/实体类型.md#getenginetypestr)    |服务端|         获取实体的类型名称         |
|    [GetEngineTypeStr](./1-ModAPI/接口/实体/实体类型.md#getenginetypestr)    |客户端|         获取实体的类型名称         |
|[GetEntityDefinitions](./1-ModAPI/接口/实体/实体类型.md#getentitydefinitions)|服务端| 获取实体的命名空间ID及其当前和之前的定义组件群  |
|    [GetEntityNBTTags](./1-ModAPI/接口/实体/实体类型.md#getentitynbttags)    |服务端|        获取实体的NBT标签         |

####  附加值 ####

|                                      接口                                      |   |        描述        |
|------------------------------------------------------------------------------|---|------------------|
|[GetAuxValue](./1-ModAPI/接口/实体/附加值.md#getauxvalue)|服务端|获取射出的弓箭或投掷出的药水的附加值|
|[GetAuxValue](./1-ModAPI/接口/实体/附加值.md#getauxvalue)|客户端|获取射出的弓箭或投掷出的药水的附加值|

####  属性 ####

|                                                      接口                                                       |   |                                                                                                                 描述                                                                                                                  |
|---------------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                 [AddModifier](./1-ModAPI/接口/实体/属性.md#addmodifier)                 |服务端|                                                                                                            为指定生物增加属性修饰符                                                                                                             |
|       [ChangeEntityDimension](./1-ModAPI/接口/实体/属性.md#changeentitydimension)       |服务端|                                                                                                                传送实体                                                                                                                 |
|        [GetAllComponentsName](./1-ModAPI/接口/实体/属性.md#getallcomponentsname)        |服务端|                                                                                                          获取实体所拥有的原版组件list                                                                                                           |
|             [GetAllModifiers](./1-ModAPI/接口/实体/属性.md#getallmodifiers)             |服务端|                                                                                                          获取指定生物的某属性所有属性修饰符                                                                                                          |
|             [GetAttrMaxValue](./1-ModAPI/接口/实体/属性.md#getattrmaxvalue)             |服务端|                                                                                                            获取实体的引擎属性的最大值                                                                                                            |
|             [GetAttrMaxValue](./1-ModAPI/接口/实体/属性.md#getattrmaxvalue)             |客户端|                                                                                                        获取属性最大值，包括生命值，饥饿度，移速等                                                                                                        |
|                [GetAttrValue](./1-ModAPI/接口/实体/属性.md#getattrvalue)                |服务端|                                                                                                              获取实体的引擎属性                                                                                                              |
|                [GetAttrValue](./1-ModAPI/接口/实体/属性.md#getattrvalue)                |客户端|                                                                                                         获取属性值，包括生命值，饥饿度，移速                                                                                                          |
|                  [GetBodyRot](./1-ModAPI/接口/实体/属性.md#getbodyrot)                  |客户端|                                                                                                             获取实体的身体的角度                                                                                                              |
|         [GetCurrentAirSupply](./1-ModAPI/接口/实体/属性.md#getcurrentairsupply)         |服务端|                                                                                                              生物当前氧气储备值                                                                                                              |
|         [GetCurrentAirSupply](./1-ModAPI/接口/实体/属性.md#getcurrentairsupply)         |客户端|                                                                                                              生物当前氧气储备值                                                                                                              |
|                [GetDeathTime](./1-ModAPI/接口/实体/属性.md#getdeathtime)                |服务端|                                                                                              获取生物死亡后持续的时间（刻，1秒20刻），用于控制死亡动画。0表示生物未死亡。                                                                                               |
|       [GetEntitiesBySelector](./1-ModAPI/接口/实体/属性.md#getentitiesbyselector)       |服务端|                                                                                                  传入目标选择器，获取对应实体id (最大范围是所有已加载的实体)                                                                                                   |
|             [GetEntityDamage](./1-ModAPI/接口/实体/属性.md#getentitydamage)             |服务端|                                                                                                           获取生物(包括玩家)的攻击力                                                                                                            |
|        [GetEntityDimensionId](./1-ModAPI/接口/实体/属性.md#getentitydimensionid)        |服务端|                                                                                                              获取实体所在维度                                                                                                               |
|       [GetEntityFallDistance](./1-ModAPI/接口/实体/属性.md#getentityfalldistance)       |服务端|                                                    获取实体的坠落高度，越大的值会给予实体更大的坠落伤害，建议在[OnGroundServerEvent](./1-ModAPI/事件/实体.md#ongroundserverevent)事件中调用                                                    |
|           [GetEntityLinksTag](./1-ModAPI/接口/实体/属性.md#getentitylinkstag)           |服务端|                                                                                                 获取实体相连接的实体，如获取entityId为马，会返回骑乘者的信息                                                                                                  |
|              [GetEntityOwner](./1-ModAPI/接口/实体/属性.md#getentityowner)              |服务端|                                                                                               获取实体的属主（包括可驯服生物的主人，或者掉落物的丢弃者，弹射物的发射者等）                                                                                                |
|                  [GetFootPos](./1-ModAPI/接口/实体/属性.md#getfootpos)                  |服务端|                                                                                                             获取实体脚所在的位置                                                                                                              |
|                  [GetFootPos](./1-ModAPI/接口/实体/属性.md#getfootpos)                  |客户端|                                                                                                             获取实体脚所在的位置                                                                                                              |
|                  [GetGravity](./1-ModAPI/接口/实体/属性.md#getgravity)                  |服务端|                                                                                                   获取实体的重力因子，当生物重力因子为0时则应用世界的重力因子                                                                                                    |
|               [GetLoadActors](./1-ModAPI/接口/实体/属性.md#getloadactors)               |服务端|                                                                                                             获取已加载的实体id                                                                                                              |
|              [GetMarkVariant](./1-ModAPI/接口/实体/属性.md#getmarkvariant)              |服务端|                                                                                                            获取实体的标记变种属性值                                                                                                             |
|             [GetMaxAirSupply](./1-ModAPI/接口/实体/属性.md#getmaxairsupply)             |服务端|                                                                                                             获取生物最大氧气储备值                                                                                                             |
|             [GetMaxAirSupply](./1-ModAPI/接口/实体/属性.md#getmaxairsupply)             |客户端|                                                                                                              生物最大氧气储备值                                                                                                              |
|                 [GetMobColor](./1-ModAPI/接口/实体/属性.md#getmobcolor)                 |服务端|                                                                                                    获取生物的颜色，截止至网易2.9版本，只对羊和热带鱼有效                                                                                                     |
|              [GetMobStrength](./1-ModAPI/接口/实体/属性.md#getmobstrength)              |服务端|                                                                                            获取生物的强度，截止至网易2.9版本，只对羊驼有效，强度越大羊驼驮运的箱子时格子数量越多                                                                                             |
|           [GetMobStrengthMax](./1-ModAPI/接口/实体/属性.md#getmobstrengthmax)           |服务端|                                       获取生物强度的最大值，截止至网易2.9版本，只对羊驼有效，强度越大羊驼驮运的箱子时格子数量越多，[SetMobStrength](./1-ModAPI/接口/实体/属性.md#setstrength)无法超过SetMobStrengthMax的值                                       |
|                     [GetName](./1-ModAPI/接口/实体/属性.md#getname)                     |服务端|                                                                                             获取生物的自定义名称（即使用命名牌或者SetName接口设置的名称），或者玩家的名字。                                                                                             |
|                     [GetName](./1-ModAPI/接口/实体/属性.md#getname)                     |客户端|                                                                                             获取生物的自定义名称（即使用命名牌或者SetName接口设置的名称），或者玩家的名字。                                                                                             |
|                      [GetPos](./1-ModAPI/接口/实体/属性.md#getpos)                      |服务端|                                                                                                               获取实体位置                                                                                                                |
|                      [GetPos](./1-ModAPI/接口/实体/属性.md#getpos)                      |客户端|                                                                                                               获取实体位置                                                                                                                |
|                  [GetRiderId](./1-ModAPI/接口/实体/属性.md#getriderid)                  |客户端|                                                                                                           获取玩家坐骑entityid                                                                                                            |
|                      [GetRot](./1-ModAPI/接口/实体/属性.md#getrot)                      |服务端|                                                       获取实体头与水平方向的俯仰角度和竖直方向的旋转角度，获得角度后可用GetDirFromRot接口转换为朝向的单位向量 [MC坐标系说明](../../../mcguide/20-玩法开发/10-基本概念/10-Vector3.html)                                                        |
|                      [GetRot](./1-ModAPI/接口/实体/属性.md#getrot)                      |客户端|                                                       获取实体头与水平方向的俯仰角度和竖直方向的旋转角度，获得角度后可用GetDirFromRot接口转换为朝向的单位向量 [MC坐标系说明](../../../mcguide/20-玩法开发/10-基本概念/10-Vector3.html)                                                        |
|                     [GetSize](./1-ModAPI/接口/实体/属性.md#getsize)                     |服务端|                                                                                                              获取实体的包围盒                                                                                                               |
|                     [GetSize](./1-ModAPI/接口/实体/属性.md#getsize)                     |客户端|                                                                                                              获取实体的包围盒                                                                                                               |
|               [GetTradeLevel](./1-ModAPI/接口/实体/属性.md#gettradelevel)               |服务端|                                                                                                              获取村民的交易等级                                                                                                              |
|               [GetTypeFamily](./1-ModAPI/接口/实体/属性.md#gettypefamily)               |服务端|                                                                                                       获取生物行为包字段 type\_family                                                                                                        |
|      [GetUnitBubbleAirSupply](./1-ModAPI/接口/实体/属性.md#getunitbubbleairsupply)      |服务端|                                                                                                            单位气泡数对应的氧气储备值                                                                                                            |
|                  [GetVariant](./1-ModAPI/接口/实体/属性.md#getvariant)                  |服务端|                                                                                                             获取实体的变种属性值                                                                                                              |
|                    [HasChest](./1-ModAPI/接口/实体/属性.md#haschest)                    |服务端|                                                                                                  判断生物是否背负了箱子，截止至网易2.9版本，只对羊驼、驴、骡生效                                                                                                  |
|                [HasComponent](./1-ModAPI/接口/实体/属性.md#hascomponent)                |服务端|                                                                                                             判断实体是否有原版组件                                                                                                             |
|                 [HasModifier](./1-ModAPI/接口/实体/属性.md#hasmodifier)                 |服务端|                                                                                                           获取指定生物是否含有属性修饰符                                                                                                           |
|                   [HasSaddle](./1-ModAPI/接口/实体/属性.md#hassaddle)                   |服务端|                                                                                                             判断实体是否装备了鞍                                                                                                              |
|                     [IsAngry](./1-ModAPI/接口/实体/属性.md#isangry)                     |服务端|                                                                                                            判断实体是否处于激怒状态                                                                                                             |
|                      [IsBaby](./1-ModAPI/接口/实体/属性.md#isbaby)                      |服务端|                                                                                                              判断实体是否为幼年                                                                                                              |
|        [IsConsumingAirSupply](./1-ModAPI/接口/实体/属性.md#isconsumingairsupply)        |服务端|                                                                                                            获取生物当前是否在消耗氧气                                                                                                            |
|            [IsIllagerCaptain](./1-ModAPI/接口/实体/属性.md#isillagercaptain)            |服务端|                                                                                                 判断实体是否为袭击队长，截止至网易2.9版本，只对掠夺者和卫道士有效                                                                                                  |
|          [IsNaturallySpawned](./1-ModAPI/接口/实体/属性.md#isnaturallyspawned)          |服务端|                                                                                                            获取生物是否为自然生成的                                                                                                             |
|              [IsOutOfControl](./1-ModAPI/接口/实体/属性.md#isoutofcontrol)              |服务端|                                                                                                    判断实体是否处于失控状态，截止至网易2.9版本，只对船有效                                                                                                    |
|                  [IsPregnant](./1-ModAPI/接口/实体/属性.md#ispregnant)                  |服务端|                                                                                                     获取生物是否怀孕，截止至网易2.9版本，只对海龟有效                                                                                                      |
|                   [IsSheared](./1-ModAPI/接口/实体/属性.md#issheared)                   |服务端|                                                                                                     判断实体是否被剃毛，截止至网易2.9版本，只对羊有效                                                                                                      |
|                   [IsSitting](./1-ModAPI/接口/实体/属性.md#issitting)                   |服务端|                                                                                                            判断实体是否处于坐下状态                                                                                                             |
|                     [IsTamed](./1-ModAPI/接口/实体/属性.md#istamed)                     |服务端|                                                                                                              判断实体是否被驯服                                                                                                              |
|          [LockLocalPlayerRot](./1-ModAPI/接口/实体/属性.md#locklocalplayerrot)          |客户端|                                                                                                         在分离摄像机时，锁定本地玩家的头部角度                                                                                                         |
|     [PromoteToIllagerCaptain](./1-ModAPI/接口/实体/属性.md#promotetoillagercaptain)     |服务端|                                                                                                  晋升实体为袭击队长，截止至网易2.9版本，只对掠夺者和卫道士有效                                                                                                   |
|              [RemoveModifier](./1-ModAPI/接口/实体/属性.md#removemodifier)              |服务端|                                                                                                            为指定生物移除属性修饰符                                                                                                             |
|         [ResetToDefaultValue](./1-ModAPI/接口/实体/属性.md#resettodefaultvalue)         |服务端|                                                                                                            重置实体引擎属性到默认值                                                                                                             |
|             [ResetToMaxValue](./1-ModAPI/接口/实体/属性.md#resettomaxvalue)             |服务端|                                                                                                            重置实体引擎属性到最大值                                                                                                             |
|                    [SetAngry](./1-ModAPI/接口/实体/属性.md#setangry)                    |服务端|                                                                                                            设置实体是否处于激怒状态                                                                                                             |
|                  [SetAsAdult](./1-ModAPI/接口/实体/属性.md#setasadult)                  |服务端|                                                                                                              设置实体为成年体                                                                                                               |
|             [SetAttrMaxValue](./1-ModAPI/接口/实体/属性.md#setattrmaxvalue)             |服务端|                                                                                                            设置实体的引擎属性的最大值                                                                                                            |
|                [SetAttrValue](./1-ModAPI/接口/实体/属性.md#setattrvalue)                |服务端|                                                                                                              设置实体的引擎属性                                                                                                              |
|                    [SetChest](./1-ModAPI/接口/实体/属性.md#setchest)                    |服务端|                                                                                                  设置生物是否背负了箱子，截止至网易2.9版本，只对羊驼、驴、骡生效                                                                                                  |
|         [SetCurrentAirSupply](./1-ModAPI/接口/实体/属性.md#setcurrentairsupply)         |服务端|                                                                                                              设置生物氧气储备值                                                                                                              |
|          [SetEntityLookAtPos](./1-ModAPI/接口/实体/属性.md#setentitylookatpos)          |服务端|                                                                                                           设置非玩家的实体看向某个位置                                                                                                            |
|              [SetEntityOwner](./1-ModAPI/接口/实体/属性.md#setentityowner)              |服务端|                                                                                               设置实体的属主（包括可驯服生物的主人，或者掉落物的丢弃者，弹射物的发射者等）                                                                                                |
|                  [SetFootPos](./1-ModAPI/接口/实体/属性.md#setfootpos)                  |服务端|                                                                                                             设置实体脚底所在的位置                                                                                                             |
|                  [SetGravity](./1-ModAPI/接口/实体/属性.md#setgravity)                  |服务端|                                                                                                   设置实体的重力因子，当生物重力因子为0时则应用世界的重力因子                                                                                                    |
|              [SetMarkVariant](./1-ModAPI/接口/实体/属性.md#setmarkvariant)              |服务端|                                                                                                            设置实体的标记变种属性值                                                                                                             |
|             [SetMaxAirSupply](./1-ModAPI/接口/实体/属性.md#setmaxairsupply)             |服务端|                                                                                                             设置生物最大氧气储备值                                                                                                             |
|                 [SetMobColor](./1-ModAPI/接口/实体/属性.md#setmobcolor)                 |服务端|                                                                                                    设置生物的颜色，截止至网易2.9版本，只对羊和热带鱼有效                                                                                                     |
|              [SetMobStrength](./1-ModAPI/接口/实体/属性.md#setmobstrength)              |服务端|                                                                                            设置生物的强度，截止至网易2.9版本，只对羊驼有效，强度越大羊驼驮运的箱子时格子数量越多                                                                                             |
|           [SetMobStrengthMax](./1-ModAPI/接口/实体/属性.md#setmobstrengthmax)           |服务端|设置生物强度的最大值，截止至网易2.9版本，只对羊驼有效，强度越大羊驼驮运的箱子时格子数量越多，[SetMobStrength](./1-ModAPI/接口/实体/属性.md#setmobstrength)无法超过SetMobStrengthMax的值。由于引擎限制，在羊驼被打时候会reload组件，strengthMax会恢复成llama.json中的配置值(minecraft:strength)|
|                     [SetName](./1-ModAPI/接口/实体/属性.md#setname)                     |服务端|                                                                                                用于设置生物的自定义名称，跟原版命名牌作用相同，玩家和新版流浪商人暂不支持                                                                                                |
|             [SetOutOfControl](./1-ModAPI/接口/实体/属性.md#setoutofcontrol)             |服务端|                                                                                                    设置实体是否处于失控状态，截止至网易2.9版本，只对船有效                                                                                                    |
|               [SetPersistent](./1-ModAPI/接口/实体/属性.md#setpersistent)               |服务端|                                                              设置实体不会因为离玩家太远而被[清除 (opens new window)](https://zh.minecraft.wiki/w/%E7%94%9F%E6%88%90#%E6%B8%85%E9%99%A4)                                                              |
|          [SetPlayerLookAtPos](./1-ModAPI/接口/实体/属性.md#setplayerlookatpos)          |客户端|                                                                                                            设置本地玩家看向某个位置                                                                                                             |
|                      [SetPos](./1-ModAPI/接口/实体/属性.md#setpos)                      |服务端|                                                                                                               设置实体位置                                                                                                                |
|       [SetPosForClientEntity](./1-ModAPI/接口/实体/属性.md#setposforcliententity)       |客户端|                                                                                                             设置客户端实体位置。                                                                                                              |
|[SetRecoverTotalAirSupplyTime](./1-ModAPI/接口/实体/属性.md#setrecovertotalairsupplytime)|服务端|                                                                                                          设置恢复最大氧气量的时间，单位秒                                                                                                           |
|                      [SetRot](./1-ModAPI/接口/实体/属性.md#setrot)                      |服务端|                                                                        设置实体头与水平方向的俯仰角度和竖直方向的旋转角度 [MC坐标系说明](../../../mcguide/20-玩法开发/10-基本概念/10-Vector3.html)                                                                        |
|                      [SetRot](./1-ModAPI/接口/实体/属性.md#setrot)                      |客户端|                                                                        设置实体头与水平方向的俯仰角度和竖直方向的旋转角度 [MC坐标系说明](../../../mcguide/20-玩法开发/10-基本概念/10-Vector3.html)                                                                        |
|       [SetRotForClientEntity](./1-ModAPI/接口/实体/属性.md#setrotforcliententity)       |客户端|                                                                      设置客户端实体头与水平方向的俯仰角度和竖直方向的旋转角度 [MC坐标系说明](../../../mcguide/20-玩法开发/10-基本概念/10-Vector3.html)                                                                       |
|                  [SetSheared](./1-ModAPI/接口/实体/属性.md#setsheared)                  |服务端|                                                                                                     设置实体是否被剃毛，截止至网易2.9版本，只对羊有效                                                                                                      |
|                  [SetSitting](./1-ModAPI/接口/实体/属性.md#setsitting)                  |服务端|                                                                                                              设置生物是否坐下                                                                                                               |
|                     [SetSize](./1-ModAPI/接口/实体/属性.md#setsize)                     |服务端|                                                                                          设置实体的包围盒。设置过大会导致游戏卡顿。实体的scale的立方乘以包围盒的体积不可超过32768                                                                                          |
|               [SetTradeLevel](./1-ModAPI/接口/实体/属性.md#settradelevel)               |服务端|                                                                                                              设置村民的交易等级                                                                                                              |
|                  [SetVariant](./1-ModAPI/接口/实体/属性.md#setvariant)                  |服务端|                                                                                                             设置实体的变种属性值                                                                                                              |
|              [UpdateModifier](./1-ModAPI/接口/实体/属性.md#updatemodifier)              |服务端|                                                                                                            为指定生物更新属性修饰符                                                                                                             |
|              [isEntityInLava](./1-ModAPI/接口/实体/属性.md#isentityinlava)              |客户端|                                                                                                              实体是否在岩浆中                                                                                                               |
|            [isEntityOnGround](./1-ModAPI/接口/实体/属性.md#isentityonground)            |客户端|                                                                                                               实体是否触地                                                                                                                |

####  行为 ####

|                                                     接口                                                      |   |                                      描述                                       |
|-------------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------|
|          [AddActorComponent](./1-ModAPI/接口/实体/行为.md#addactorcomponent)          |服务端|                             给指定实体自定义添加实体Component                             |
|     [AddActorComponentGroup](./1-ModAPI/接口/实体/行为.md#addactorcomponentgroup)     |服务端|                        给指定实体添加实体json中配置的ComponentGroup                        |
|[AddEntityAroundEntityMotion](./1-ModAPI/接口/实体/行为.md#addentityaroundentitymotion)|服务端|                              给实体（不含玩家）添加对实体环绕运动器                              |
| [AddEntityAroundPointMotion](./1-ModAPI/接口/实体/行为.md#addentityaroundpointmotion) |服务端|                              给实体（不含玩家）添加对点环绕运动器                               |
|              [AddEntitySeat](./1-ModAPI/接口/实体/行为.md#addentityseat)              |服务端|                                    增加坐骑座位                                     |
|       [AddEntityTrackMotion](./1-ModAPI/接口/实体/行为.md#addentitytrackmotion)       |服务端|                               给实体（不含玩家）添加轨迹运动器                                |
|    [AddEntityVelocityMotion](./1-ModAPI/接口/实体/行为.md#addentityvelocitymotion)    |服务端|                               给实体（不含玩家）添加速度运动器                                |
|            [ChangeRiderSeat](./1-ModAPI/接口/实体/行为.md#changeriderseat)            |服务端|                                设置骑乘者在当前坐骑上的序号                                 |
|           [DeleteEntitySeat](./1-ModAPI/接口/实体/行为.md#deleteentityseat)           |服务端|                                    删除坐骑座位                                     |
|            [GetAttackTarget](./1-ModAPI/接口/实体/行为.md#getattacktarget)            |服务端|                                    获取仇恨目标                                     |
|            [GetAttackTarget](./1-ModAPI/接口/实体/行为.md#getattacktarget)            |客户端|                                    获取仇恨目标                                     |
|          [GetBlockControlAi](./1-ModAPI/接口/实体/行为.md#getblockcontrolai)          |服务端|                                 获取生物原生AI是否被屏蔽                                 |
|              [GetComponents](./1-ModAPI/接口/实体/行为.md#getcomponents)              |服务端|                              获取指定实体的生效Components                              |
|           [GetCustomGoalCls](./1-ModAPI/接口/实体/行为.md#getcustomgoalcls)           |服务端|                    用于获取服务器自定义行为节点的基类。实现新的行为节点时，需要继承该接口返回的类                    |
|           [GetEntityMotions](./1-ModAPI/接口/实体/行为.md#getentitymotions)           |服务端|                              获取实体（不含玩家）身上的所有运动器                               |
|               [GetJumpPower](./1-ModAPI/接口/实体/行为.md#getjumppower)               |服务端|                              获取生物跳跃力度，0.42表示正常水平                              |
|             [GetLeashHolder](./1-ModAPI/接口/实体/行为.md#getleashholder)             |服务端|                              获取实体被使用拴绳牵引时牵引者的ID                               |
|                  [GetMotion](./1-ModAPI/接口/实体/行为.md#getmotion)                  |服务端|                              获取生物（含玩家）的瞬时移动方向向量                               |
|                  [GetMotion](./1-ModAPI/接口/实体/行为.md#getmotion)                  |客户端|          获取生物的瞬时移动方向向量。与服务端不同，客户端不会计算摩擦等因素，获取到的是上一帧的向量，与服务器获取到的值会不相等          |
|                 [GetOwnerId](./1-ModAPI/接口/实体/行为.md#getownerid)                 |服务端|                                  获取驯服生物的主人id                                  |
|                 [GetOwnerId](./1-ModAPI/接口/实体/行为.md#getownerid)                 |客户端|                                  获取驯服生物的主人id                                  |
|                  [GetRiders](./1-ModAPI/接口/实体/行为.md#getriders)                  |服务端|                                  获取坐骑上的骑乘者信息                                  |
|              [GetStepHeight](./1-ModAPI/接口/实体/行为.md#getstepheight)              |服务端|                             返回玩家前进非跳跃状态下能上的最大台阶高度                             |
|                       [Hurt](./1-ModAPI/接口/实体/行为.md#hurt)                       |服务端|                                    设置实体伤害                                     |
|               [ImmuneDamage](./1-ModAPI/接口/实体/行为.md#immunedamage)               |服务端|                               设置实体是否免疫伤害（该属性存档）                               |
|                   [IsEating](./1-ModAPI/接口/实体/行为.md#iseating)                   |服务端|                                 判断非玩家实体是否在进食                                  |
|             [IsEntityOnFire](./1-ModAPI/接口/实体/行为.md#isentityonfire)             |服务端|                                   获取实体是否着火                                    |
|              [IsLootDropped](./1-ModAPI/接口/实体/行为.md#islootdropped)              |服务端|                                  获取生物是否生成掉落物                                  |
|               [IsPersistent](./1-ModAPI/接口/实体/行为.md#ispersistent)               |服务端|                                  判断是否为持久性生物                                   |
|                  [IsRoaring](./1-ModAPI/接口/实体/行为.md#isroaring)                  |服务端|                         判断是否处于咆哮状态，截止至网易2.9版本，仅对劫掠兽有效                         |
|                  [IsStunned](./1-ModAPI/接口/实体/行为.md#isstunned)                  |服务端|                         判断是否处于眩晕状态，截止至网易2.9版本，仅对劫掠兽有效                         |
|       [RemoveActorComponent](./1-ModAPI/接口/实体/行为.md#removeactorcomponent)       |服务端|                              删除指定实体的指定Component                               |
|  [RemoveActorComponentGroup](./1-ModAPI/接口/实体/行为.md#removeactorcomponentgroup)  |服务端|                        移除指定实体在实体json中配置的ComponentGroup                        |
|         [RemoveEntityMotion](./1-ModAPI/接口/实体/行为.md#removeentitymotion)         |服务端|                               移除实体（不含玩家）身上的运动器                                |
|          [ResetAttackTarget](./1-ModAPI/接口/实体/行为.md#resetattacktarget)          |服务端|                                    清除仇恨目标                                     |
|                [ResetMotion](./1-ModAPI/接口/实体/行为.md#resetmotion)                |服务端|                              重置生物（不含玩家）的瞬时移动方向向量                              |
|            [ResetStepHeight](./1-ModAPI/接口/实体/行为.md#resetstepheight)            |服务端|                           恢复引擎默认玩家前进非跳跃状态下能上的最大台阶高度                           |
|         [SetActorCollidable](./1-ModAPI/接口/实体/行为.md#setactorcollidable)         |服务端|                                   设置实体是否可碰撞                                   |
|           [SetActorPushable](./1-ModAPI/接口/实体/行为.md#setactorpushable)           |服务端|                                   设置实体是否可推动                                   |
|            [SetAttackTarget](./1-ModAPI/接口/实体/行为.md#setattacktarget)            |服务端|                                    设置仇恨目标                                     |
|          [SetBlockControlAi](./1-ModAPI/接口/实体/行为.md#setblockcontrolai)          |服务端|                                  设置屏蔽生物原生AI                                   |
|      [SetCanOtherPlayerRide](./1-ModAPI/接口/实体/行为.md#setcanotherplayerride)      |服务端|                  设置其他玩家是否有权限骑乘，True表示每个玩家都能骑乘，False只有驯服者才能骑乘                  |
|                 [SetControl](./1-ModAPI/接口/实体/行为.md#setcontrol)                 |服务端|                              设置该生物无需装备鞍就可以控制行走跳跃                              |
|    [SetEntityInteractFilter](./1-ModAPI/接口/实体/行为.md#setentityinteractfilter)    |服务端|                                  设置与生物可交互的条件                                  |
|         [SetEntityLockRider](./1-ModAPI/接口/实体/行为.md#setentitylockrider)         |服务端|                                设置坐骑上的实体是否锁定序号                                 |
|            [SetEntityOnFire](./1-ModAPI/接口/实体/行为.md#setentityonfire)            |服务端|                                    设置实体着火                                     |
|              [SetEntityRide](./1-ModAPI/接口/实体/行为.md#setentityride)              |服务端|                                    驯服可骑乘生物                                    |
|              [SetEntitySeat](./1-ModAPI/接口/实体/行为.md#setentityseat)              |服务端|                            设置坐骑座位的位置、旋转以及允许实体旋转范围                             |
|   [SetEntityShareablesItems](./1-ModAPI/接口/实体/行为.md#setentityshareablesitems)   |服务端|                               设置生物可分享/可拾取的物品列表                                |
|             [SetEntityTamed](./1-ModAPI/接口/实体/行为.md#setentitytamed)             |服务端|                   设置生物驯服，需要配合 entityEvent组件使用。该类驯服不包含骑乘功能。                    |
|               [SetJumpPower](./1-ModAPI/接口/实体/行为.md#setjumppower)               |服务端|                              设置生物跳跃力度，0.42表示正常水平                              |
|             [SetLeashHolder](./1-ModAPI/接口/实体/行为.md#setleashholder)             |服务端|为实体添加牵引者，与原版拴绳的作用相同，详见[基岩版栓绳介绍](https://zh.minecraft.wiki/w/%E6%8B%B4%E7%BB%B3)|
|             [SetLootDropped](./1-ModAPI/接口/实体/行为.md#setlootdropped)             |服务端|                                  设置生物是否生成掉落物                                  |
|            [SetMobKnockback](./1-ModAPI/接口/实体/行为.md#setmobknockback)            |服务端|                              设置击退的初始速度，需要考虑阻力的影响                              |
|                  [SetMotion](./1-ModAPI/接口/实体/行为.md#setmotion)                  |服务端|                              设置生物（不含玩家）的瞬时移动方向向量                              |
|                  [SetMotion](./1-ModAPI/接口/实体/行为.md#setmotion)                  |客户端|                              设置瞬时的移动方向向量，用于本地玩家                               |
|             [SetMoveSetting](./1-ModAPI/接口/实体/行为.md#setmovesetting)             |服务端|                                     寻路组件                                      |
|             [SetPersistence](./1-ModAPI/接口/实体/行为.md#setpersistence)             |服务端|                                  设置实体是否持久化。                                   |
|                 [SetRidePos](./1-ModAPI/接口/实体/行为.md#setridepos)                 |服务端|                                   设置生物骑乘位置                                    |
|         [SetRiderRideEntity](./1-ModAPI/接口/实体/行为.md#setriderrideentity)         |服务端|                               设置实体骑乘生物（或者船与矿车）                                |
|              [SetStepHeight](./1-ModAPI/接口/实体/行为.md#setstepheight)              |服务端|                 设置玩家前进非跳跃状态下能上的最大台阶高度, 默认值为0.5625，1的话表示能上一个台阶                 |
|          [StartEntityMotion](./1-ModAPI/接口/实体/行为.md#startentitymotion)          |服务端|                              启动实体（不含玩家）身上的某个运动器                               |
|           [StopEntityMotion](./1-ModAPI/接口/实体/行为.md#stopentitymotion)           |服务端|                              停止实体（不含玩家）身上的某个运动器                               |
|           [StopEntityRiding](./1-ModAPI/接口/实体/行为.md#stopentityriding)           |服务端|                                   强制骑乘者下坐骑。                                   |
|         [TriggerCustomEvent](./1-ModAPI/接口/实体/行为.md#triggercustomevent)         |服务端|                                   触发生物自定义事件                                   |

####  状态效果 ####

|                                                 接口                                                  |   |                                                       描述                                                        |
|-----------------------------------------------------------------------------------------------------|---|-----------------------------------------------------------------------------------------------------------------|
|     [AddEffectToEntity](./1-ModAPI/接口/实体/状态效果.md#addeffecttoentity)     |服务端|为实体添加指定状态效果，如果添加的状态已存在则有以下集中情况：1、等级大于已存在则更新状态等级及持续时间；2、状态等级相等且剩余时间duration大于已存在则刷新剩余时间；3、等级小于已存在则不做修改；4、粒子效果以新的为准|
|         [GetAllEffects](./1-ModAPI/接口/实体/状态效果.md#getalleffects)         |服务端|                                                  获取实体当前所有状态效果                                                   |
|         [GetAllEffects](./1-ModAPI/接口/实体/状态效果.md#getalleffects)         |客户端|                                                  获取实体当前所有状态效果                                                   |
|        [GetLoadEffects](./1-ModAPI/接口/实体/状态效果.md#getloadeffects)        |服务端|                                                  获取所有已加载的状态效果                                                   |
|             [HasEffect](./1-ModAPI/接口/实体/状态效果.md#haseffect)             |服务端|                                                 获取实体是否存在当前状态效果                                                  |
|             [HasEffect](./1-ModAPI/接口/实体/状态效果.md#haseffect)             |客户端|                                                 获取实体是否存在当前状态效果                                                  |
|[RemoveEffectFromEntity](./1-ModAPI/接口/实体/状态效果.md#removeeffectfromentity)|服务端|                                                   为实体删除指定状态效果                                                   |

####  渲染 ####

|                                                              接口                                                               |   |                                                                                                                                        描述                                                                                                                                        |
|-------------------------------------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                   [AddActorAnimation](./1-ModAPI/接口/实体/渲染.md#addactoranimation)                   |客户端|                                                                                                                                     增加生物渲染动画                                                                                                                                     |
|         [AddActorAnimationController](./1-ModAPI/接口/实体/渲染.md#addactoranimationcontroller)         |客户端|                                                                                                                                   增加生物渲染动画控制器                                                                                                                                    |
|               [AddActorBlockGeometry](./1-ModAPI/接口/实体/渲染.md#addactorblockgeometry)               |客户端|                                                                                                                                  为实体添加方块几何体模型。                                                                                                                                   |
|                    [AddActorGeometry](./1-ModAPI/接口/实体/渲染.md#addactorgeometry)                    |客户端|                                                                                                                                    增加生物渲染几何体                                                                                                                                     |
|              [AddActorParticleEffect](./1-ModAPI/接口/实体/渲染.md#addactorparticleeffect)              |客户端|                                                                                                                                     增加生物特效资源                                                                                                                                     |
|            [AddActorRenderController](./1-ModAPI/接口/实体/渲染.md#addactorrendercontroller)            |客户端|                                                                                               增加生物[渲染控制器](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_7-自定义渲染控制器)                                                                                               |
|       [AddActorRenderControllerArray](./1-ModAPI/接口/实体/渲染.md#addactorrendercontrollerarray)       |客户端|                                                                                                                              增加生物渲染控制器列表中字典arrays元素                                                                                                                              |
|              [AddActorRenderMaterial](./1-ModAPI/接口/实体/渲染.md#addactorrendermaterial)              |客户端|                                                                                               增加生物渲染需要的[材质](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_3-自定义材质)                                                                                                |
|               [AddActorScriptAnimate](./1-ModAPI/接口/实体/渲染.md#addactorscriptanimate)               |客户端|                                                                                                      在生物的客户端实体定义（minecraft:client\_entity）json中的scripts/animate节点添加动画/动画控制器                                                                                                      |
|                 [AddActorSoundEffect](./1-ModAPI/接口/实体/渲染.md#addactorsoundeffect)                 |客户端|                                                                                                                                     增加生物音效资源                                                                                                                                     |
|                     [AddActorTexture](./1-ModAPI/接口/实体/渲染.md#addactortexture)                     |客户端|                                                                                                                                     增加生物渲染贴图                                                                                                                                     |
|    [AddAnimationControllerToOneActor](./1-ModAPI/接口/实体/渲染.md#addanimationcontrollertooneactor)    |客户端|                                                                                                                                  增加单个生物渲染动画控制器                                                                                                                                   |
|              [AddAnimationToOneActor](./1-ModAPI/接口/实体/渲染.md#addanimationtooneactor)              |客户端|                                                                                                                                    增加单个生物渲染动画                                                                                                                                    |
|               [AddGeometryToOneActor](./1-ModAPI/接口/实体/渲染.md#addgeometrytooneactor)               |客户端|                                                                                                                                   增加单个生物渲染几何体                                                                                                                                    |
|         [AddParticleEffectToOneActor](./1-ModAPI/接口/实体/渲染.md#addparticleeffecttooneactor)         |客户端|                                                                                                                                     增加生物特效资源                                                                                                                                     |
|       [AddRenderControllerToOneActor](./1-ModAPI/接口/实体/渲染.md#addrendercontrollertooneactor)       |客户端|                                                                                             增加单个生物[的渲染控制器](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_7-自定义渲染控制器)                                                                                              |
|         [AddRenderMaterialToOneActor](./1-ModAPI/接口/实体/渲染.md#addrendermaterialtooneactor)         |客户端|                                                                                              增加单个生物渲染需要的[材质](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_3-自定义材质)                                                                                               |
|          [AddScriptAnimateToOneActor](./1-ModAPI/接口/实体/渲染.md#addscriptanimatetooneactor)          |客户端|                                                                                                     在单个生物的客户端实体定义（minecraft:client\_entity）json中的scripts/animate节点添加动画/动画控制器                                                                                                     |
|            [AddSoundEffectToOneActor](./1-ModAPI/接口/实体/渲染.md#addsoundeffecttooneactor)            |客户端|                                                                                                                                   增加单个生物的音效资源                                                                                                                                    |
|                [AddTextureToOneActor](./1-ModAPI/接口/实体/渲染.md#addtexturetooneactor)                |客户端|                                                                                                                                   增加单个生物的渲染贴图                                                                                                                                    |
|                  [BindEntityToEntity](./1-ModAPI/接口/实体/渲染.md#bindentitytoentity)                  |客户端|                                                                                                                 绑定骨骼模型跟随其他entity,如果当前entity是本地玩家，摄像机也跟随其他entity                                                                                                                  |
|             [ClearActorBlockGeometry](./1-ModAPI/接口/实体/渲染.md#clearactorblockgeometry)             |客户端|                                                                                                                                 删除实体中所有的方块几何体模型。                                                                                                                                 |
|         [CopyActorGeometryFromPlayer](./1-ModAPI/接口/实体/渲染.md#copyactorgeometryfromplayer)         |客户端|                                                                                                                          将渲染几何体从某个玩家拷贝到某类生物identifier上                                                                                                                           |
|   [CopyActorRenderMaterialFromPlayer](./1-ModAPI/接口/实体/渲染.md#copyactorrendermaterialfromplayer)   |客户端|                                                                                       将渲染[材质](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_3-自定义材质)从某个玩家拷贝到某类生物identifier上                                                                                       |
|          [CopyActorTextureFromPlayer](./1-ModAPI/接口/实体/渲染.md#copyactortexturefromplayer)          |客户端|                                                                                                                            将贴图从某个玩家拷贝到某类生物identifier上                                                                                                                            |
|        [CopyPlayerGeometryToOneActor](./1-ModAPI/接口/实体/渲染.md#copyplayergeometrytooneactor)        |客户端|                                                                                                                               将渲染几何体从某个玩家拷贝到某个生物上                                                                                                                                |
|  [CopyPlayerRenderMaterialToOneActor](./1-ModAPI/接口/实体/渲染.md#copyplayerrendermaterialtooneactor)  |客户端|                                                                                            将渲染[材质](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_3-自定义材质)从某个玩家拷贝到某个生物上                                                                                            |
|         [CopyPlayerTextureToOneActor](./1-ModAPI/接口/实体/渲染.md#copyplayertexturetooneactor)         |客户端|                                                                                                                                 将贴图从某个玩家拷贝到某个生物上                                                                                                                                 |
|            [DeleteActorBlockGeometry](./1-ModAPI/接口/实体/渲染.md#deleteactorblockgeometry)            |客户端|                                                                                                                                 删除实体中指定方块几何体模型。                                                                                                                                  |
|                [GetActorRenderParams](./1-ModAPI/接口/实体/渲染.md#getactorrenderparams)                |客户端|                                                                                                                                  获取实体（包括玩家）渲染参数                                                                                                                                  |
|              [GetEntityExtraUniforms](./1-ModAPI/接口/实体/渲染.md#getentityextrauniforms)              |客户端|                                                   获取在实体shader当中使用的自定义变量的值。该自定义变量包含EXTRA\_ACTOR\_UNIFORM1,EXTRA\_ACTOR\_UNIFORM2,EXTRA\_ACTOR\_UNIFORM3,EXTRA\_ACTOR\_UNIFORM4，总共4组，每组为一个vec4(float, float, float ,float)类型的向量。                                                   |
|             [GetEntityRenderDistance](./1-ModAPI/接口/实体/渲染.md#getentityrenderdistance)             |客户端|                                                                          获取玩家的实体可渲染距离。玩家周围的实体指这个区块内的实体，也包含玩家自身。实体的渲染距离指，实体的位置到玩家相机位置的距离。可渲染距离指，如果实体的渲染距离在可渲染距离之内，则实体会被渲染出来，如果在距离以外，则实体不会被渲染出来。仅对本地玩家有效。                                                                          |
|            [GetEntityUIExtraUniforms](./1-ModAPI/接口/实体/渲染.md#getentityuiextrauniforms)            |客户端|             获取在实体shader当中使用的UI自定义变量的值，该变量可在微软UI纸娃娃（paperdoll）及网易版纸娃娃（neteasepaperdoll)上使用identifier渲染某一类生物实体时使用。该自定义变量包含EXTRA\_ACTOR\_UNIFORM1,EXTRA\_ACTOR\_UNIFORM2,EXTRA\_ACTOR\_UNIFORM3,EXTRA\_ACTOR\_UNIFORM4，总共4组，每组为一个vec4(float, float, float ,float)类型的向量。             |
|                   [GetNotRenderAtAll](./1-ModAPI/接口/实体/渲染.md#getnotrenderatall)                   |客户端|                                                                                                                                    获取实体是否不渲染                                                                                                                                     |
|         [GetQueryableBoneOrientation](./1-ModAPI/接口/实体/渲染.md#getqueryableboneorientation)         |客户端|                                                                                                                              获取实体的原版模型指定骨骼的骨骼矩阵信息。                                                                                                                               |
|                          [IsShowName](./1-ModAPI/接口/实体/渲染.md#isshowname)                          |客户端|                                                                                                                             获取生物名字是否按照默认游戏逻辑显示（包括玩家）                                                                                                                             |
|                  [RebuildActorRender](./1-ModAPI/接口/实体/渲染.md#rebuildactorrender)                  |客户端|                                                                                                                  重建生物的数据渲染器（该接口不支持玩家，玩家请使用RebuildPlayerRender）                                                                                                                   |
|            [RebuildRenderForOneActor](./1-ModAPI/接口/实体/渲染.md#rebuildrenderforoneactor)            |客户端|                                                                                                          使用完entity类渲染接口后，重建单个生物渲染控制器（该接口不支持玩家，玩家请使用RebuildPlayerRender）                                                                                                          |
|      [RemoveActorAnimationController](./1-ModAPI/接口/实体/渲染.md#removeactoranimationcontroller)      |客户端|                                                                                                                                   移除生物渲染动画控制器                                                                                                                                    |
|                 [RemoveActorGeometry](./1-ModAPI/接口/实体/渲染.md#removeactorgeometry)                 |客户端|                                                                                                                                    删除生物渲染几何体                                                                                                                                     |
|         [RemoveActorRenderController](./1-ModAPI/接口/实体/渲染.md#removeactorrendercontroller)         |客户端|                                                                                               删除生物[渲染控制器](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_7-自定义渲染控制器)                                                                                               |
|                  [RemoveActorTexture](./1-ModAPI/接口/实体/渲染.md#removeactortexture)                  |客户端|                                                                                                                                     删除生物渲染贴图                                                                                                                                     |
|[RemoveAnimationControllerForOneActor](./1-ModAPI/接口/实体/渲染.md#removeanimationcontrollerforoneactor)|客户端|                                                                                                                                  移除单个生物渲染动画控制器                                                                                                                                   |
|           [RemoveGeometryForOneActor](./1-ModAPI/接口/实体/渲染.md#removegeometryforoneactor)           |客户端|                                                                                                                                   删除单个生物的渲染几何体                                                                                                                                   |
|   [RemoveRenderControllerForOneActor](./1-ModAPI/接口/实体/渲染.md#removerendercontrollerforoneactor)   |客户端|                                                                                             删除单个生物[的渲染控制器](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_7-自定义渲染控制器)                                                                                              |
|            [RemoveTextureForOneActor](./1-ModAPI/接口/实体/渲染.md#removetextureforoneactor)            |客户端|                                                                                                                                   删除单个生物的渲染贴图                                                                                                                                    |
|                    [ResetActorRender](./1-ModAPI/接口/实体/渲染.md#resetactorrender)                    |客户端|                                                                                                                   重置实体渲染接口，包括动画、动画控制器、渲染控制器、贴图、材质、特效资源、音效资源等。                                                                                                                    |
|                     [ResetBindEntity](./1-ModAPI/接口/实体/渲染.md#resetbindentity)                     |客户端|                                                                                                                        取消目标entity的绑定实体，取消后不再跟随任何其他entity                                                                                                                         |
|                [ResetEntityExtraSkin](./1-ModAPI/接口/实体/渲染.md#resetentityextraskin)                |客户端|                                                                                                  清除通过 actorRender 接口为实体（包括玩家）额外添加的皮肤渲染组件（几何体、动画、动画控制器、贴图、材质、渲染控制器），还原实体到原始渲染状态。                                                                                                  |
|              [ResetRenderForOneActor](./1-ModAPI/接口/实体/渲染.md#resetrenderforoneactor)              |客户端|                                                                                            将调用OneActor类渲染接口(CopyPlayerTextureToOneActor、CopyPlayerRenderMaterialToOneActor等)的生物重置回种群                                                                                             |
|     [SetActorAllBlockGeometryVisible](./1-ModAPI/接口/实体/渲染.md#setactorallblockgeometryvisible)     |客户端|                                                                                                                               设置实体中所有的方块几何体模型是否显示。                                                                                                                               |
|        [SetActorBlockGeometryVisible](./1-ModAPI/接口/实体/渲染.md#setactorblockgeometryvisible)        |客户端|                                                                                                                               设置实体中指定的方块几何体模型是否显示。                                                                                                                               |
|                   [SetAlwaysShowName](./1-ModAPI/接口/实体/渲染.md#setalwaysshowname)                   |客户端|                                                                                                                            设置生物名字是否一直显示，瞄准点不指向生物时也能显示                                                                                                                            |
|                            [SetColor](./1-ModAPI/接口/实体/渲染.md#setcolor)                            |客户端|                                                                                                                                   设置血条的颜色及背景色                                                                                                                                    |
|              [SetEntityExtraUniforms](./1-ModAPI/接口/实体/渲染.md#setentityextrauniforms)              |客户端|                                    设置可在实体shader当中使用的自定义变量的值。该自定义变量总共可设置EXTRA\_ACTOR\_UNIFORM1,EXTRA\_ACTOR\_UNIFORM2,EXTRA\_ACTOR\_UNIFORM3,EXTRA\_ACTOR\_UNIFORM4，总共4组，每组为一个vec4(float, float, float ,float)类型的向量，向量的默认值为(1.0,1.0,1.0,1.0)。                                     |
|             [SetEntityRenderDistance](./1-ModAPI/接口/实体/渲染.md#setentityrenderdistance)             |客户端|                                                                        设置玩家周围的实体的可渲染距离。玩家周围的实体指这个区块内的实体，也包含玩家自身。实体的渲染距离指，实体的位置到玩家相机位置的距离。可渲染距离指，如果实体的渲染距离在可渲染距离之内，则实体会被渲染出来，如果在距离以外，则实体不会被渲染出来。仅对本地玩家有效。                                                                         |
|            [SetEntityUIExtraUniforms](./1-ModAPI/接口/实体/渲染.md#setentityuiextrauniforms)            |客户端|设置可在实体shader当中使用的UI自定义变量的值，可在微软UI纸娃娃（paperdoll）及网易版纸娃娃（neteasepaperdoll)上使用identifier渲染某一类生物实体时使用。该自定义变量总共可设置EXTRA\_ACTOR\_UNIFORM1,EXTRA\_ACTOR\_UNIFORM2,EXTRA\_ACTOR\_UNIFORM3,EXTRA\_ACTOR\_UNIFORM4，总共4组，每组为一个vec4(float, float, float ,float)类型的向量，向量的默认值为(1.0,1.0,1.0,1.0)。|
|               [SetHealthBarDeviation](./1-ModAPI/接口/实体/渲染.md#sethealthbardeviation)               |客户端|                                                                                                                                设置某个entity血条的相对高度                                                                                                                                 |
|                     [SetNameDeeptest](./1-ModAPI/接口/实体/渲染.md#setnamedeeptest)                     |客户端|                                                                                                                                     设置名字是否透视                                                                                                                                     |
|                   [SetNotRenderAtAll](./1-ModAPI/接口/实体/渲染.md#setnotrenderatall)                   |客户端|                                                                                                                                    设置是否关闭实体渲染                                                                                                                                    |
|                [SetRenderLocalPlayer](./1-ModAPI/接口/实体/渲染.md#setrenderlocalplayer)                |客户端|                                                                                                                                    设置本地玩家是否渲染                                                                                                                                    |
|                         [SetShowName](./1-ModAPI/接口/实体/渲染.md#setshowname)                         |客户端|                                                                                                                             设置生物名字是否按照默认游戏逻辑显示（包括玩家）                                                                                                                             |
|                          [ShowHealth](./1-ModAPI/接口/实体/渲染.md#showhealth)                          |客户端|                                                                                                                              设置某个entity是否显示血条，默认为显示                                                                                                                              |
|                       [ShowHealthBar](./1-ModAPI/接口/实体/渲染.md#showhealthbar)                       |客户端|                                                                                                                                     设置是否显示血条                                                                                                                                     |

####  背包 ####

|                                              接口                                               |   |                          描述                          |
|-----------------------------------------------------------------------------------------------|---|------------------------------------------------------|
|       [GetEntityItem](./1-ModAPI/接口/实体/背包.md#getentityitem)       |服务端|              获取生物物品，支持获取背包，盔甲栏，副手以及主手物品              |
|   [GetEquItemEnchant](./1-ModAPI/接口/实体/背包.md#getequitemenchant)   |服务端|                     获取装备槽位中盔甲的附魔                     |
|[GetEquItemModEnchant](./1-ModAPI/接口/实体/背包.md#getequitemmodenchant)|服务端|                   获取装备槽位中盔甲的自定义附魔                    |
|       [SetEntityItem](./1-ModAPI/接口/实体/背包.md#setentityitem)       |服务端|设置生物物品，建议开发者根据生物特性来进行设置，部分生物设置装备后可能不显示但是死亡后仍然会掉落所设置的装备|

####  自定义属性 ####

|                                                接口                                                |   |                                   描述                                    |
|--------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------|
|             [GetAttr](./1-ModAPI/接口/实体/自定义属性.md#getattr)             |服务端|                             获取SetAttr设置的属性值                             |
|             [GetAttr](./1-ModAPI/接口/实体/自定义属性.md#getattr)             |客户端|                             获取SetAttr设置的属性值                             |
|  [RegisterUpdateFunc](./1-ModAPI/接口/实体/自定义属性.md#registerupdatefunc)  |客户端|                       注册属性值变换时的回调函数，当属性变化时会调用该函数                        |
|            [SaveAttr](./1-ModAPI/接口/实体/自定义属性.md#saveattr)            |服务端|                             保存SetAttr设置的属性值                             |
|             [SetAttr](./1-ModAPI/接口/实体/自定义属性.md#setattr)             |服务端|设置属性值。服务端设置后会自动同步到客户端，可以用客户端的GetAttr获取。默认不会存档，需要存档的话可以设置needRestore=True。|
|             [SetAttr](./1-ModAPI/接口/实体/自定义属性.md#setattr)             |客户端|                                设置客户端属性值                                 |
|[UnRegisterUpdateFunc](./1-ModAPI/接口/实体/自定义属性.md#unregisterupdatefunc)|客户端|                             反注册属性值变换时的回调函数                              |

####  自定义数据 ####

|                                             接口                                             |   |                                    描述                                     |
|--------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------|
|   [CleanExtraData](./1-ModAPI/接口/实体/自定义数据.md#cleanextradata)   |服务端|       清除实体的自定义数据或者世界的自定义数据，清除实体数据时使用对应实体id创建组件，清除世界数据时使用levelId创建组件       |
|     [GetExtraData](./1-ModAPI/接口/实体/自定义数据.md#getextradata)     |服务端|  获取实体的自定义数据或者世界的自定义数据，某个键所对应的值。获取实体数据时使用对应实体id创建组件，获取世界数据时使用levelId创建组件   |
|[GetWholeExtraData](./1-ModAPI/接口/实体/自定义数据.md#getwholeextradata)|服务端|     获取完整的实体的自定义数据或者世界的自定义数据，获取实体数据时使用对应实体id创建组件，获取世界数据时使用levelId创建组件      |
|    [SaveExtraData](./1-ModAPI/接口/实体/自定义数据.md#saveextradata)    |服务端|                          用于保存实体的自定义数据或者世界的自定义数据                           |
|     [SetExtraData](./1-ModAPI/接口/实体/自定义数据.md#setextradata)     |服务端|用于设置实体的自定义数据或者世界的自定义数据，数据以键值对的形式保存。设置实体数据时使用对应实体id创建组件，设置世界数据时使用levelId创建组件|

####  molang ####

|                                                接口                                                 |   |             描述             |
|---------------------------------------------------------------------------------------------------|---|----------------------------|
|[EvalMolangExpression](./1-ModAPI/接口/实体/molang.md#evalmolangexpression)|服务端|     在实体上下文上执行molang表达式     |
|[EvalMolangExpression](./1-ModAPI/接口/实体/molang.md#evalmolangexpression)|客户端|     在实体上下文上执行molang表达式     |
|                 [Get](./1-ModAPI/接口/实体/molang.md#get)                 |客户端|获取某一个实体计算节点的值，如果不存在返回注册时的默认值|
|    [GetAllProperties](./1-ModAPI/接口/实体/molang.md#getallproperties)    |服务端|          获取实体属性列表          |
|      [GetMolangValue](./1-ModAPI/接口/实体/molang.md#getmolangvalue)      |客户端|       获取实体molang变量的值       |
|     [GetStringHash64](./1-ModAPI/接口/实体/molang.md#getstringhash64)     |客户端|       返回字符串变量的hash64       |
|            [Register](./1-ModAPI/接口/实体/molang.md#register)            |客户端|          注册实体计算节点          |
|                 [Set](./1-ModAPI/接口/实体/molang.md#set)                 |客户端|       设置某一个实体计算节点的值        |
|    [SetPropertyValue](./1-ModAPI/接口/实体/molang.md#setpropertyvalue)    |服务端|          设置实体属性的值          |
|          [UnRegister](./1-ModAPI/接口/实体/molang.md#unregister)          |客户端|          注销实体计算节点          |

####  标签 ####

|                                         接口                                          |   |      描述       |
|-------------------------------------------------------------------------------------|---|---------------|
|   [AddEntityTag](./1-ModAPI/接口/实体/标签.md#addentitytag)   |服务端|    增加实体标签     |
|   [EntityHasTag](./1-ModAPI/接口/实体/标签.md#entityhastag)   |服务端|判断实体是否存在某个指定的标签|
|  [GetEntityTags](./1-ModAPI/接口/实体/标签.md#getentitytags)  |服务端|   获取实体标签列表    |
|[RemoveEntityTag](./1-ModAPI/接口/实体/标签.md#removeentitytag)|服务端|  移除实体某个指定的标签  |

####  抛射物 ####

|                                            接口                                            |   |     描述     |
|------------------------------------------------------------------------------------------|---|------------|
|[GetSourceEntityId](./1-ModAPI/接口/实体/抛射物.md#getsourceentityid)|服务端|获取抛射物发射者实体id|

####  经验球 ####

|                                           接口                                           |   |   描述   |
|----------------------------------------------------------------------------------------|---|--------|
|[GetOrbExperience](./1-ModAPI/接口/实体/经验球.md#getorbexperience)|服务端|获取经验球的经验|
|[SetOrbExperience](./1-ModAPI/接口/实体/经验球.md#setorbexperience)|服务端|设置经验球经验 |

####  官方伙伴 ####

|                                  接口                                   |   |           描述            |
|-----------------------------------------------------------------------|---|-------------------------|
|[Disable](./1-ModAPI/接口/实体/官方伙伴.md#disable)|服务端|关闭官方伙伴功能，单人游戏以及本地联机不支持该接口|
| [Enable](./1-ModAPI/接口/实体/官方伙伴.md#enable) |服务端|启用官方伙伴功能，单人游戏以及本地联机不支持该接口|

####  官方聊天扩展 ####

|                                                   接口                                                    |   |                                   描述                                    |
|---------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------|
|       [AddCommonPhrases](./1-ModAPI/接口/实体/官方聊天扩展.md#addcommonphrases)       |服务端|             为官方聊天扩展功能添加常用短语。单人模式下单个模组最多添加12条，联机大厅和网络服无条数限制。             |
|                [Disable](./1-ModAPI/接口/实体/官方聊天扩展.md#disable)                |服务端|   关闭官方聊天扩展功能。需要在ClientLoadAddonsFinishServerEvent事件中调用。仅在联机大厅和网络服中生效。   |
|                 [Enable](./1-ModAPI/接口/实体/官方聊天扩展.md#enable)                 |服务端|   启用官方聊天扩展功能。需要在ClientLoadAddonsFinishServerEvent事件中调用。仅在联机大厅和网络服中生效。   |
|     [RegisterChatPrefix](./1-ModAPI/接口/实体/官方聊天扩展.md#registerchatprefix)     |服务端|为游戏内指定玩家注册聊天前缀。仅在主界面消息框和聊天界面游戏频道生效。建议在AddServerPlayerEvent事件中调用，为新玩家添加前缀。|
|    [RemoveCommonPhrases](./1-ModAPI/接口/实体/官方聊天扩展.md#removecommonphrases)    |服务端|                            为官方聊天扩展功能移除常用短语。                             |
| [SetShowOfficialPhrases](./1-ModAPI/接口/实体/官方聊天扩展.md#setshowofficialphrases) |服务端|                     设置是否显示官方的常用聊天短语。仅在联机大厅和网络服中生效。                      |
|[SetShowSocialNearbyInfo](./1-ModAPI/接口/实体/官方聊天扩展.md#setshowsocialnearbyinfo)|服务端|                      设置是否显示官方聊天社交界面中同一游戏玩家是否在附近信息。                      |

####  魔法指令 ####

|                                  接口                                   |   |                              描述                               |
|-----------------------------------------------------------------------|---|---------------------------------------------------------------|
|[Disable](./1-ModAPI/接口/实体/魔法指令.md#disable)|服务端|关闭官方魔法指令功能。需要在ClientLoadAddonsFinishServerEvent事件中调用。仅在联机大厅中生效。|
| [Enable](./1-ModAPI/接口/实体/魔法指令.md#enable) |服务端|启用官方魔法指令功能。需要在ClientLoadAddonsFinishServerEvent事件中调用。仅在联机大厅中生效。|

####  属性 ####

|                                                           接口                                                            |   |                                                                                                        描述                                                                                                         |
|-------------------------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|              [AddPlayerExperience](./1-ModAPI/接口/玩家/属性.md#addplayerexperience)              |服务端|                                                                                                      增加玩家经验值                                                                                                      |
|                   [AddPlayerLevel](./1-ModAPI/接口/玩家/属性.md#addplayerlevel)                   |服务端|                                                                                                      修改玩家等级                                                                                                       |
|          [CollectOnlineClientData](./1-ModAPI/接口/玩家/属性.md#collectonlineclientdata)          |服务端|                                                                                              收集在线玩家客户端数据，用于判断玩家是否作弊                                                                                               |
|                    [GetArmorValue](./1-ModAPI/接口/玩家/属性.md#getarmorvalue)                    |客户端|                                                                                                      获取玩家护甲值                                                                                                      |
|               [GetEnchantmentSeed](./1-ModAPI/接口/玩家/属性.md#getenchantmentseed)               |服务端|                                                                                          获取玩家的附魔种子，该种子会决定附魔台上准备附魔的装备的附魔项                                                                                          |
|             [GetPlayerCurLevelExp](./1-ModAPI/接口/玩家/属性.md#getplayercurlevelexp)             |客户端|                                                                                                  获取玩家当前等级需要的经验值                                                                                                   |
|  [GetPlayerCurrentExhaustionValue](./1-ModAPI/接口/玩家/属性.md#getplayercurrentexhaustionvalue)  |服务端|                                                    获取玩家foodExhaustionLevel的当前消耗度。详见[消耗度介绍](https://zh.minecraft.wiki/w/%E9%A5%A5%E9%A5%BF#%E6%9C%BA%E5%88%B6)                                                     |
|                     [GetPlayerExp](./1-ModAPI/接口/玩家/属性.md#getplayerexp)                     |服务端|                                                                                                   获取玩家当前等级下的经验值                                                                                                   |
|                     [GetPlayerExp](./1-ModAPI/接口/玩家/属性.md#getplayerexp)                     |客户端|                                                                                                   获取玩家当前等级下的经验值                                                                                                   |
|             [GetPlayerHealthLevel](./1-ModAPI/接口/玩家/属性.md#getplayerhealthlevel)             |服务端|                                                                             获取玩家健康临界值，当饥饿值大于等于健康临界值时会自动恢复血量，开启饥饿值且开启自然恢复时有效。原版默认值为18                                                                              |
|              [GetPlayerHealthTick](./1-ModAPI/接口/玩家/属性.md#getplayerhealthtick)              |服务端|                                                                      获取玩家自然恢复速度，当饥饿值大于等于健康临界值时会自动恢复血量，开启饥饿值且开启自然恢复时有效。原版默认值为80刻（即每4秒）恢复1点血量                                                                       |
|                  [GetPlayerHunger](./1-ModAPI/接口/玩家/属性.md#getplayerhunger)                  |服务端|获取玩家饥饿度，展示在UI饥饿度进度条上，初始值为20，即每一个鸡腿代表2个饥饿度。 **饱和度(saturation)** ：玩家当前饱和度，初始值为5，最大值始终为玩家当前饥饿度(hunger)，该值直接影响玩家**饥饿度(hunger)**。  <br/>1）增加方法：吃食物。  <br/>2）减少方法：每触发一次**消耗事件**，该值减少1，如果该值不大于0，直接把玩家 **饥饿度(hunger)** 减少1。|
|                  [GetPlayerHunger](./1-ModAPI/接口/玩家/属性.md#getplayerhunger)                  |客户端|获取玩家饥饿度，展示在UI饥饿度进度条上，初始值为20，即每一个鸡腿代表2个饥饿度。 **饱和度(saturation)** ：玩家当前饱和度，初始值为5，最大值始终为玩家当前饥饿度(hunger)，该值直接影响玩家**饥饿度(hunger)**。  <br/>1）增加方法：吃食物。  <br/>2）减少方法：每触发一次**消耗事件**，该值减少1，如果该值不大于0，直接把玩家 **饥饿度(hunger)** 减少1。|
|                   [GetPlayerLevel](./1-ModAPI/接口/玩家/属性.md#getplayerlevel)                   |服务端|                                                                                                      获取玩家等级                                                                                                       |
|      [GetPlayerMaxExhaustionValue](./1-ModAPI/接口/玩家/属性.md#getplayermaxexhaustionvalue)      |服务端|                  获取玩家foodExhaustionLevel的归零值，常量值，默认为4。**消耗度（exhaustion）**是指玩家当前消耗度水平，初始值为0，该值会随着玩家一系列动作（如跳跃）的影响而增加，当该值大于最大消耗度（maxExhaustion）后归零，并且把饱和度（saturation）减少1（为了说明饥饿度机制，我们将此定义为**消耗事件**）                  |
|             [GetPlayerStarveLevel](./1-ModAPI/接口/玩家/属性.md#getplayerstarvelevel)             |服务端|                                                                               获取玩家饥饿临界值，当饥饿值小于饥饿临界值时会自动扣除血量，开启饥饿值且开启饥饿掉血时有效。原版默认值为1                                                                               |
|              [GetPlayerStarveTick](./1-ModAPI/接口/玩家/属性.md#getplayerstarvetick)              |服务端|                                                                       获取玩家饥饿掉血速度，当饥饿值小于饥饿临界值时会自动扣除血量，开启饥饿值且开启饥饿掉血时有效。原版默认值为80刻（即每4秒）扣除1点血量                                                                        |
|                [GetPlayerTotalExp](./1-ModAPI/接口/玩家/属性.md#getplayertotalexp)                |服务端|                                                                                                     获取玩家的总经验值                                                                                                     |
|                [GetPlayerTotalExp](./1-ModAPI/接口/玩家/属性.md#getplayertotalexp)                |客户端|                                                                                                     获取玩家的总经验值                                                                                                     |
|[IsHighLevelMultiJointOfficialSkin](./1-ModAPI/接口/玩家/属性.md#ishighlevelmultijointofficialskin)|客户端|                                                       获取玩家穿戴的皮肤是否为史诗及以上的多关节官方4d皮肤 在接收到 UpdatePlayerSkinClientEvent 事件后调用 此事件在客户端接收到玩家皮肤信息同步后触发 参数仅playerId                                                        |
|          [IsHighLevelOfficialSkin](./1-ModAPI/接口/玩家/属性.md#ishighlevelofficialskin)          |客户端|                                                         获取玩家穿戴的皮肤是否为史诗及以上的官方4d皮肤 在接收到 UpdatePlayerSkinClientEvent 事件后调用 此事件在客户端接收到玩家皮肤信息同步后触发 参数仅playerId                                                         |
|         [IsMultiJointOfficialSkin](./1-ModAPI/接口/玩家/属性.md#ismultijointofficialskin)         |客户端|                                                          获取玩家穿戴的皮肤是否为多关节官方4d皮肤 在接收到 UpdatePlayerSkinClientEvent 事件后调用 此事件在客户端接收到玩家皮肤信息同步后触发 参数仅playerId                                                           |
|                   [IsOfficialSkin](./1-ModAPI/接口/玩家/属性.md#isofficialskin)                   |客户端|                                                            获取玩家穿戴的皮肤是否为官方4d皮肤 在接收到 UpdatePlayerSkinClientEvent 事件后调用 此事件在客户端接收到玩家皮肤信息同步后触发 参数仅playerId                                                            |
|             [IsPlayerNaturalRegen](./1-ModAPI/接口/玩家/属性.md#isplayernaturalregen)             |服务端|                                                                              是否开启玩家自然恢复，当饥饿值大于等于健康临界值时会自动恢复血量，开启饥饿值且开启自然恢复时有效。原版默认开启                                                                              |
|            [IsPlayerNaturalStarve](./1-ModAPI/接口/玩家/属性.md#isplayernaturalstarve)            |服务端|                                                                               是否开启玩家饥饿掉血，当饥饿值小于饥饿临界值时会自动恢复血量，开启饥饿值且开启饥饿掉血时有效。原版默认开启                                                                               |
|               [SetEnchantmentSeed](./1-ModAPI/接口/玩家/属性.md#setenchantmentseed)               |服务端|                                                                                          设置玩家的附魔种子，该种子会决定附魔台上准备附魔的装备的附魔项                                                                                          |
|  [SetPlayerCurrentExhaustionValue](./1-ModAPI/接口/玩家/属性.md#setplayercurrentexhaustionvalue)  |服务端|                                                    设置玩家foodExhaustionLevel的当前消耗度。详见[消耗度介绍](https://zh.minecraft.wiki/w/%E9%A5%A5%E9%A5%BF#%E6%9C%BA%E5%88%B6)                                                     |
|             [SetPlayerHealthLevel](./1-ModAPI/接口/玩家/属性.md#setplayerhealthlevel)             |服务端|                                                                             设置玩家健康临界值，当饥饿值大于等于健康临界值时会自动恢复血量，开启饥饿值且开启自然恢复时有效.原版默认值为18                                                                              |
|              [SetPlayerHealthTick](./1-ModAPI/接口/玩家/属性.md#setplayerhealthtick)              |服务端|                                                                      设置玩家自然恢复速度，当饥饿值大于等于健康临界值时会自动恢复血量，开启饥饿值且开启自然恢复时有效.原版默认值为80刻（即每4秒）恢复1点血量                                                                       |
|                  [SetPlayerHunger](./1-ModAPI/接口/玩家/属性.md#setplayerhunger)                  |服务端|                                                                                                     设置玩家饥饿度。                                                                                                      |
|      [SetPlayerMaxExhaustionValue](./1-ModAPI/接口/玩家/属性.md#setplayermaxexhaustionvalue)      |服务端|                                      设置玩家**最大消耗度(maxExhaustion)**，通过调整 **最大消耗度(maxExhaustion)** 的大小，就可以调整 **饥饿度(hunger)** 的消耗速度，当 **最大消耗度(maxExhaustion)** 很大时，饥饿度可以看似一直不下降                                       |
|            [SetPlayerNaturalRegen](./1-ModAPI/接口/玩家/属性.md#setplayernaturalregen)            |服务端|                                                                             设置是否开启玩家自然恢复，当饥饿值大于等于健康临界值时会自动恢复血量，开启饥饿值且开启自然恢复时有效.原版默认开启                                                                             |
|           [SetPlayerNaturalStarve](./1-ModAPI/接口/玩家/属性.md#setplayernaturalstarve)           |服务端|                                                                              设置是否开启玩家饥饿掉血，当饥饿值小于饥饿临界值时会自动扣除血量，开启饥饿值且开启饥饿掉血时有效.原版默认开启                                                                              |
|     [SetPlayerPrefixAndSuffixName](./1-ModAPI/接口/玩家/属性.md#setplayerprefixandsuffixname)     |服务端|                                                                                                    设置玩家前缀和后缀名字                                                                                                    |
|             [SetPlayerStarveLevel](./1-ModAPI/接口/玩家/属性.md#setplayerstarvelevel)             |服务端|                                                                               设置玩家饥饿临界值，当饥饿值小于饥饿临界值时会自动扣除血量，开启饥饿值且开启饥饿掉血时有效。原版默认值为1                                                                               |
|              [SetPlayerStarveTick](./1-ModAPI/接口/玩家/属性.md#setplayerstarvetick)              |服务端|                                                                       设置玩家饥饿掉血速度，当饥饿值小于饥饿临界值时会自动扣除血量，开启饥饿值且开启饥饿掉血时有效.原版默认值为80刻（即每4秒）扣除1点血量                                                                        |
|                [SetPlayerTotalExp](./1-ModAPI/接口/玩家/属性.md#setplayertotalexp)                |服务端|                                                                                                     设置玩家的总经验值                                                                                                     |
|                            [Swing](./1-ModAPI/接口/玩家/属性.md#swing)                            |客户端|                                                                                                   本地玩家播放原版攻击动作                                                                                                    |
|                           [getUid](./1-ModAPI/接口/玩家/属性.md#getuid)                           |客户端|                                                                                                    获取本地玩家的uid                                                                                                     |

####  行为 ####

|                                                        接口                                                         |   |                                                          描述                                                          |
|-------------------------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------------------------------------------|
|   [AddPlayerAroundEntityMotion](./1-ModAPI/接口/玩家/行为.md#addplayeraroundentitymotion)   |服务端|                                                    给玩家添加对实体环绕运动器                                                     |
|    [AddPlayerAroundPointMotion](./1-ModAPI/接口/玩家/行为.md#addplayeraroundpointmotion)    |服务端|                                                     给玩家添加对点环绕运动器                                                     |
|          [AddPlayerTrackMotion](./1-ModAPI/接口/玩家/行为.md#addplayertrackmotion)          |服务端|                                                      给玩家添加轨迹运动器                                                      |
|       [AddPlayerVelocityMotion](./1-ModAPI/接口/玩家/行为.md#addplayervelocitymotion)       |服务端|                                                      给玩家添加速度运动器                                                      |
|                [BeginSprinting](./1-ModAPI/接口/玩家/行为.md#beginsprinting)                |客户端|                                                 使本地玩家进入并保持向前疾跑/冲刺状态                                                  |
|         [ChangePlayerDimension](./1-ModAPI/接口/玩家/行为.md#changeplayerdimension)         |服务端|                                                         传送玩家                                                         |
|          [ChangePlayerFlyState](./1-ModAPI/接口/玩家/行为.md#changeplayerflystate)          |服务端|                                          给予/取消飞行能力, 并根据enterFly参数确定是否进入飞行状态                                          |
|           [EnableKeepInventory](./1-ModAPI/接口/玩家/行为.md#enablekeepinventory)           |服务端|                                                     设置玩家死亡不掉落物品                                                      |
|                  [EndSprinting](./1-ModAPI/接口/玩家/行为.md#endsprinting)                  |客户端|                                                   使本地玩家结束向前疾跑/冲刺状态                                                   |
|                [GetEntityRider](./1-ModAPI/接口/玩家/行为.md#getentityrider)                |服务端|                                                   获取骑乘者正在骑乘的实体的id。                                                   |
|                [GetEntityRider](./1-ModAPI/接口/玩家/行为.md#getentityrider)                |客户端|                                                   获取骑乘者正在骑乘的实体的id。                                                   |
|      [GetInteracteCenterOffset](./1-ModAPI/接口/玩家/行为.md#getinteractecenteroffset)      |服务端|获取玩家服务端交互中心的偏移，对应使用[SetPickCenterOffset](./1-ModAPI/接口/玩家/行为.md#setpickcenteroffset)修改的偏移值|
|                 [GetIsBlocking](./1-ModAPI/接口/玩家/行为.md#getisblocking)                 |服务端|                                                      获取玩家激活盾牌状态                                                      |
|           [GetPickCenterOffset](./1-ModAPI/接口/玩家/行为.md#getpickcenteroffset)           |客户端|                                                获取玩家设置的第三人称下客户端交互中心的偏移                                                |
|                  [GetPickRange](./1-ModAPI/接口/玩家/行为.md#getpickrange)                  |客户端|                                                     获取玩家客户端的交互距离                                                     |
|     [GetPlayerDestroyTotalTime](./1-ModAPI/接口/玩家/行为.md#getplayerdestroytotaltime)     |服务端|                                   获取玩家破坏方块需要的时间，受玩家状态（急迫、潮涌、挖掘疲劳）和手持物及手持物附魔（效率）影响                                    |
|     [GetPlayerDestroyTotalTime](./1-ModAPI/接口/玩家/行为.md#getplayerdestroytotaltime)     |客户端|                                   获取玩家破坏方块需要的时间，受玩家状态（急迫、潮涌、挖掘疲劳）和手持物及手持物附魔（效率）影响                                    |
|[GetPlayerExhaustionRatioByType](./1-ModAPI/接口/玩家/行为.md#getplayerexhaustionratiobytype)|服务端|                                                    获取玩家某行为饥饿度消耗倍率                                                    |
|       [GetPlayerInteracteRange](./1-ModAPI/接口/玩家/行为.md#getplayerinteracterange)       |服务端|                                                     获取玩家服务端的交互距离                                                     |
|            [GetPlayerIsFishing](./1-ModAPI/接口/玩家/行为.md#getplayerisfishing)            |服务端|                                                      获取玩家是否在钓鱼                                                       |
|            [GetPlayerIsFishing](./1-ModAPI/接口/玩家/行为.md#getplayerisfishing)            |客户端|                                                      获取玩家是否在钓鱼                                                       |
|              [GetPlayerMotions](./1-ModAPI/接口/玩家/行为.md#getplayermotions)              |服务端|                                                     获取玩家身上的所有运动器                                                     |
|           [GetPlayerRespawnPos](./1-ModAPI/接口/玩家/行为.md#getplayerrespawnpos)           |服务端|                                                       获取玩家复活点                                                        |
|             [GetRelevantPlayer](./1-ModAPI/接口/玩家/行为.md#getrelevantplayer)             |服务端|                                                      获取附近玩家id列表                                                      |
|                [IsEntityRiding](./1-ModAPI/接口/玩家/行为.md#isentityriding)                |服务端|                                                      检查玩家是否骑乘。                                                       |
|               [IsInScaffolding](./1-ModAPI/接口/玩家/行为.md#isinscaffolding)               |客户端|                                                     获取玩家是否在脚手架中                                                      |
|                    [IsOnLadder](./1-ModAPI/接口/玩家/行为.md#isonladder)                    |客户端|                                                    获取玩家是否在梯子/藤蔓上                                                     |
|                [IsPlayerCanFly](./1-ModAPI/接口/玩家/行为.md#isplayercanfly)                |服务端|                                                       获取玩家能否飞行                                                       |
|                [IsPlayerFlying](./1-ModAPI/接口/玩家/行为.md#isplayerflying)                |服务端|                                                      获取玩家是否在飞行                                                       |
|          [OpenNeteaseContainer](./1-ModAPI/接口/玩家/行为.md#openneteasecontainer)          |服务端|                                         打开自定义容器界面，不依赖于方块。该界面的物品数据需由开发者自行维护。                                          |
|                 [OpenWorkBench](./1-ModAPI/接口/玩家/行为.md#openworkbench)                 |服务端|                                               在玩家当前位置打开工作台UI，不依赖于工作台方块                                               |
|              [PickUpItemEntity](./1-ModAPI/接口/玩家/行为.md#pickupitementity)              |服务端|                                                某个Player拾取物品ItemEntity                                                |
|            [PlayerAttackEntity](./1-ModAPI/接口/玩家/行为.md#playerattackentity)            |服务端|                                                    玩家使用手持武器攻击某个生物                                                    |
|            [PlayerDestroyBlock](./1-ModAPI/接口/玩家/行为.md#playerdestroyblock)            |服务端|                                                      使用手上工具破坏方块                                                      |
|         [PlayerUseItemToEntity](./1-ModAPI/接口/玩家/行为.md#playeruseitemtoentity)         |服务端|                                                   玩家使用手上物品对某个生物使用                                                    |
|            [PlayerUseItemToPos](./1-ModAPI/接口/玩家/行为.md#playeruseitemtopos)            |服务端|                                                    模拟玩家对某个坐标使用物品                                                     |
|            [RemovePlayerMotion](./1-ModAPI/接口/玩家/行为.md#removeplayermotion)            |服务端|                                                      移除玩家身上的运动器                                                      |
|           [SetBanPlayerFishing](./1-ModAPI/接口/玩家/行为.md#setbanplayerfishing)           |服务端|                                         设置是否屏蔽玩家钓鱼功能，屏蔽后玩家可以正常抛甩鱼竿，但无法钓起任何物品                                         |
|      [SetInteracteCenterOffset](./1-ModAPI/接口/玩家/行为.md#setinteractecenteroffset)      |服务端|                                                    设置玩家服务端交互中心的偏移                                                    |
|           [SetPickCenterOffset](./1-ModAPI/接口/玩家/行为.md#setpickcenteroffset)           |客户端|                                                 设置第三人称下，玩家客户端交互中心的偏移                                                 |
|                  [SetPickRange](./1-ModAPI/接口/玩家/行为.md#setpickrange)                  |客户端|                                                     设置玩家客户端的交互距离                                                     |
|                 [SetPickUpArea](./1-ModAPI/接口/玩家/行为.md#setpickuparea)                 |服务端|                                      设置玩家的拾取物品范围，设置后该玩家的拾取物品范围会在原版拾取范围的基础上进行改变。                                      |
| [SetPlayerAttackSpeedAmplifier](./1-ModAPI/接口/玩家/行为.md#setplayerattackspeedamplifier) |服务端|                                    设置玩家攻击速度倍数，1.0表示正常水平，1.2表示速度减益20%，0.8表示速度增益20%                                    |
|[SetPlayerExhaustionRatioByType](./1-ModAPI/接口/玩家/行为.md#setplayerexhaustionratiobytype)|服务端|                                                    设置玩家某行为饥饿度消耗倍率                                                    |
|       [SetPlayerInteracteRange](./1-ModAPI/接口/玩家/行为.md#setplayerinteracterange)       |服务端|                                                     设置玩家服务端的交互距离                                                     |
|             [SetPlayerJumpable](./1-ModAPI/接口/玩家/行为.md#setplayerjumpable)             |服务端|                                                      设置玩家是否可跳跃                                                       |
|               [SetPlayerMotion](./1-ModAPI/接口/玩家/行为.md#setplayermotion)               |服务端|                                           设置玩家的瞬时移动方向向量(可解决SetMotion闪现问题)                                            |
|              [SetPlayerMovable](./1-ModAPI/接口/玩家/行为.md#setplayermovable)              |服务端|                                                      设置玩家是否可移动                                                       |
|           [SetPlayerRespawnPos](./1-ModAPI/接口/玩家/行为.md#setplayerrespawnpos)           |服务端|                                                     设置玩家复活的位置与维度                                                     |
|             [StartPlayerMotion](./1-ModAPI/接口/玩家/行为.md#startplayermotion)             |服务端|                                                     启动玩家身上的某个运动器                                                     |
|              [StopPlayerMotion](./1-ModAPI/接口/玩家/行为.md#stopplayermotion)              |服务端|                                                     停止玩家身上的某个运动器                                                     |
|                     [isGliding](./1-ModAPI/接口/玩家/行为.md#isgliding)                     |客户端|                                                        是否鞘翅飞行                                                        |
|                     [isInWater](./1-ModAPI/接口/玩家/行为.md#isinwater)                     |客户端|                                                        是否在水中                                                         |
|                      [isMoving](./1-ModAPI/接口/玩家/行为.md#ismoving)                      |客户端|                                                        是否在行走                                                         |
|                      [isRiding](./1-ModAPI/接口/玩家/行为.md#isriding)                      |客户端|                                                         是否骑乘                                                         |
|                    [isSneaking](./1-ModAPI/接口/玩家/行为.md#issneaking)                    |服务端|                                                     获取玩家是否处于潜行状态                                                     |
|                    [isSneaking](./1-ModAPI/接口/玩家/行为.md#issneaking)                    |客户端|                                                         是否潜行                                                         |
|                   [isSprinting](./1-ModAPI/接口/玩家/行为.md#issprinting)                   |客户端|                                                        是否在疾跑                                                         |
|                    [isSwimming](./1-ModAPI/接口/玩家/行为.md#isswimming)                    |服务端|                                                    获取玩家是否处于游泳状态。                                                     |
|                    [isSwimming](./1-ModAPI/接口/玩家/行为.md#isswimming)                    |客户端|                                                         是否游泳                                                         |
|                     [setMoving](./1-ModAPI/接口/玩家/行为.md#setmoving)                     |客户端|                                               设置是否行走，只能设置本地玩家（只适用于移动端）                                               |
|                   [setSneaking](./1-ModAPI/接口/玩家/行为.md#setsneaking)                   |客户端|                                               设置是否潜行，只能设置本地玩家（只适用于移动端）                                               |
|                  [setSprinting](./1-ModAPI/接口/玩家/行为.md#setsprinting)                  |客户端|                                            设置行走模式为疾跑/冲刺，只能设置本地玩家（只适用于移动端）                                            |
|                [setUsingShield](./1-ModAPI/接口/玩家/行为.md#setusingshield)                |客户端|                                                        激活盾牌状态                                                        |

####  渲染 ####

|                                                         接口                                                          |   |                                         描述                                         |
|---------------------------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------|
|             [AddPlayerAnimation](./1-ModAPI/接口/玩家/渲染.md#addplayeranimation)             |客户端|                                      增加玩家渲染动画                                      |
|   [AddPlayerAnimationController](./1-ModAPI/接口/玩家/渲染.md#addplayeranimationcontroller)   |客户端|                                    增加玩家渲染动画控制器                                     |
|    [AddPlayerAnimationIntoState](./1-ModAPI/接口/玩家/渲染.md#addplayeranimationintostate)    |客户端|                              在玩家的动画控制器中的状态添加动画或者动画控制器                              |
|              [AddPlayerGeometry](./1-ModAPI/接口/玩家/渲染.md#addplayergeometry)              |客户端|                                     增加玩家渲染几何体                                      |
|        [AddPlayerParticleEffect](./1-ModAPI/接口/玩家/渲染.md#addplayerparticleeffect)        |客户端|                                      增加玩家特效资源                                      |
|      [AddPlayerRenderController](./1-ModAPI/接口/玩家/渲染.md#addplayerrendercontroller)      |客户端|增加玩家[渲染控制器](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_7-自定义渲染控制器)|
|        [AddPlayerRenderMaterial](./1-ModAPI/接口/玩家/渲染.md#addplayerrendermaterial)        |客户端|增加玩家渲染需要的[材质](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_3-自定义材质) |
|         [AddPlayerScriptAnimate](./1-ModAPI/接口/玩家/渲染.md#addplayerscriptanimate)         |客户端|       在玩家的客户端实体定义（minecraft:client\_entity）json中的scripts/animate节点添加动画/动画控制器       |
|           [AddPlayerSoundEffect](./1-ModAPI/接口/玩家/渲染.md#addplayersoundeffect)           |客户端|                                      增加玩家音效资源                                      |
|               [AddPlayerTexture](./1-ModAPI/接口/玩家/渲染.md#addplayertexture)               |客户端|                                      增加玩家渲染贴图                                      |
|            [RebuildPlayerRender](./1-ModAPI/接口/玩家/渲染.md#rebuildplayerrender)            |客户端|                                     重建玩家的数据渲染器                                     |
|[RemovePlayerAnimationController](./1-ModAPI/接口/玩家/渲染.md#removeplayeranimationcontroller)|客户端|                                    移除玩家渲染动画控制器                                     |
|           [RemovePlayerGeometry](./1-ModAPI/接口/玩家/渲染.md#removeplayergeometry)           |客户端|                                     删除玩家渲染几何体                                      |
|   [RemovePlayerRenderController](./1-ModAPI/接口/玩家/渲染.md#removeplayerrendercontroller)   |客户端|删除玩家[渲染控制器](../../../mcguide/20-玩法开发/15-自定义游戏内容/3-自定义生物/01-自定义基础生物.html#_7-自定义渲染控制器)|
|                      [ResetSkin](./1-ModAPI/接口/玩家/渲染.md#resetskin)                      |客户端|                                       还原默认皮肤                                       |
|     [SetPlayerItemInHandVisible](./1-ModAPI/接口/玩家/渲染.md#setplayeriteminhandvisible)     |客户端|                                 设置是否隐藏玩家的手持物品模型显示                                  |
|                        [SetSkin](./1-ModAPI/接口/玩家/渲染.md#setskin)                        |客户端|                                     更换原版自定义皮肤                                      |

####  背包 ####

|                                                        接口                                                         |   |                     描述                      |
|-------------------------------------------------------------------------------------------------------------------|---|---------------------------------------------|
|           [AddEnchantToInvItem](./1-ModAPI/接口/玩家/背包.md#addenchanttoinvitem)           |服务端|                给物品栏的物品添加附魔信息                |
|        [AddModEnchantToInvItem](./1-ModAPI/接口/玩家/背包.md#addmodenchanttoinvitem)        |服务端|              给物品栏中物品添加自定义附魔信息               |
|[ChangePlayerItemTipsAndExtraId](./1-ModAPI/接口/玩家/背包.md#changeplayeritemtipsandextraid)|服务端|            修改玩家物品的自定义tips和自定义标识符            |
|              [ChangeSelectSlot](./1-ModAPI/接口/玩家/背包.md#changeselectslot)              |服务端|             设置玩家当前选中快捷栏物品的index             |
|                [GetCarriedItem](./1-ModAPI/接口/玩家/背包.md#getcarrieditem)                |客户端|                  获取右手物品的信息                  |
|         [GetInvItemEnchantData](./1-ModAPI/接口/玩家/背包.md#getinvitemenchantdata)         |服务端|                获取物品栏的物品附魔信息                 |
|      [GetInvItemModEnchantData](./1-ModAPI/接口/玩家/背包.md#getinvitemmodenchantdata)      |服务端|               获取物品栏的物品自定义附魔信息               |
|                [GetOffhandItem](./1-ModAPI/接口/玩家/背包.md#getoffhanditem)                |客户端|                  获取左手物品的信息                  |
|             [GetPlayerAllItems](./1-ModAPI/接口/玩家/背包.md#getplayerallitems)             |服务端|              获取玩家指定的槽位的批量物品信息               |
|             [GetPlayerAllItems](./1-ModAPI/接口/玩家/背包.md#getplayerallitems)             |客户端|获取玩家指定的槽位的批量物品信息，支持获取盔甲栏，副手以及主手物品，背包物品仅支持本地玩家|
|       [GetPlayerFishHookEntity](./1-ModAPI/接口/玩家/背包.md#getplayerfishhookentity)       |服务端|               获取玩家钓鱼时候的鱼漂实体id               |
|       [GetPlayerFishHookEntity](./1-ModAPI/接口/玩家/背包.md#getplayerfishhookentity)       |客户端|               获取玩家钓鱼时候的鱼漂实体id               |
|             [GetPlayerFishItem](./1-ModAPI/接口/玩家/背包.md#getplayerfishitem)             |服务端|               获取玩家钓鱼时候的鱼竿物品字典               |
|             [GetPlayerFishItem](./1-ModAPI/接口/玩家/背包.md#getplayerfishitem)             |客户端|               获取玩家钓鱼时候的鱼竿物品字典               |
|                 [GetPlayerItem](./1-ModAPI/接口/玩家/背包.md#getplayeritem)                 |服务端|         获取玩家物品，支持获取背包，盔甲栏，副手以及主手物品          |
|                 [GetPlayerItem](./1-ModAPI/接口/玩家/背包.md#getplayeritem)                 |客户端|      获取玩家物品，支持获取背包（本地玩家），盔甲栏，副手以及主手物品       |
|               [GetSelectSlotId](./1-ModAPI/接口/玩家/背包.md#getselectslotid)               |服务端|                 获取玩家当前选中槽位                  |
|                     [GetSlotId](./1-ModAPI/接口/玩家/背包.md#getslotid)                     |客户端|               获取当前手持的快捷栏的槽id                |
|        [RemoveEnchantToInvItem](./1-ModAPI/接口/玩家/背包.md#removeenchanttoinvitem)        |服务端|                给物品栏的物品移除附魔信息                |
|     [RemoveModEnchantToInvItem](./1-ModAPI/接口/玩家/背包.md#removemodenchanttoinvitem)     |服务端|              给物品栏中物品移除自定义附魔信息               |
|            [SetInvItemExchange](./1-ModAPI/接口/玩家/背包.md#setinvitemexchange)            |服务端|                  交换玩家背包物品                   |
|                 [SetInvItemNum](./1-ModAPI/接口/玩家/背包.md#setinvitemnum)                 |服务端|                 设置玩家背包物品数目                  |
|             [SetPlayerAllItems](./1-ModAPI/接口/玩家/背包.md#setplayerallitems)             |服务端|                添加批量物品信息到指定槽位                |
|      [SpawnItemToPlayerCarried](./1-ModAPI/接口/玩家/背包.md#spawnitemtoplayercarried)      |服务端|                  生成物品到玩家右手                  |
|          [SpawnItemToPlayerInv](./1-ModAPI/接口/玩家/背包.md#spawnitemtoplayerinv)          |服务端|                  生成物品到玩家背包                  |

####  摄像机 ####

|                                                      接口                                                      |   |                                   描述                                    |
|--------------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------|
|[AddCameraAroundEntityMotion](./1-ModAPI/接口/玩家/摄像机.md#addcameraaroundentitymotion)|客户端|                              给相机添加对实体环绕运动器                              |
| [AddCameraAroundPointMotion](./1-ModAPI/接口/玩家/摄像机.md#addcameraaroundpointmotion) |客户端|                              给相机添加对点环绕运动器                               |
|       [AddCameraTrackMotion](./1-ModAPI/接口/玩家/摄像机.md#addcameratrackmotion)       |客户端|                               给相机添加轨迹运动器                                |
|    [AddCameraVelocityMotion](./1-ModAPI/接口/玩家/摄像机.md#addcameravelocitymotion)    |客户端|                               给相机添加速度运动器                                |
|               [DepartCamera](./1-ModAPI/接口/玩家/摄像机.md#departcamera)               |客户端|                                分离玩家与摄像机                                 |
|            [GetCameraAnchor](./1-ModAPI/接口/玩家/摄像机.md#getcameraanchor)            |客户端|                                 获取相机锚点                                  |
|           [GetCameraMotions](./1-ModAPI/接口/玩家/摄像机.md#getcameramotions)           |客户端|                               获取相机上的所有运动器                               |
|            [GetCameraOffset](./1-ModAPI/接口/玩家/摄像机.md#getcameraoffset)            |客户端|                                获取摄像机偏移量                                 |
|        [GetCameraPitchLimit](./1-ModAPI/接口/玩家/摄像机.md#getcamerapitchlimit)        |客户端|                              获取摄像机上下角度限制值                               |
|          [GetCameraRotation](./1-ModAPI/接口/玩家/摄像机.md#getcamerarotation)          |客户端|                                获取摄像机的朝向                                 |
|                 [GetForward](./1-ModAPI/接口/玩家/摄像机.md#getforward)                 |客户端|                                返回相机向前的方向                                |
|                     [GetFov](./1-ModAPI/接口/玩家/摄像机.md#getfov)                     |客户端|                                 获取视野大小                                  |
|                [GetFpHeight](./1-ModAPI/接口/玩家/摄像机.md#getfpheight)                |客户端|            获取本地玩家当前状态下，第一人称视角时的摄像机高度偏移量。游泳时，滑翔时以及普通状态下会有所不同             |
|             [GetPerspective](./1-ModAPI/接口/玩家/摄像机.md#getperspective)             |客户端|                                获取当前的视角模式                                |
|                [GetPosition](./1-ModAPI/接口/玩家/摄像机.md#getposition)                |客户端|                                 返回相机中心                                  |
|       [IsModCameraLockPitch](./1-ModAPI/接口/玩家/摄像机.md#ismodcameralockpitch)       |客户端|                               是否锁定摄像机上下角度                               |
|         [IsModCameraLockYaw](./1-ModAPI/接口/玩家/摄像机.md#ismodcameralockyaw)         |客户端|                               是否锁定摄像机左右角度                               |
|                 [LockCamera](./1-ModAPI/接口/玩家/摄像机.md#lockcamera)                 |客户端|                                  锁定摄像机                                  |
|         [LockModCameraPitch](./1-ModAPI/接口/玩家/摄像机.md#lockmodcamerapitch)         |客户端|                     锁定摄像机上下角度（第三人称下生效，锁定后不能上下调整视角）                      |
|           [LockModCameraYaw](./1-ModAPI/接口/玩家/摄像机.md#lockmodcamerayaw)           |客户端|                   锁定摄像机左右角度（第三人称下生效，锁定后不能通过鼠标左右调整视角）                    |
|            [LockPerspective](./1-ModAPI/接口/玩家/摄像机.md#lockperspective)            |客户端|                                锁定玩家的视角模式                                |
|         [RemoveCameraMotion](./1-ModAPI/接口/玩家/摄像机.md#removecameramotion)         |客户端|                               移除相机上的某个运动器                               |
|     [ResetCameraBindActorId](./1-ModAPI/接口/玩家/摄像机.md#resetcamerabindactorid)     |客户端|                              将摄像机重新绑定回主角身上                              |
|             [ResetCameraPos](./1-ModAPI/接口/玩家/摄像机.md#resetcamerapos)             |客户端|              重置相机位置模式，使相机恢复跟随玩家。用于取消SetCameraPos设置的独立相机位置。              |
|            [SetCameraAnchor](./1-ModAPI/接口/玩家/摄像机.md#setcameraanchor)            |客户端|                                 设置相机锚点                                  |
|       [SetCameraBindActorId](./1-ModAPI/接口/玩家/摄像机.md#setcamerabindactorid)       |客户端|将摄像机绑定到目标实体身上（调用者与目标必须在同一个dimension，同时需要在加载范围之内，若绑定后目标离开了范围或者死亡，则会自动解除绑定）|
|     [SetCameraDistanceFixed](./1-ModAPI/接口/玩家/摄像机.md#setcameradistancefixed)     |客户端|                    设置相机弹簧臂固定，即设置当相机遇到阻挡时是否压缩与人物之间的距离                    |
|            [SetCameraOffset](./1-ModAPI/接口/玩家/摄像机.md#setcameraoffset)            |客户端|                                设置摄像机偏移量                                 |
|        [SetCameraPitchLimit](./1-ModAPI/接口/玩家/摄像机.md#setcamerapitchlimit)        |客户端|                        设置摄像机上下角度限制值，默认是（-90，90）                         |
|               [SetCameraPos](./1-ModAPI/接口/玩家/摄像机.md#setcamerapos)               |客户端|                                设置相机中心的位置                                |
|          [SetCameraRotation](./1-ModAPI/接口/玩家/摄像机.md#setcamerarotation)          |客户端|                                设定摄像机的朝向                                 |
|                     [SetFov](./1-ModAPI/接口/玩家/摄像机.md#setfov)                     |客户端|                                 设置视野大小                                  |
|             [SetPerspective](./1-ModAPI/接口/玩家/摄像机.md#setperspective)             |客户端|                                 设置视角模式                                  |
|          [SetPlayerFovScale](./1-ModAPI/接口/玩家/摄像机.md#setplayerfovscale)          |客户端|        将渲染实际使用的fov变为设置中的fov乘以fovScale,fovScale越接近0，其效果越接近原版望远镜效果        |
|            [SetSpeedFovLock](./1-ModAPI/接口/玩家/摄像机.md#setspeedfovlock)            |客户端|                        是否锁定相机视野fov，锁定后不随速度变化而变化                         |
|          [StartCameraMotion](./1-ModAPI/接口/玩家/摄像机.md#startcameramotion)          |客户端|                               启动相机上的某个运动器                               |
|           [StopCameraMotion](./1-ModAPI/接口/玩家/摄像机.md#stopcameramotion)           |客户端|                               停止相机上的某个运动器                               |
|             [UnDepartCamera](./1-ModAPI/接口/玩家/摄像机.md#undepartcamera)             |客户端|                                绑定玩家与摄像机                                 |
|               [UnLockCamera](./1-ModAPI/接口/玩家/摄像机.md#unlockcamera)               |客户端|                                 解除摄像机锁定                                 |

####  动画 ####

|                                         接口                                          |   |      描述      |
|-------------------------------------------------------------------------------------|---|--------------|
|[PlayTpAnimation](./1-ModAPI/接口/玩家/动画.md#playtpanimation)|客户端|第三人称视角播放玩家通用动作|
|  [StopAnimation](./1-ModAPI/接口/玩家/动画.md#stopanimation)  |客户端|  停止播放玩家通用动作  |

####  游戏模式 ####

|                                            接口                                             |   |    描述     |
|-------------------------------------------------------------------------------------------|---|-----------|
|[GetPlayerGameType](./1-ModAPI/接口/玩家/游戏模式.md#getplayergametype)|服务端|获取指定玩家的游戏模式|
|[GetPlayerGameType](./1-ModAPI/接口/玩家/游戏模式.md#getplayergametype)|客户端|获取指定玩家的游戏模式|
|[SetPlayerGameType](./1-ModAPI/接口/玩家/游戏模式.md#setplayergametype)|服务端|设置玩家个人游戏模式 |

####  权限 ####

|                                                           接口                                                            |   |             描述              |
|-------------------------------------------------------------------------------------------------------------------------|---|-----------------------------|
|               [GetPlayerAbilities](./1-ModAPI/接口/玩家/权限.md#getplayerabilities)               |服务端|          获取玩家具体权限           |
|               [GetPlayerOperation](./1-ModAPI/接口/玩家/权限.md#getplayeroperation)               |服务端|         获取玩家权限类型信息          |
|             [SetAttackMobsAbility](./1-ModAPI/接口/玩家/权限.md#setattackmobsability)             |服务端|         设置玩家能否攻击生物          |
|          [SetAttackPlayersAbility](./1-ModAPI/接口/玩家/权限.md#setattackplayersability)          |服务端|        设置玩家能否攻击其他玩家         |
|                  [SetBuildAbility](./1-ModAPI/接口/玩家/权限.md#setbuildability)                  |服务端|设置玩家能否放置方块，该接口的设置会存档，且只影响生存模式|
|                   [SetMineAbility](./1-ModAPI/接口/玩家/权限.md#setmineability)                   |服务端|设置玩家能否摧毁方块，该接口的设置会存档，且只影响生存模式|
|         [SetOpenContainersAbility](./1-ModAPI/接口/玩家/权限.md#setopencontainersability)         |服务端|         设置玩家能否打开容器          |
|[SetOperateDoorsAndSwitchesAbility](./1-ModAPI/接口/玩家/权限.md#setoperatedoorsandswitchesability)|服务端|        设置玩家能否与门和开关交互        |
|        [SetOperatorCommandAbility](./1-ModAPI/接口/玩家/权限.md#setoperatorcommandability)        |服务端|       设置玩家是否具有操作员命令权限       |
|               [SetPermissionLevel](./1-ModAPI/接口/玩家/权限.md#setpermissionlevel)               |服务端|          设置玩家权限等级           |
|                    [SetPlayerMute](./1-ModAPI/接口/玩家/权限.md#setplayermute)                    |服务端|     设置玩家是否禁言，该接口的设置不存档      |
|               [SetTeleportAbility](./1-ModAPI/接口/玩家/权限.md#setteleportability)               |服务端|        设置玩家能否使用TP指令         |

####  导航 ####

|                                    接口                                     |   |                                描述                                 |
|---------------------------------------------------------------------------|---|-------------------------------------------------------------------|
|[GetNavPath](./1-ModAPI/接口/玩家/导航.md#getnavpath)|客户端|               获取本地玩家到目标点的寻路路径，开发者可以通过该接口定制自定义的导航系统。               |
|[StartNavTo](./1-ModAPI/接口/玩家/导航.md#startnavto)|客户端|我们提供了一个基于GetNavPath的导航系统实现，做法是在路径上生成序列帧以引导玩家通向目标点，并且当玩家偏离路径会重新进行导航。|
|   [StopNav](./1-ModAPI/接口/玩家/导航.md#stopnav)   |客户端|                              终止当前的导航                              |

####  方块状态与附加值 ####

|                                                       接口                                                        |   |                                            描述                                            |
|-----------------------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------------|
|[GetBlockAuxValueFromStates](./1-ModAPI/接口/方块/方块状态与附加值.md#getblockauxvaluefromstates)|服务端|根据方块名称和[方块状态](../../../mcguide/20-玩法开发/10-基本概念/1-我的世界基础概念.html#物品信息字典#方块状态)获取方块附加值AuxValue|
|            [GetBlockStates](./1-ModAPI/接口/方块/方块状态与附加值.md#getblockstates)            |服务端|          获取[方块状态](../../../mcguide/20-玩法开发/10-基本概念/1-我的世界基础概念.html#物品信息字典#方块状态)          |
|[GetBlockStatesFromAuxValue](./1-ModAPI/接口/方块/方块状态与附加值.md#getblockstatesfromauxvalue)|服务端|根据方块名称和方块附加值AuxValue获取[方块状态](../../../mcguide/20-玩法开发/10-基本概念/1-我的世界基础概念.html#物品信息字典#方块状态)|
|            [SetBlockStates](./1-ModAPI/接口/方块/方块状态与附加值.md#setblockstates)            |服务端|          设置[方块状态](../../../mcguide/20-玩法开发/10-基本概念/1-我的世界基础概念.html#物品信息字典#方块状态)          |

####  属性 ####

|                                           接口                                            |   |          描述          |
|-----------------------------------------------------------------------------------------|---|----------------------|
|[GetBlockBasicInfo](./1-ModAPI/接口/方块/属性.md#getblockbasicinfo)|服务端|       获取方块基本信息       |
|     [GetBlockTags](./1-ModAPI/接口/方块/属性.md#getblocktags)     |服务端|获取方块在tags:\*中定义的tags列表|
|    [GetLoadBlocks](./1-ModAPI/接口/方块/属性.md#getloadblocks)    |服务端|     获取已经加载的方块id      |
|[SetBlockBasicInfo](./1-ModAPI/接口/方块/属性.md#setblockbasicinfo)|服务端|       设置方块基本信息       |
|[SetChestLootTable](./1-ModAPI/接口/方块/属性.md#setchestloottable)|服务端|       设置箱子战利品表       |

####  方块实体 ####

|                                                             接口                                                              |   |                                                                                                          描述                                                                                                          |
|-----------------------------------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|    [CleanBlockTileEntityCustomData](./1-ModAPI/接口/方块/方块实体.md#cleanblocktileentitycustomdata)    |服务端|                                                                                   清空指定位置的特殊方块（箱子、头颅、熔炉、花盆等）绑定的TileEntity内存储的自定义数据。                                                                                   |
|   [CreateFrameEffectForBlockEntity](./1-ModAPI/接口/方块/方块实体.md#createframeeffectforblockentity)   |客户端|                                                             在自定义方块实体上创建序列帧特效，创建后该接口返回序列帧特效的Id，利用该Id可以使用特效/序列帧中的接口对该序列帧特效进行播放、设置位置、大小等操作。与实体的序列帧特效创建方式类似。                                                             |
|[CreateParticleEffectForBlockEntity](./1-ModAPI/接口/方块/方块实体.md#createparticleeffectforblockentity)|客户端|                                          在自定义方块实体上创建粒子特效，创建后该接口返回粒子特效的Id，利用该Id可以使用特效/粒子中的接口对该粒子特效进行播放、设置位置、大小等操作。与实体的粒子特效创建方式类似。若自定义方块实体已存在键值名称相同的特效，则不会创建新的特效，接口返回已有的特效Id。                                          |
|               [ExecuteCommandBlock](./1-ModAPI/接口/方块/方块实体.md#executecommandblock)               |服务端|                                                                                                       执行一次命令方块                                                                                                       |
|                [GetBlockEntityData](./1-ModAPI/接口/方块/方块实体.md#getblockentitydata)                |服务端|                                                                                          用于获取可操作某个自定义方块实体数据的对象，操作方式与dict类似                                                                                           |
|                [GetBlockEntityData](./1-ModAPI/接口/方块/方块实体.md#getblockentitydata)                |服务端|                                                                                   用于获取方块（包括自定义方块）的数据，如需修改，请使用setblockentitydata接口                                                                                    |
|                [GetBlockEntityData](./1-ModAPI/接口/方块/方块实体.md#getblockentitydata)                |客户端|                                                                                   用于获取客户端当前维度中方块（包括自定义方块）的数据，数据只读不可写，无法获取箱子内的物品信息。                                                                                   |
|         [GetBlockEntityMolangValue](./1-ModAPI/接口/方块/方块实体.md#getblockentitymolangvalue)         |客户端|                                                                                                获取自定义方块实体的Molang变量的值。                                                                                                 |
|      [GetBlockTileEntityCustomData](./1-ModAPI/接口/方块/方块实体.md#getblocktileentitycustomdata)      |服务端|                                                                                   读取指定位置的特殊方块（箱子、头颅、熔炉、花盆等）绑定的TileEntity内存储的自定义数据                                                                                    |
| [GetBlockTileEntityWholeCustomData](./1-ModAPI/接口/方块/方块实体.md#getblocktileentitywholecustomdata) |服务端|                                                                                  读取指定位置的特殊方块（箱子、头颅、熔炉、花盆等）绑定的TileEntity内存储的自定义数据字典。                                                                                  |
|                   [GetCommandBlock](./1-ModAPI/接口/方块/方块实体.md#getcommandblock)                   |服务端|                                                                                                     获取命令方块的设置内容                                                                                                      |
|     [GetFrameEffectIdInBlockEntity](./1-ModAPI/接口/方块/方块实体.md#getframeeffectidinblockentity)     |客户端| 获取在自定义方块实体中已创建的指定序列帧特效的Id，已创建的特效分为两种：一是通过resource\_pack/entity/下的实体json文件中使用“netease\_frame\_effects”所定义的特效；二是使用接口CreateFrameEffectForBlockEntity创建的特效。 返回的特效Id可以使用特效/序列帧中的接口对该序列帧特效进行播放、设置位置、大小等操作。与实体的序列帧特效创建方式类似。 |
|                      [GetFrameItem](./1-ModAPI/接口/方块/方块实体.md#getframeitem)                      |服务端|                                                                                                      获取物品展示框的物品                                                                                                      |
|            [GetFrameItemDropChange](./1-ModAPI/接口/方块/方块实体.md#getframeitemdropchange)            |服务端|                                                                                                   获取物品展示框里物品的掉落几率                                                                                                    |
|                  [GetFrameRotation](./1-ModAPI/接口/方块/方块实体.md#getframerotation)                  |服务端|                                                                                                  获取物品展示框里物品的顺时针旋转角度                                                                                                  |
|                    [GetHopperSpeed](./1-ModAPI/接口/方块/方块实体.md#gethopperspeed)                    |服务端|                                                                                                获取漏斗运输一个物品所需的时间（单位：刻）                                                                                                 |
|  [GetParticleEffectIdInBlockEntity](./1-ModAPI/接口/方块/方块实体.md#getparticleeffectidinblockentity)  |客户端|获取在自定义方块实体中已创建的指定粒子特效的Id，已创建的特效分为两种：一是通过resource\_pack/entity/下的实体json文件中使用“netease\_particle\_effects”所定义的特效；二是使用接口CreateParticleEffectForBlockEntity创建的特效。 返回的特效Id可以使用特效/粒子中的接口对该粒子特效进行播放、设置位置、大小等操作。与实体的粒子特效创建方式类似。|
|    [RemoveFrameEffectInBlockEntity](./1-ModAPI/接口/方块/方块实体.md#removeframeeffectinblockentity)    |客户端|                                                                                          移除在自定义方块实体上创建的序列帧特效。移除后的特效Id将会失效。                                                                                           |
| [RemoveParticleEffectInBlockEntity](./1-ModAPI/接口/方块/方块实体.md#removeparticleeffectinblockentity) |客户端|                                                                                           移除在自定义方块实体上创建的粒子特效。移除后的特效Id将会失效。                                                                                           |
|                [SetBlockEntityData](./1-ModAPI/接口/方块/方块实体.md#setblockentitydata)                |服务端|                                                                                                  用于设置方块（包括自定义方块）的数据                                                                                                  |
|         [SetBlockEntityMolangValue](./1-ModAPI/接口/方块/方块实体.md#setblockentitymolangvalue)         |客户端|                                                   设置自定义方块实体的Molang变量，与实体的molang变量作用相同。目前主要用于控制自定义实体的动画状态转变。Molang变量的定义方式与原版实体的Molang变量定义方法相同。详细可参考自定义方块实体动画的教学文档。                                                    |
|      [SetBlockTileEntityCustomData](./1-ModAPI/接口/方块/方块实体.md#setblocktileentitycustomdata)      |服务端|                                                                                   设置指定位置的特殊方块（箱子、头颅、熔炉、花盆等）绑定的TileEntity内存储的自定义数据。                                                                                   |
|                   [SetCommandBlock](./1-ModAPI/接口/方块/方块实体.md#setcommandblock)                   |服务端|                                                                                                     对命令方块进行内容设置                                                                                                      |
|    [SetEnableBlockEntityAnimations](./1-ModAPI/接口/方块/方块实体.md#setenableblockentityanimations)    |客户端|                                                             设置是否开启自定义方块实体的动画效果，开启之后，自定义实体方块会按照实体文件中animation\_controller所定义的动画状态机进行动画播放。关闭之后，则会停止所有动画播放。                                                             |
|                      [SetFrameItem](./1-ModAPI/接口/方块/方块实体.md#setframeitem)                      |服务端|                                                                                                      设置物品展示框的物品                                                                                                      |
|            [SetFrameItemDropChange](./1-ModAPI/接口/方块/方块实体.md#setframeitemdropchange)            |服务端|                                                                                                设置点击物品展示框时生成掉落的几率，默认为1                                                                                                |
|                  [SetFrameRotation](./1-ModAPI/接口/方块/方块实体.md#setframerotation)                  |服务端|                                                                                                  设置物品展示框里物品的顺时针旋转角度                                                                                                  |
|                    [SetHopperSpeed](./1-ModAPI/接口/方块/方块实体.md#sethopperspeed)                    |服务端|                                                                                      设置漏斗运输一个物品所需的时间（单位：红石刻，1秒10刻），默认值为4刻，该设置存档                                                                                      |

####  方块几何体模型 ####

|                                                                接口                                                                |   |                                         描述                                         |
|----------------------------------------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------|
|   [CombineBlockBetweenPosToGeometry](./1-ModAPI/接口/方块/方块几何体模型.md#combineblockbetweenpostogeometry)   |客户端|                 根据输入的两个位置，搜索这两个位置之间的所有方块，并将这些方块合并和转换为能用于实体的几何体模型。                  |
|  [CombineBlockFromPosListToGeometry](./1-ModAPI/接口/方块/方块几何体模型.md#combineblockfromposlisttogeometry)  |客户端|                  根据输入的方块位置列表，搜索这些位置的所有方块，并将这些方块合并和转换为能用于实体的几何体模型。                  |
|      [CombineBlockPaletteToGeometry](./1-ModAPI/接口/方块/方块几何体模型.md#combineblockpalettetogeometry)      |客户端|                       将BlockPalette中的所有方块合并并转换为能用于实体的几何体模型。                        |
|[EnableActorBlockGeometryTransparent](./1-ModAPI/接口/方块/方块几何体模型.md#enableactorblockgeometrytransparent)|客户端|              设置是否允许实体的方块几何体模型产生透明度，允许开启后通过调节方块几何体的透明度将会使得方块几何体模型变得透明。              |
|         [GetActorBlockGeometryScale](./1-ModAPI/接口/方块/方块几何体模型.md#getactorblockgeometryscale)         |客户端|                                 获取实体的方块几何体模型的缩放倍率。                                 |
|        [SetActorBlockGeometryOffset](./1-ModAPI/接口/方块/方块几何体模型.md#setactorblockgeometryoffset)        |客户端|                                 设置实体的方块几何体模型的位置偏移。                                 |
|      [SetActorBlockGeometryRotation](./1-ModAPI/接口/方块/方块几何体模型.md#setactorblockgeometryrotation)      |客户端|                                 设置实体的方块几何体模型的旋转角度。                                 |
|         [SetActorBlockGeometryScale](./1-ModAPI/接口/方块/方块几何体模型.md#setactorblockgeometryscale)         |客户端|                                 设置实体的方块几何体模型的缩放倍率。                                 |
|  [SetActorBlockGeometryTransparency](./1-ModAPI/接口/方块/方块几何体模型.md#setactorblockgeometrytransparency)  |客户端|设置实体的方块几何体模型的透明度。注意，只有调用接口EnableActorBlockGeometryTransparent开启了方块几何体模型的透明度后该接口才会生效。|

####  方块调色板 ####

|                                                       接口                                                       |             |                                              描述                                              |
|----------------------------------------------------------------------------------------------------------------|-------------|----------------------------------------------------------------------------------------------|
|  [DeleteBlockInBlockPalette](./1-ModAPI/接口/方块/方块调色板.md#deleteblockinblockpalette)  |服务端  <br/>客户端|                                 删除方块调色板BlockPalette中某个类型的方块。                                 |
|    [DeserializeBlockPalette](./1-ModAPI/接口/方块/方块调色板.md#deserializeblockpalette)    |服务端  <br/>客户端|                         反序列化方块调色板数据字典中的数据，用于方块调色板在客户端及服务端的事件数据之间传输。                          |
|[GetBlockCountInBlockPalette](./1-ModAPI/接口/方块/方块调色板.md#getblockcountinblockpalette)|服务端  <br/>客户端|                               获取方块调色板BlockPalette中某个类型的方块的数量。                                |
|    [GetLocalPosListOfBlocks](./1-ModAPI/接口/方块/方块调色板.md#getlocalposlistofblocks)    |服务端  <br/>客户端|  获取方块调色板中某种方块的相对位置列表。方块调色板记录了多个方块组成的一个三维空间下的方块组合，而相对位置则指的是，以这些方块中最小坐标的方块所在位置作为原点的坐标轴下的相对位置。  |
|    [GetVolumeOfBlockPalette](./1-ModAPI/接口/方块/方块调色板.md#getvolumeofblockpalette)    |服务端  <br/>客户端|获取方块调色板BlockPalette所占据的长方体的长宽高。长指的是在方块调色板BlockPalette在世界坐标中占据的x轴方向的长度，宽指的是z轴方向的长度，高指的是y轴方向的长度。|
|  [ReplaceAirByStructureVoid](./1-ModAPI/接口/方块/方块调色板.md#replaceairbystructurevoid)  |服务端  <br/>客户端|                             设置是否将方块调色板BlockPalette中所有空气替换为结构空位。                              |
| [ReplaceBlockInBlockPalette](./1-ModAPI/接口/方块/方块调色板.md#replaceblockinblockpalette) |服务端  <br/>客户端|                                 替换方块调色板BlockPalette中某个类型的方块。                                 |
|      [SerializeBlockPalette](./1-ModAPI/接口/方块/方块调色板.md#serializeblockpalette)      |服务端  <br/>客户端|                            序列化方块调色板中的数据，用于方块调色板在客户端及服务端的事件数据之间传输。                            |

####  渲染 ####

|                                                         接口                                                          |   |                                                                                                      描述                                                                                                       |
|---------------------------------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|             [AddDropItemToWorld](./1-ModAPI/接口/方块/渲染.md#adddropitemtoworld)             |客户端|                                                                                                 在客户端添加一个掉落物渲染                                                                                                 |
|            [ChangeBlockTextures](./1-ModAPI/接口/方块/渲染.md#changeblocktextures)            |客户端|                                                                                                    替换方块贴图                                                                                                     |
|     [DeleteClientDropItemEntity](./1-ModAPI/接口/方块/渲染.md#deleteclientdropitementity)     |客户端|                                                                                         删除AddDropItemToWorld创建的客户端掉落物                                                                                         |
|              [DestroyCrackFrame](./1-ModAPI/接口/方块/渲染.md#destroycrackframe)              |客户端|                                                                                  销毁特定方块位置上的破坏纹理（仅能销毁SetCrackFrame接口创建的破坏纹理）。                                                                                  |
|    [GetBlockEntityExtraUniforms](./1-ModAPI/接口/方块/渲染.md#getblockentityextrauniforms)    |客户端|             获取在自定义方块实体的shader当中使用的自定义变量的值，该自定义变量总共可设置EXTRA\_ACTOR\_UNIFORM1,EXTRA\_ACTOR\_UNIFORM2,EXTRA\_ACTOR\_UNIFORM3,EXTRA\_ACTOR\_UNIFORM4，总共4组，每组为一个vec4(float, float, float ,float)类型的向量。             |
|         [GetBlockRenderDistance](./1-ModAPI/接口/方块/渲染.md#getblockrenderdistance)         |客户端|                                                                                                 获取玩家周围的可渲染距离                                                                                                  |
|               [GetBlockTextures](./1-ModAPI/接口/方块/渲染.md#getblocktextures)               |客户端|                                                                                                  获取方块的初始贴图信息                                                                                                  |
|  [GetClientDropItemEntityIdList](./1-ModAPI/接口/方块/渲染.md#getclientdropitementityidlist)  |客户端|                                                                                   获得所有通过AddDropItemToWorld创建的entityId的list                                                                                    |
|    [SetBlockEntityExtraUniforms](./1-ModAPI/接口/方块/渲染.md#setblockentityextrauniforms)    |客户端|设置可在自定义方块实体的shader当中使用的自定义变量的值，该自定义变量总共可设置EXTRA\_ACTOR\_UNIFORM1,EXTRA\_ACTOR\_UNIFORM2,EXTRA\_ACTOR\_UNIFORM3,EXTRA\_ACTOR\_UNIFORM4，总共4组，每组为一个vec4(float, float, float ,float)类型的向量，向量的默认值为(1.0,1.0,1.0,1.0)。|
|   [SetBlockEntityFramePosOffset](./1-ModAPI/接口/方块/渲染.md#setblockentityframeposoffset)   |客户端|                                                           设置自定义方块实体中序列帧特效位置偏移值，用于调整序列帧特效相对于方块位置的偏移。与特效/序列帧/SetPos接口不同，该接口调整的是相对于方块位置的位置偏移值，而不是世界坐标。                                                           |
|   [SetBlockEntityModelPosOffset](./1-ModAPI/接口/方块/渲染.md#setblockentitymodelposoffset)   |客户端|                                    设置自定义方块实体的实体模型位置偏移值，用于调整实体模型相对于方块位置的偏移。可通过该接口来调整自定义方块实体的实体模型的位置。只有自定义方块实体定义实体模型才生效，实体模型在resource\_pack/entity/下定义，详细可参考自定义方块实体动画的教学文档。                                     |
|    [SetBlockEntityModelRotation](./1-ModAPI/接口/方块/渲染.md#setblockentitymodelrotation)    |客户端|                                            设置自定义方块实体的实体模型在各个轴上的旋转值，可通过该接口来调整自定义方块实体的实体模型的旋转。只有自定义方块实体定义实体模型才生效，实体模型在resource\_pack/entity/下定义，详细可参考自定义方块实体动画的教学文档。                                            |
|       [SetBlockEntityModelScale](./1-ModAPI/接口/方块/渲染.md#setblockentitymodelscale)       |客户端|                                             设置自定义方块实体的实体模型大小的缩放值，可通过该接口来调整自定义方块实体的实体模型的大小。只有自定义方块实体定义实体模型才生效，实体模型在resource\_pack/entity/下定义，详细可参考自定义方块实体动画的教学文档。                                              |
|[SetBlockEntityParticlePosOffset](./1-ModAPI/接口/方块/渲染.md#setblockentityparticleposoffset)|客户端|                                                            设置自定义方块实体中粒子特效位置偏移值，用于调整粒子特效相对于方块位置的偏移。与特效/粒子/SetPos接口不同，该接口调整的是相对于方块位置的位置偏移值，而不是世界坐标。                                                             |
|         [SetBlockRenderDistance](./1-ModAPI/接口/方块/渲染.md#setblockrenderdistance)         |客户端|                                                                                                设置玩家周围方块的可渲染距离                                                                                                 |
|                  [SetCrackFrame](./1-ModAPI/接口/方块/渲染.md#setcrackframe)                  |客户端|                                                                                          仅客户端的破坏纹理的渲染，可自定义破坏阶段在第几帧。                                                                                           |
|           [SetDropItemTransform](./1-ModAPI/接口/方块/渲染.md#setdropitemtransform)           |客户端|                                                                                     设置通过AddDropItemToWorld添加的掉落物的位置、角度和缩放                                                                                     |

####  容器 ####

|                                                 接口                                                  |   |                                    描述                                     |
|-----------------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------|
|[GetBrewingStandSlotItem](./1-ModAPI/接口/方块/容器.md#getbrewingstandslotitem)|服务端|                                获取酿造台指定槽位物品                                |
|        [GetChestBoxSize](./1-ModAPI/接口/方块/容器.md#getchestboxsize)        |服务端|                                 获取箱子容量大小                                  |
| [GetChestPairedPosition](./1-ModAPI/接口/方块/容器.md#getchestpairedposition) |服务端|                           获取与箱子A合并成一个大箱子的箱子B的坐标                           |
|       [GetContainerItem](./1-ModAPI/接口/方块/容器.md#getcontaineritem)       |服务端|                                 获取容器内的物品                                  |
|       [GetContainerSize](./1-ModAPI/接口/方块/容器.md#getcontainersize)       |服务端|                                 获取容器容量大小                                  |
|      [GetEnderChestItem](./1-ModAPI/接口/方块/容器.md#getenderchestitem)      |服务端|                                 获取末影箱内的物品                                 |
|       [GetInputSlotItem](./1-ModAPI/接口/方块/容器.md#getinputslotitem)       |服务端|获取熔炉输入栏物品, 支持使用下面参数清空特定槽位:itemDict为空，为{}, 或itemName为minecraft:air，或者count为0|
|   [GetOpenContainerItem](./1-ModAPI/接口/方块/容器.md#getopencontaineritem)   |服务端|                                 获取开放容器的物品                                 |
|      [GetOutputSlotItem](./1-ModAPI/接口/方块/容器.md#getoutputslotitem)      |服务端|                                 获取熔炉输出栏物品                                 |
|        [GetPlayerUIItem](./1-ModAPI/接口/方块/容器.md#getplayeruiitem)        |服务端|                                 获取合成容器的物品                                 |
|[SetBrewingStandSlotItem](./1-ModAPI/接口/方块/容器.md#setbrewingstandslotitem)|服务端|                                设置酿造台指定槽位物品                                |
|[SetChestBoxItemExchange](./1-ModAPI/接口/方块/容器.md#setchestboxitemexchange)|服务端|                                交换箱子里物品的槽位                                 |
|     [SetChestBoxItemNum](./1-ModAPI/接口/方块/容器.md#setchestboxitemnum)     |服务端|                                设置箱子槽位物品数目                                 |
|       [SetInputSlotItem](./1-ModAPI/接口/方块/容器.md#setinputslotitem)       |服务端|                                 设置熔炉输入栏物品                                 |
|        [SetPlayerUIItem](./1-ModAPI/接口/方块/容器.md#setplayeruiitem)        |服务端|                                 设置合成容器的物品                                 |
|   [SpawnItemToContainer](./1-ModAPI/接口/方块/容器.md#spawnitemtocontainer)   |服务端|                               生成物品到容器方块的物品栏                               |
|  [SpawnItemToEnderChest](./1-ModAPI/接口/方块/容器.md#spawnitemtoenderchest)  |服务端|                                 生成物品到末影箱                                  |

####  红石 ####

|                                              接口                                               |   |     描述      |
|-----------------------------------------------------------------------------------------------|---|-------------|
|[GetBlockPoweredState](./1-ModAPI/接口/方块/红石.md#getblockpoweredstate)|服务端|获取某个坐标方块的充能状态|
|         [GetStrength](./1-ModAPI/接口/方块/红石.md#getstrength)         |服务端|获取某个坐标的红石信号强度|

####  告示牌 ####

|                                           接口                                           |   |      描述      |
|----------------------------------------------------------------------------------------|---|--------------|
|[GetSignBlockText](./1-ModAPI/接口/方块/告示牌.md#getsignblocktext)|服务端|获取告示牌（方块）的文本内容|
|[GetSignTextStyle](./1-ModAPI/接口/方块/告示牌.md#getsigntextstyle)|服务端| 获取告示牌的文本样式信息 |
|[SetSignBlockText](./1-ModAPI/接口/方块/告示牌.md#setsignblocktext)|服务端|设置告示牌（方块）的文本内容|
|[SetSignTextStyle](./1-ModAPI/接口/方块/告示牌.md#setsigntextstyle)|服务端|  设置告示牌的文本样式  |

####  床 ####

|                                     接口                                     |   |    描述    |
|----------------------------------------------------------------------------|---|----------|
|[GetBedColor](./1-ModAPI/接口/方块/床.md#getbedcolor)|服务端|获取床（方块）的颜色|
|[SetBedColor](./1-ModAPI/接口/方块/床.md#setbedcolor)|服务端|设置床（方块）的颜色|

####  物品 ####

|                                                         接口                                                         |   |                                                     描述                                                     |
|--------------------------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------------------------------|
|        [BindItemToMinecraftModel](./1-ModAPI/接口/物品.md#binditemtominecraftmodel)        |客户端|                                   将指定物品作为附作物动态挂接到实体原版模型上，在实体原版模型上渲染指定物品。                                   |
|         [BindItemToSkeletonModel](./1-ModAPI/接口/物品.md#binditemtoskeletonmodel)         |客户端|                             将指定物品作为附作物动态挂接到实体的网易版骨骼模型，在实体的网易版骨骼模型上指定骨骼渲染指定物品。                              |
|   [CancelShearsDestroyBlockSpeed](./1-ModAPI/接口/物品.md#cancelshearsdestroyblockspeed)   |服务端|                                              取消剪刀对某一方块的破坏速度设置                                              |
|[CancelShearsDestroyBlockSpeedAll](./1-ModAPI/接口/物品.md#cancelshearsdestroyblockspeedall)|服务端|                                              取消剪刀对全部方块的破坏速度设置                                              |
|             [ChangeArmorTextures](./1-ModAPI/接口/物品.md#changearmortextures)             |客户端|                                            修改盔甲在场景中显示和在UI中显示的贴图                                            |
|               [ChangeItemTexture](./1-ModAPI/接口/物品.md#changeitemtexture)               |客户端|                替换物品的贴图，修改后所有用到该贴图的物品都会被改变，后续创建的此类物品也会被改变。会同时修改物品在UI界面上的显示，手持时候的显示与场景掉落的显示。                 |
|              [GetAllEnchantsInfo](./1-ModAPI/接口/物品.md#getallenchantsinfo)              |服务端|                                               获取目前已注册的所有附魔信息                                               |
|              [GetAllEnchantsInfo](./1-ModAPI/接口/物品.md#getallenchantsinfo)              |客户端|                                               获取目前已注册的所有附魔信息                                               |
|          [GetBindBoneForBindItem](./1-ModAPI/接口/物品.md#getbindboneforbinditem)          |客户端|                                         查询获取实体上已绑定的物品附着物所绑定的骨骼名称。                                          |
|               [GetBindItemOffset](./1-ModAPI/接口/物品.md#getbinditemoffset)               |客户端|                                          查询获取实体上的物品附着物相对骨骼的位置偏移。                                           |
|             [GetBindItemRotation](./1-ModAPI/接口/物品.md#getbinditemrotation)             |客户端|                                          查询获取实体上的物品附着物相对骨骼的旋转角度。                                           |
|                [GetBindItemScale](./1-ModAPI/接口/物品.md#getbinditemscale)                |客户端|                                            查询获取实体上的物品附着物的缩放比例。                                             |
|                   [GetCustomName](./1-ModAPI/接口/物品.md#getcustomname)                   |服务端|                                           获取物品的自定义名称，与铁砧修改的名称一致                                            |
|                [GetItemBasicInfo](./1-ModAPI/接口/物品.md#getitembasicinfo)                |服务端|                                                 获取物品的基础信息                                                  |
|                [GetItemBasicInfo](./1-ModAPI/接口/物品.md#getitembasicinfo)                |客户端|                                                 获取物品的基础信息                                                  |
|             [GetItemDefenceAngle](./1-ModAPI/接口/物品.md#getitemdefenceangle)             |服务端|                                               获取盾牌物品的抵挡角度范围                                                |
|               [GetItemDurability](./1-ModAPI/接口/物品.md#getitemdurability)               |服务端|                                                获取指定槽位的物品耐久                                                 |
|               [GetItemEffectName](./1-ModAPI/接口/物品.md#getitemeffectname)               |客户端|                                            获取物品的状态描述，如：§7保护 0§r                                            |
|       [GetItemFormattedHoverText](./1-ModAPI/接口/物品.md#getitemformattedhovertext)       |客户端|                                         获取物品的格式化hover文本，如：§f灾厄旗帜§r                                         |
|                [GetItemHoverName](./1-ModAPI/接口/物品.md#getitemhovername)                |客户端|                                           获取物品的hover名称，如：灾厄旗帜§r                                            |
|          [GetItemInfoByBlockName](./1-ModAPI/接口/物品.md#getiteminfobyblockname)          |服务端|                                             通过方块名称及aux值获取物品信息                                              |
|                    [GetItemLayer](./1-ModAPI/接口/物品.md#getitemlayer)                    |服务端|                                       获取物品的叠加贴图。物品叠加贴图详见SetItemLayer                                       |
|            [GetItemMaxDurability](./1-ModAPI/接口/物品.md#getitemmaxdurability)            |服务端|                                               获取指定槽位的物品耐最大耐久                                               |
|                     [GetItemTags](./1-ModAPI/接口/物品.md#getitemtags)                     |服务端|                                       获取物品在minecraft:tags中定义的tags列表                                        |
|                     [GetItemTags](./1-ModAPI/接口/物品.md#getitemtags)                     |客户端|                                       获取物品在minecraft:tags中定义的tags列表                                        |
|                  [GetItemTexture](./1-ModAPI/接口/物品.md#getitemtexture)                  |客户端|                                       获取item\_texture.json中物品的贴图路径。                                        |
|                    [GetLoadItems](./1-ModAPI/接口/物品.md#getloaditems)                    |服务端|                                                获取已经加载的物品id                                                 |
|              [GetUserDataInEvent](./1-ModAPI/接口/物品.md#getuserdatainevent)              |服务端|使物品相关服务端事件的[物品信息字典](../../../mcguide/20-玩法开发/10-基本概念/1-我的世界基础概念.html#物品信息字典#物品信息字典)参数带有userData。在mod初始化时调用即可|
|              [GetUserDataInEvent](./1-ModAPI/接口/物品.md#getuserdatainevent)              |客户端|使物品相关客户端事件的[物品信息字典](../../../mcguide/20-玩法开发/10-基本概念/1-我的世界基础概念.html#物品信息字典#物品信息字典)参数带有userData。在mod初始化时调用即可|
|                [LookupItemByName](./1-ModAPI/接口/物品.md#lookupitembyname)                |服务端|                                           判定指定identifier的物品是否存在                                            |
|                 [RemoveItemLayer](./1-ModAPI/接口/物品.md#removeitemlayer)                 |服务端|                                       移除物品的叠加贴图。物品叠加贴图详见SetItemLayer                                       |
|                 [SetAttackDamage](./1-ModAPI/接口/物品.md#setattackdamage)                 |服务端|                                                 设置物品的攻击伤害值                                                 |
|          [SetBindBoneForBindItem](./1-ModAPI/接口/物品.md#setbindboneforbinditem)          |客户端|                                     改变实体上已绑定的物品附着物所绑定的骨骼，又或者移除该物品附着物。                                      |
|               [SetBindItemOffset](./1-ModAPI/接口/物品.md#setbinditemoffset)               |客户端|                                           设置实体上的物品附着物相对骨骼的位置偏移。                                            |
|             [SetBindItemRotation](./1-ModAPI/接口/物品.md#setbinditemrotation)             |客户端|                                           设置实体上的物品附着物相对骨骼的旋转角度。                                            |
|                [SetBindItemScale](./1-ModAPI/接口/物品.md#setbinditemscale)                |客户端|                                             设置实体上的物品附着物的缩放比例。                                              |
|                [SetCompassEntity](./1-ModAPI/接口/物品.md#setcompassentity)                |客户端|                                                 设置指南针朝向的实体                                                 |
|                [SetCompassTarget](./1-ModAPI/接口/物品.md#setcompasstarget)                |客户端|                                                 设置指南针的朝向位置                                                 |
|                   [SetCustomName](./1-ModAPI/接口/物品.md#setcustomname)                   |服务端|                                           设置物品的自定义名称，与使用铁砧重命名一致                                            |
|             [SetItemDefenceAngle](./1-ModAPI/接口/物品.md#setitemdefenceangle)             |服务端|                                               设置盾牌物品的抵挡角度范围                                                |
|               [SetItemDurability](./1-ModAPI/接口/物品.md#setitemdurability)               |服务端|                                                  设置物品的耐久值                                                  |
|                    [SetItemLayer](./1-ModAPI/接口/物品.md#setitemlayer)                    |服务端|                           设置物品的叠加贴图，可以在物品的上层与下层叠加自定义贴图。具体使用可参考CustomItemsMod示例。                            |
|            [SetItemMaxDurability](./1-ModAPI/接口/物品.md#setitemmaxdurability)            |服务端|                                                 设置物品的最大耐久值                                                 |
|                [SetItemTierLevel](./1-ModAPI/接口/物品.md#setitemtierlevel)                |服务端|                                                设置工具类物品的挖掘等级                                                |
|                [SetItemTierSpeed](./1-ModAPI/接口/物品.md#setitemtierspeed)                |服务端|                               设置工具类物品的挖掘速度(可通过userData中的ModTierSpeed获取挖掘速度)                                |
|                 [SetMaxStackSize](./1-ModAPI/接口/物品.md#setmaxstacksize)                 |服务端|                                              设置物品的最大堆叠数量（存档）                                               |
|      [SetShearsDestroyBlockSpeed](./1-ModAPI/接口/物品.md#setshearsdestroyblockspeed)      |服务端|                                               设置剪刀对某一方块的破坏速度                                               |

####  通用 ####

|                                       接口                                        |   | 描述 |
|---------------------------------------------------------------------------------|---|----|
|[DestroyEntity](./1-ModAPI/接口/特效/通用.md#destroyentity)|客户端|销毁特效|

####  文字面板 ####

|                                                  接口                                                   |   |              描述               |
|-------------------------------------------------------------------------------------------------------|---|-------------------------------|
| [CreateTextBoardInWorld](./1-ModAPI/接口/特效/文字面板.md#createtextboardinworld) |客户端|            创建文字面板             |
|        [RemoveTextBoard](./1-ModAPI/接口/特效/文字面板.md#removetextboard)        |客户端|            删除文字面板             |
|[SetBoardBackgroundColor](./1-ModAPI/接口/特效/文字面板.md#setboardbackgroundcolor)|客户端|            修改背景颜色             |
|     [SetBoardBindEntity](./1-ModAPI/接口/特效/文字面板.md#setboardbindentity)     |客户端|          文字面板绑定实体对象           |
|      [SetBoardDepthTest](./1-ModAPI/接口/特效/文字面板.md#setboarddepthtest)      |客户端|     设置是否开启深度测试, 默认状态下是开启      |
|     [SetBoardFaceCamera](./1-ModAPI/接口/特效/文字面板.md#setboardfacecamera)     |客户端|           设置文字面板的朝向           |
|            [SetBoardPos](./1-ModAPI/接口/特效/文字面板.md#setboardpos)            |客户端|             修改位置              |
|            [SetBoardRot](./1-ModAPI/接口/特效/文字面板.md#setboardrot)            |客户端|修改旋转角度, 若设置了文本朝向相机，则旋转角度的修改不会生效|
|          [SetBoardScale](./1-ModAPI/接口/特效/文字面板.md#setboardscale)          |客户端|            内容整体缩放             |
|      [SetBoardTextColor](./1-ModAPI/接口/特效/文字面板.md#setboardtextcolor)      |客户端|            修改字体颜色             |
|                [SetText](./1-ModAPI/接口/特效/文字面板.md#settext)                |客户端|           修改文字面板内容            |

####  序列帧 ####

|                                                    接口                                                    |   |                                                     描述                                                     |
|----------------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------------------------------|
|                     [Bind](./1-ModAPI/接口/特效/序列帧.md#bind)                     |客户端|                                                  绑定entity                                                  |
|                     [Bind](./1-ModAPI/接口/特效/序列帧.md#bind)                     |客户端|                                                   绑定骨骼模型                                                   |
|          [CreateEngineSfx](./1-ModAPI/接口/特效/序列帧.md#createenginesfx)          |客户端|                                                  创建序列帧特效                                                   |
|[CreateEngineSfxFromEditor](./1-ModAPI/接口/特效/序列帧.md#createenginesfxfromeditor)|客户端|                             指使用资源包中effects/xxx.json，按照编辑器中编辑好的参数创建序列帧。支持环状序列帧                              |
|                   [GetPos](./1-ModAPI/接口/特效/序列帧.md#getpos)                   |客户端|                                                 获取序列帧特效的位置                                                 |
|                   [GetRot](./1-ModAPI/接口/特效/序列帧.md#getrot)                   |客户端|                                                获取序列帧特效的旋转角度                                                |
|                 [GetScale](./1-ModAPI/接口/特效/序列帧.md#getscale)                 |客户端|                                                获取序列帧特效的缩放值                                                 |
|                    [Pause](./1-ModAPI/接口/特效/序列帧.md#pause)                    |客户端|                                       暂停播放，序列帧定格在当前时刻，再次调用Play时继续播放                                        |
|                     [Play](./1-ModAPI/接口/特效/序列帧.md#play)                     |客户端|                                                   播放序列帧                                                    |
|              [SetDeepTest](./1-ModAPI/接口/特效/序列帧.md#setdeeptest)              |客户端|                                               设置序列帧是否透视，默认为否                                               |
|            [SetFaceCamera](./1-ModAPI/接口/特效/序列帧.md#setfacecamera)            |客户端|                                            设置序列帧是否始终朝向摄像机，默认为是                                             |
|          [SetFadeDistance](./1-ModAPI/接口/特效/序列帧.md#setfadedistance)          |客户端|                       设置序列帧开始自动调整透明度的距离。序列帧与摄像机之间的距离小于该值时会自动调整序列帧的透明度，距离摄像机越近，序列帧越透明                       |
|                [SetGlobal](./1-ModAPI/接口/特效/序列帧.md#setglobal)                |客户端|                                              设置序列帧是否是全局的，默认为否                                              |
|                 [SetLayer](./1-ModAPI/接口/特效/序列帧.md#setlayer)                 |客户端|设置序列帧渲染层级，默认层级为1，当层级不为1时表示该特效开启特效分层渲染功能。特效（粒子和帧动画）分层渲染时，层级越高渲染越靠后，层级大的会遮挡层级低的，且同一层级的特效会根据特效的相对位置产生正确的相互遮挡关系。|
|                  [SetLoop](./1-ModAPI/接口/特效/序列帧.md#setloop)                  |客户端|                                              设置序列帧是否循环播放，默认为否                                              |
|              [SetMixColor](./1-ModAPI/接口/特效/序列帧.md#setmixcolor)              |客户端|                                                 设置序列帧混合颜色                                                  |
|                   [SetPos](./1-ModAPI/接口/特效/序列帧.md#setpos)                   |客户端|                                                  设置序列帧的位置                                                  |
|                   [SetRot](./1-ModAPI/接口/特效/序列帧.md#setrot)                   |客户端|                                                  设置序列帧的旋转                                                  |
|             [SetRotUseZXY](./1-ModAPI/接口/特效/序列帧.md#setrotusezxy)             |客户端|                                          设置序列帧的旋转，旋转顺序按照绕z,x,y轴旋转                                          |
|                 [SetScale](./1-ModAPI/接口/特效/序列帧.md#setscale)                 |客户端|                                                  设置序列帧的缩放                                                  |
|     [SetUsePointFiltering](./1-ModAPI/接口/特效/序列帧.md#setusepointfiltering)     |客户端|                                                设置序列帧是否使用点滤波                                                |
|                     [Stop](./1-ModAPI/接口/特效/序列帧.md#stop)                     |客户端|                                                停止序列帧（不是暂停）                                                 |

####  粒子 ####

|                                                 接口                                                  |   |                                                 描述                                                 |
|-----------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------------------------|
|                   [Bind](./1-ModAPI/接口/特效/粒子.md#bind)                   |客户端|                                              绑定entity                                              |
|                   [Bind](./1-ModAPI/接口/特效/粒子.md#bind)                   |客户端|                                               绑定骨骼模型                                               |
|   [CreateEngineParticle](./1-ModAPI/接口/特效/粒子.md#createengineparticle)   |客户端|                                              用于创建粒子特效                                              |
|[GetParticleEmissionRate](./1-ModAPI/接口/特效/粒子.md#getparticleemissionrate)|客户端|                                         获取粒子发射器每帧发射粒子的频率。                                          |
|      [GetParticleMaxNum](./1-ModAPI/接口/特效/粒子.md#getparticlemaxnum)      |客户端|                                         获取粒子发射器包含的最大粒子数量。                                          |
|     [GetParticleMaxSize](./1-ModAPI/接口/特效/粒子.md#getparticlemaxsize)     |客户端|                                          获取粒子特效中粒子大小的最大值。                                          |
|     [GetParticleMinSize](./1-ModAPI/接口/特效/粒子.md#getparticleminsize)     |客户端|                                          获取粒子特效中粒子大小的最小值。                                          |
|  [GetParticleVolumeSize](./1-ModAPI/接口/特效/粒子.md#getparticlevolumesize)  |客户端|                                          获取粒子发射器的体积大小缩放值。                                          |
|                 [GetPos](./1-ModAPI/接口/特效/粒子.md#getpos)                 |客户端|                                           获取粒子发射器的世界坐标位置                                           |
|                 [GetRot](./1-ModAPI/接口/特效/粒子.md#getrot)                 |客户端|                                            获取粒子发射器的旋转角度                                            |
|                  [Pause](./1-ModAPI/接口/特效/粒子.md#pause)                  |客户端|                                    暂停播放，粒子定格在当前时刻，再次调用Play时继续播放                                    |
|                   [Play](./1-ModAPI/接口/特效/粒子.md#play)                   |客户端|                                               播放粒子特效                                               |
|        [SetFadeDistance](./1-ModAPI/接口/特效/粒子.md#setfadedistance)        |客户端|                     设置粒子开始自动调整透明度的距离。粒子与摄像机之间的距离小于该值时会自动调整粒子的透明度，距离摄像机越近，粒子越透明                     |
|              [SetGlobal](./1-ModAPI/接口/特效/粒子.md#setglobal)              |客户端|                                    设置粒子发射器是否为全局粒子发射器, 默认是False                                     |
|               [SetLayer](./1-ModAPI/接口/特效/粒子.md#setlayer)               |客户端|粒子默认层级为1，当层级不为1时表示该特效开启特效分层渲染功能。特效（粒子和帧动画）分层渲染时，层级越高渲染越靠后，层级大的会遮挡层级低的，且同一层级的特效会根据特效的相对位置产生正确的相互遮挡关系。|
|[SetParticleEmissionRate](./1-ModAPI/接口/特效/粒子.md#setparticleemissionrate)|客户端|         设置粒子发射器每帧发射粒子的频率，频率越大则每帧发射的粒子数量越多，但粒子数量不会超过粒子发射器的粒子容量，同时由于性能考虑，每帧发射的粒子数量也不会超过100个。         |
|      [SetParticleMaxNum](./1-ModAPI/接口/特效/粒子.md#setparticlemaxnum)      |客户端|          设置粒子发射器的粒子容量，即粒子发射器所包含的最大粒子数量。该数量并不代表目前粒子发射器所发射的粒子数量，如需要增加发射的粒子数量，需同时改变粒子的发射频率。           |
|        [SetParticleSize](./1-ModAPI/接口/特效/粒子.md#setparticlesize)        |客户端|                                        设置粒子特效中粒子大小的最小值及最大值。                                        |
|  [SetParticleVolumeSize](./1-ModAPI/接口/特效/粒子.md#setparticlevolumesize)  |客户端|                          设置粒子发射器的体积大小缩放，不影响单个粒子的尺寸。粒子发射器的体积越大，则粒子的发射范围越大。                          |
|                 [SetPos](./1-ModAPI/接口/特效/粒子.md#setpos)                 |客户端|                                           设置粒子发射器的世界坐标位置                                           |
|            [SetRelative](./1-ModAPI/接口/特效/粒子.md#setrelative)            |客户端|           当粒子绑定了entity或骨骼模型时，发射出的粒子使用entity坐标系还是世界坐标系。与mcstudio特效编辑器中粒子的“相对挂点运动”选项功能相同。            |
|           [SetRotUseZXY](./1-ModAPI/接口/特效/粒子.md#setrotusezxy)           |客户端|                                     设置粒子发射器的旋转，旋转顺序按照绕z,x,y轴旋转                                     |
|   [SetUsePointFiltering](./1-ModAPI/接口/特效/粒子.md#setusepointfiltering)   |客户端|                                  设置粒子材质的纹理滤波是否使用点滤波方法。默认为使用双线性滤波                                   |
|                   [Stop](./1-ModAPI/接口/特效/粒子.md#stop)                   |客户端|                                               停止粒子播放                                               |

####  模型特效 ####

|                                                 接口                                                  |   |                                                                             描述                                                                             |
|-----------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------------------------------------------------------------------------------|
|[CreateEngineEffectBind](./1-ModAPI/接口/特效/模型特效.md#createengineeffectbind)|客户端|指用编辑器保存资源包中models/bind/xxx\_bind.json生成编辑好的所有挂点的所有特效。生成的特效会自动进行挂接及播放，编辑器中设为不可见的特效也会进行播放。并且使用这种方式创建的特效，开发者不用维护entity进出视野导致的挂接特效被移除，引擎会在entity每次进入视野时自动创建所有特效。|
|                 [Pause](./1-ModAPI/接口/特效/模型特效.md#pause)                 |客户端|                                                           暂停模型特效（即使用CreateEngineEffectBind创建的特效）                                                           |
|                [Resume](./1-ModAPI/接口/特效/模型特效.md#resume)                |客户端|                                                          继续播放模型特效（即使用CreateEngineEffectBind创建的特效）                                                          |

####  微软粒子 ####

|                                              接口                                               |   |                   描述                   |
|-----------------------------------------------------------------------------------------------|---|----------------------------------------|
|         [BindEntity](./1-ModAPI/接口/特效/微软粒子.md#bindentity)         |客户端|           绑定粒子发射器到指定实体的指定骨骼上           |
|          [BindModel](./1-ModAPI/接口/特效/微软粒子.md#bindmodel)          |客户端|          绑定粒子发射器到指定骨骼模型的指定骨骼上          |
|             [Create](./1-ModAPI/接口/特效/微软粒子.md#create)             |客户端|            创建粒子发射器, 创建后立即播放            |
|[CreateBindEntityNew](./1-ModAPI/接口/特效/微软粒子.md#createbindentitynew)|客户端|     创建粒子发射器并绑定到指定实体的指定骨骼上, 创建后立即播放     |
|       [EmitManually](./1-ModAPI/接口/特效/微软粒子.md#emitmanually)       |客户端|                手动发射粒子一次                |
|              [Exist](./1-ModAPI/接口/特效/微软粒子.md#exist)              |客户端|             判断指定粒子发射器是否存在              |
|  [GetActiveDuration](./1-ModAPI/接口/特效/微软粒子.md#getactiveduration)  |客户端|              获取粒子发射器的激活周期              |
|       [GetBindingID](./1-ModAPI/接口/特效/微软粒子.md#getbindingid)       |客户端|          返回粒子绑定的实体id，没有则返回"0"          |
|  [GetBindingModelID](./1-ModAPI/接口/特效/微软粒子.md#getbindingmodelid)  |客户端|          返回绑定的骨骼模型id 没有则返回-1           |
|        [GetDuration](./1-ModAPI/接口/特效/微软粒子.md#getduration)        |客户端|         获取粒子发射器的播放周期(激活+休眠时间)          |
|      [GetFacingMode](./1-ModAPI/接口/特效/微软粒子.md#getfacingmode)      |客户端|             返回粒子发射器的粒子朝向模式             |
|         [GetLoopAge](./1-ModAPI/接口/特效/微软粒子.md#getloopage)         |客户端|          获取粒子发射器当前播放周期内已播放的时间          |
|             [GetPos](./1-ModAPI/接口/特效/微软粒子.md#getpos)             |客户端|               获取粒子发射器位置                |
|             [GetRot](./1-ModAPI/接口/特效/微软粒子.md#getrot)             |客户端|              获取粒子发射器局部旋转               |
|   [GetSleepDuration](./1-ModAPI/接口/特效/微软粒子.md#getsleepduration)   |客户端|              获取粒子发射器的休眠周期              |
|       [GetTimeScale](./1-ModAPI/接口/特效/微软粒子.md#gettimescale)       |客户端|              获取粒子发射器的播放速度              |
|        [GetVariable](./1-ModAPI/接口/特效/微软粒子.md#getvariable)        |客户端|           获取粒子发射器的Molang变量值            |
|               [Hide](./1-ModAPI/接口/特效/微软粒子.md#hide)               |客户端|              隐藏粒子发射器(不渲染)              |
|           [IsHiding](./1-ModAPI/接口/特效/微软粒子.md#ishiding)           |客户端|          返回粒子发射器是否正在被隐藏(不渲染)           |
|          [IsPausing](./1-ModAPI/接口/特效/微软粒子.md#ispausing)          |客户端|           返回粒子发射器的逻辑是否正在被暂停            |
|              [Pause](./1-ModAPI/接口/特效/微软粒子.md#pause)              |客户端|          暂停粒子发射器的逻辑更新，但保持渲染状态          |
|               [Play](./1-ModAPI/接口/特效/微软粒子.md#play)               |客户端|                播放粒子发射器                 |
|             [PlayAt](./1-ModAPI/接口/特效/微软粒子.md#playat)             |客户端|              设置粒子发射器播放时间点              |
|             [Remove](./1-ModAPI/接口/特效/微软粒子.md#remove)             |客户端|               销毁指定粒子发射器                |
|       [RemoveByName](./1-ModAPI/接口/特效/微软粒子.md#removebyname)       |客户端|销毁场景中指定名称(粒子发射器json中的identifier)的所有粒子发射器|
|             [Replay](./1-ModAPI/接口/特效/微软粒子.md#replay)             |客户端|                重播粒子发射器                 |
|             [Resume](./1-ModAPI/接口/特效/微软粒子.md#resume)             |客户端|          恢复粒子发射器的逻辑更新，不影响渲染状态          |
|             [SetPos](./1-ModAPI/接口/特效/微软粒子.md#setpos)             |客户端|               设置粒子发射器位置                |
|        [SetRelative](./1-ModAPI/接口/特效/微软粒子.md#setrelative)        |客户端|            设置粒子是否在局部空间进行计算             |
|             [SetRot](./1-ModAPI/接口/特效/微软粒子.md#setrot)             |客户端|              设置粒子发射器局部旋转               |
|       [SetRotUseZXY](./1-ModAPI/接口/特效/微软粒子.md#setrotusezxy)       |客户端|      设置粒子发射器局部旋转，旋转顺序按照绕z,x,y轴旋转       |
|       [SetTimeScale](./1-ModAPI/接口/特效/微软粒子.md#settimescale)       |客户端|              设置粒子发射器的播放速度              |
|        [SetVariable](./1-ModAPI/接口/特效/微软粒子.md#setvariable)        |客户端|           设置粒子发射器的Molang变量值            |
|               [Show](./1-ModAPI/接口/特效/微软粒子.md#show)               |客户端|             显示粒子发射器(开启渲染)              |
|               [Stop](./1-ModAPI/接口/特效/微软粒子.md#stop)               |客户端|          停止粒子发射器播放(不渲染且不更新逻辑)          |
|             [Unbind](./1-ModAPI/接口/特效/微软粒子.md#unbind)             |客户端|             解除指定粒子发射器的绑定状态             |

####  模型 ####

|                                                           接口                                                           |   |                                                                                                                               描述                                                                                                                               |
|------------------------------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                    [BindItemToBone](./1-ModAPI/接口/模型.md#binditemtobone)                    |客户端|                                                                                                                    将使用了骨骼模型的玩家的手持物绑定到指定的骨骼上                                                                                                                    |
|                 [BindModelToEntity](./1-ModAPI/接口/模型.md#bindmodeltoentity)                 |客户端|                                                                                                                     实体替换骨骼模型后，再往上挂接其他骨骼模型。                                                                                                                     |
|                  [BindModelToModel](./1-ModAPI/接口/模型.md#bindmodeltomodel)                  |客户端|                                                                                                                         在骨骼模型上挂接其他骨骼模型                                                                                                                         |
|                 [CancelAllBoneMask](./1-ModAPI/接口/模型.md#cancelallbonemask)                 |客户端|                                                                                                                         取消动画中的所有骨骼屏蔽。                                                                                                                          |
|                   [CreateFreeModel](./1-ModAPI/接口/模型.md#createfreemodel)                   |客户端|                                                                                                                      创建自由的模型（无需绑定Entity）                                                                                                                       |
|           [GetAllBindModelToEntity](./1-ModAPI/接口/模型.md#getallbindmodeltoentity)           |客户端|                                                                                                                     获取实体上某个骨骼上挂接的所有骨骼模型的id                                                                                                                     |
|                     [GetAnimLength](./1-ModAPI/接口/模型.md#getanimlength)                     |客户端|                                                                                                                        获取某个骨骼动画的长度，单位为秒                                                                                                                        |
|[GetBonePositionFromMinecraftObject](./1-ModAPI/接口/模型.md#getbonepositionfromminecraftobject)|客户端|                                                                                                                         获取原版模型的骨骼世界坐标                                                                                                                          |
|                   [GetBoneWorldPos](./1-ModAPI/接口/模型.md#getboneworldpos)                   |客户端|                                                                                                                            获取骨骼的坐标                                                                                                                             |
|             [GetEntityBoneWorldPos](./1-ModAPI/接口/模型.md#getentityboneworldpos)             |客户端|                                                                                                                        获取换了骨骼模型的实体的骨骼坐标                                                                                                                        |
|                    [GetEntityScale](./1-ModAPI/接口/模型.md#getentityscale)                    |服务端|                                                                                                                          获取实体的放缩比例大小                                                                                                                           |
|              [GetExtraUniformValue](./1-ModAPI/接口/模型.md#getextrauniformvalue)              |客户端|                                                                                                                获取在骨骼模型shader中使用的自定义变量Uniform的值                                                                                                                 |
|                        [GetModelId](./1-ModAPI/接口/模型.md#getmodelid)                        |客户端|                                                                                                                     获取骨骼模型的Id，主要用于特效绑定骨骼模型                                                                                                                     |
|                  [GetModelMaterial](./1-ModAPI/接口/模型.md#getmodelmaterial)                  |客户端|                                          获取骨骼模型的正在使用的材质名称，也可获取骨骼模型中指定骨骼所使用的[材质名称](../../../mcguide/16-美术/6-模型和动作/04-骨骼模型的使用.html#7.模型使用自定义材质及更多贴图)。如果获取指定骨骼所使用的材质，需要先在netease\_model.json下设置"useSplitMeshes"字段为true。                                           |
|                      [GetModelName](./1-ModAPI/接口/模型.md#getmodelname)                      |服务端|                                                                                                                           获取实体的模型名称                                                                                                                            |
|                     [GetModelStyle](./1-ModAPI/接口/模型.md#getmodelstyle)                     |客户端|                                                                                                                             获取模型类型                                                                                                                             |
|                [GetPlayingAnimList](./1-ModAPI/接口/模型.md#getplayinganimlist)                |客户端|                                                                                                                   获取指定的骨骼模型中正处于播放状态的骨骼动画名称列表                                                                                                                   |
|                        [GetTexture](./1-ModAPI/接口/模型.md#gettexture)                        |客户端|                                                                                                                          获取骨骼模型的贴图路径                                                                                                                           |
|                         [HideModel](./1-ModAPI/接口/模型.md#hidemodel)                         |客户端|                                                                                                                             隐藏纯模型                                                                                                                              |
|                      [ModelPlayAni](./1-ModAPI/接口/模型.md#modelplayani)                      |客户端|                                                                                          纯骨骼播放动作。 支持骨骼动画混合，可参考SetAnimationBoneMask接口以及RegisterAnim1DControlParam接口说明。                                                                                          |
|                      [ModelStopAni](./1-ModAPI/接口/模型.md#modelstopani)                      |客户端|                                                                                                                           暂停指定的骨骼动画                                                                                                                            |
|                          [PlayAnim](./1-ModAPI/接口/模型.md#playanim)                          |客户端|                                                                                                                             播放骨骼动画                                                                                                                             |
|        [RegisterAnim1DControlParam](./1-ModAPI/接口/模型.md#registeranim1dcontrolparam)        |客户端|                                                                                 当同时播放多个骨骼动画时，新建用于控制动画进行1D线性混合的参数。目前线性混合仅支持对两个动画进行混合。新建的参数值范围为[0,1]。指定的骨骼将会按照这个参数的值对两个动画进行线性混合。                                                                                 |
|   [RegisterAnim1DMultiControlParam](./1-ModAPI/接口/模型.md#registeranim1dmulticontrolparam)   |客户端|                                                                                                               当同时播放多个骨骼动画时，注册用于根据权重控制多动画进行混合的参数                                                                                                                |
|     [RemoveAnim1DMultiControlParam](./1-ModAPI/接口/模型.md#removeanim1dmulticontrolparam)     |客户端|                                                                                                                      删除用于根据权重控制多动画进行混合的参数                                                                                                                      |
|                   [RemoveFreeModel](./1-ModAPI/接口/模型.md#removefreemodel)                   |客户端|                                                                                                                             移除自由模型                                                                                                                             |
|                        [ResetModel](./1-ModAPI/接口/模型.md#resetmodel)                        |客户端|                                                                                                                           恢复实体为原版模型                                                                                                                            |
|             [SetAnim1DControlParam](./1-ModAPI/接口/模型.md#setanim1dcontrolparam)             |客户端|                                                                                                                 新建动画的1D控制参数后，使用该接口对相应的参数进行控制。                                                                                                                  |
|        [SetAnim1DMultiControlParam](./1-ModAPI/接口/模型.md#setanim1dmulticontrolparam)        |客户端|                                                                                                               新建动画的1D控制参数后，设置用于根据权重控制多动画进行混合的参数                                                                                                                |
|                      [SetAnimLayer](./1-ModAPI/接口/模型.md#setanimlayer)                      |客户端|                                                                                                设置骨骼动画的层级，动画层级越大，则优先度越高，骨骼模型的骨骼优先播放优先度最高的动画，相同层级的动画则优先播放率先播放的动画。                                                                                                |
|                      [SetAnimSpeed](./1-ModAPI/接口/模型.md#setanimspeed)                      |客户端|                                                                                                                         设置某个骨骼动画的播放速度                                                                                                                          |
|           [SetAnimationAllBoneMask](./1-ModAPI/接口/模型.md#setanimationallbonemask)           |客户端|                                                         设置是否屏蔽动画中所有骨骼的动画，若开启骨骼屏蔽后，该骨骼将不再播放该动画中的动作。该接口会对该动画中所有骨骼生效，可通过参数ignoreBoneList来指定不受影响的骨骼名称。通过屏蔽指定骨骼的动画可实现同一个骨骼模型同时在不同骨骼上播放不同的动作动画，从而实现快捷的动作融合。                                                          |
|              [SetAnimationBoneMask](./1-ModAPI/接口/模型.md#setanimationbonemask)              |客户端|                                                                                 设置是否屏蔽动画中指定的骨骼的动画，若开启骨骼屏蔽后，该骨骼将不再播放该动画中的动作。通过屏蔽指定骨骼的动画可实现同一个骨骼模型同时在不同骨骼上播放不同的动作动画，从而实现快捷的动作融合。                                                                                 |
|                     [SetBrightness](./1-ModAPI/接口/模型.md#setbrightness)                     |客户端|                                                                                                                            设置实体的亮度                                                                                                                             |
|                  [SetEntityOpacity](./1-ModAPI/接口/模型.md#setentityopacity)                  |客户端|                                                                                                          设置骨骼模型的透明度，只能对骨骼模型生效，如果设置的是原版模型，则模型的影子会被隐藏。                                                                                                           |
|                    [SetEntityScale](./1-ModAPI/接口/模型.md#setentityscale)                    |服务端|                                                                                               设置实体的放缩比例大小，设置比例过大会导致游戏卡顿，建议控制在20倍以内。实体的scale的立方乘以包围盒的体积不可超过32768                                                                                                |
|               [SetEntityShadowShow](./1-ModAPI/接口/模型.md#setentityshadowshow)               |客户端|                                                                                                                         设置实体打开/关闭影子渲染                                                                                                                          |
|              [SetExtraUniformValue](./1-ModAPI/接口/模型.md#setextrauniformvalue)              |客户端|                                                                                                                      设置shader中特定Uniform的值                                                                                                                      |
|              [SetFreeModelAniSpeed](./1-ModAPI/接口/模型.md#setfreemodelanispeed)              |客户端|                                                                                                                         设置自由模型动画的播放速度                                                                                                                          |
|           [SetFreeModelBoundingBox](./1-ModAPI/接口/模型.md#setfreemodelboundingbox)           |客户端|                                                                                                                           设置自由模型的包围盒                                                                                                                           |
|                   [SetFreeModelPos](./1-ModAPI/接口/模型.md#setfreemodelpos)                   |客户端|                                                                                                                           设置自由模型的位置                                                                                                                            |
|                   [SetFreeModelRot](./1-ModAPI/接口/模型.md#setfreemodelrot)                   |客户端|                                                                                                                           设置自由模型的方向                                                                                                                            |
|                 [SetFreeModelScale](./1-ModAPI/接口/模型.md#setfreemodelscale)                 |客户端|                                                                                                                           设置自由模型的大小                                                                                                                            |
|                  [SetLegacyBindRot](./1-ModAPI/接口/模型.md#setlegacybindrot)                  |客户端|                                                                                                                        用于修复特效挂接到骨骼时的方向                                                                                                                         |
|                          [SetModel](./1-ModAPI/接口/模型.md#setmodel)                          |服务端|                                                                                                                             设置骨骼模型                                                                                                                             |
|                          [SetModel](./1-ModAPI/接口/模型.md#setmodel)                          |客户端|                                                                                                                           替换实体的骨骼模型                                                                                                                            |
|                  [SetModelMaterial](./1-ModAPI/接口/模型.md#setmodelmaterial)                  |客户端|设置骨骼模型所使用的的材质，除了可以设置骨骼模型所使用的[自定义材质](../../../mcguide/16-美术/6-模型和动作/04-骨骼模型的使用.html#7.模型使用自定义材质及更多贴图)以外，也可对单个骨骼设置所使用的[自定义材质](../../../mcguide/16-美术/6-模型和动作/04-骨骼模型的使用.html#7.模型使用自定义材质及更多贴图)。如果需要设置单个骨骼所使用的材质，需要先在netease\_model.json下设置"useSplitMeshes"字段为true。|
|         [SetModelMultiPassMaterial](./1-ModAPI/接口/模型.md#setmodelmultipassmaterial)         |客户端|                                     设置骨骼模型多pass中使用到的[材质列表](../../../mcguide/16-美术/6-模型和动作/04-骨骼模型的使用.html#9.骨骼模型自定义多pass)，也可对单个骨骼设置所使用的自定义多Pass材质。如果需要设置单个骨骼所使用的多Pass材质，需要先在netease\_model.json下设置"useSplitMeshes"字段为true。                                     |
|                    [SetModelOffset](./1-ModAPI/接口/模型.md#setmodeloffset)                    |服务端|                                                                                                                设置骨骼模型相对于局部坐标系的偏移量，初始值为(0, 0, 0)                                                                                                                |
|                    [SetModelOffset](./1-ModAPI/接口/模型.md#setmodeloffset)                    |客户端|                                                                                                                            模型增加偏移量                                                                                                                             |
|               [SetModelPartVisible](./1-ModAPI/接口/模型.md#setmodelpartvisible)               |客户端|                                                                                                                对骨骼模型中指定的骨骼进行渲染屏蔽，屏蔽后该骨骼不会被渲染出来。                                                                                                                |
|         [SetModelPerspectiveEffect](./1-ModAPI/接口/模型.md#setmodelperspectiveeffect)         |客户端|                                                                                                                     设置模型透视效果。注：只对自定义骨骼模型生效                                                                                                                     |
|                   [SetModelTexture](./1-ModAPI/接口/模型.md#setmodeltexture)                   |服务端|                                                                                                             设置骨骼模型贴图，该接口与SetTexture功能相同，但属于服务端接口。                                                                                                              |
|                   [SetShowArmModel](./1-ModAPI/接口/模型.md#setshowarmmodel)                   |客户端|                                                              设置使用骨骼模型后切换至第一人称时是否显示手部模型。需要先为骨骼模型定义arm\_model，arm\_model的定义可参考demo示例-AwesomeMod中的resourcePack/models/netease\_models.json中的大天狗模型定义                                                               |
|                        [SetTexture](./1-ModAPI/接口/模型.md#settexture)                        |客户端|                                                                                                          设置骨骼模型的贴图，该接口与SetModelTexture功能相同，但属于客户端接口。                                                                                                           |
|               [ShowCommonHurtColor](./1-ModAPI/接口/模型.md#showcommonhurtcolor)               |服务端|                                                                                                                    设置挂接骨骼模型的实体是否显示通用的受伤变红效果                                                                                                                    |
|               [ShowCommonHurtColor](./1-ModAPI/接口/模型.md#showcommonhurtcolor)               |客户端|                                                                                                                    设置挂接骨骼模型的实体是否显示通用的受伤变红效果                                                                                                                    |
|                         [ShowModel](./1-ModAPI/接口/模型.md#showmodel)                         |客户端|                                                                                                                             显示纯模型                                                                                                                              |
|               [UnBindModelToEntity](./1-ModAPI/接口/模型.md#unbindmodeltoentity)               |客户端|                                                                                                取消实体上挂接的某个骨骼模型。取消挂接后，这个modelId的模型便会销毁，无法再使用，如果是临时隐藏可以使用HideModel                                                                                                |
|                [UnBindModelToModel](./1-ModAPI/接口/模型.md#unbindmodeltomodel)                |客户端|                                                                                               取消骨骼模型上挂接的某个骨骼模型。取消挂接后，这个modelId的模型便会销毁，无法再使用，如果是临时隐藏可以使用HideModel                                                                                               |

####  原生UI ####

|                                                 接口                                                 |   |                                                                                                                                                     描述                                                                                                                                                      |
|----------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|       [ChangeSneakState](./1-ModAPI/接口/原生UI.md#changesneakstate)       |客户端|                                                                                                                                                   切换潜行状态                                                                                                                                                    |
|       [ClickInteractGUI](./1-ModAPI/接口/原生UI.md#clickinteractgui)       |客户端|                                                                                                                                     模拟点击交互按钮，交互按钮指的在喂食、钓鱼、交易等交互场景出现的按钮                                                                                                                                      |
|    [GetOriginAreaOffset](./1-ModAPI/接口/原生UI.md#getoriginareaoffset)    |客户端|                                                                                                                                          获取指定原生UI的offset,包括左上角和右下角                                                                                                                                          |
|          [GetScreenSize](./1-ModAPI/接口/原生UI.md#getscreensize)          |客户端|                                                                                                                                                   获取游戏分辨率                                                                                                                                                   |
|      [GetScreenViewInfo](./1-ModAPI/接口/原生UI.md#getscreenviewinfo)      |客户端|获取游戏视角信息。首先获得当前分辨率下UI放大倍数，计算方式可参考[《我的世界》界面适配方法](../../../mcguide/18-界面与交互/1-界面编辑器使用说明.html#《我的世界》界面适配方法)。则当前游戏视角的宽度的计算方式为：若当前分辨率的宽度能被该放大倍数整除，则等于当前分辨率，若不能，则等于当前分辨率加放大倍数再减去当前分辨率对放大倍数求余的结果，当前游戏视角的高度计算方法类似。例：以分辨率为1792，828的手机计算，画布是分辨率的3倍，所以x = 1792 + 3 - 1 = 1794；y = 828，该接口返回的结果为(1794.0, 828.0, 0.0, 0.0)|
|           [GetWalkState](./1-ModAPI/接口/原生UI.md#getwalkstate)           |客户端|                                                                                                                                               获取玩家行走/潜行/跑步状态                                                                                                                                                |
|       [HideAirSupplyGUI](./1-ModAPI/接口/原生UI.md#hideairsupplygui)       |客户端|                                                                                                                                                  隐藏玩家氧气值界面                                                                                                                                                  |
|           [HideArmorGui](./1-ModAPI/接口/原生UI.md#hidearmorgui)           |客户端|                                                                                                                                                隐藏hud界面的护甲值显示                                                                                                                                                |
|    [HideChangePersonGui](./1-ModAPI/接口/原生UI.md#hidechangepersongui)    |客户端|                                                                                                                                           隐藏切换人称的按钮。隐藏后点击相应位置不会响应                                                                                                                                           |
|            [HideChatGUI](./1-ModAPI/接口/原生UI.md#hidechatgui)            |客户端|                                                                                                                                          隐藏聊天按钮原生UI。该接口在开启新版聊天时不生效                                                                                                                                          |
|       [HideCrossHairGUI](./1-ModAPI/接口/原生UI.md#hidecrosshairgui)       |客户端|                                                                                                                                               隐藏hud界面的十字准心显示                                                                                                                                                |
|           [HideEmoteGUI](./1-ModAPI/接口/原生UI.md#hideemotegui)           |客户端|                                                                                                                            设置是否开启表情功能，默认PC端关闭，手机端开启，且该接口只能在手机端使用。该接口在开启新版聊天时不生效                                                                                                                             |
|             [HideExpGui](./1-ModAPI/接口/原生UI.md#hideexpgui)             |客户端|                                                                                                                                               非创造者模式下隐藏经验条显示                                                                                                                                                |
|            [HideFoldGUI](./1-ModAPI/接口/原生UI.md#hidefoldgui)            |客户端|                                                                                                                                                 隐藏下拉按钮原生UI。                                                                                                                                                 |
|          [HideHealthGui](./1-ModAPI/接口/原生UI.md#hidehealthgui)          |客户端|                                                                                                                                                隐藏hud界面的血量显示                                                                                                                                                 |
|     [HideHorseHealthGui](./1-ModAPI/接口/原生UI.md#hidehorsehealthgui)     |客户端|                                                                                                                                               隐藏hud界面的坐骑的血量显示                                                                                                                                               |
|             [HideHudGUI](./1-ModAPI/接口/原生UI.md#hidehudgui)             |客户端|                                                                                                                              隐藏HUD游戏界面的游戏原生UI。与原版F1按钮效果一致，只隐藏显示，但点击跳跃键等位置依然会响应                                                                                                                              |
|          [HideHungerGui](./1-ModAPI/接口/原生UI.md#hidehungergui)          |客户端|                                                                                                                                                隐藏hud界面的饥饿值显示                                                                                                                                                |
|        [HideInteractGui](./1-ModAPI/接口/原生UI.md#hideinteractgui)        |客户端|                                                                                                                                            隐藏交互按钮。隐藏后点击相应位置不会响应                                                                                                                                             |
|            [HideJumpGui](./1-ModAPI/接口/原生UI.md#hidejumpgui)            |客户端|                                                                                                                                         隐藏游戏中右下角的跳跃按钮。隐藏后点击相应位置不会响应                                                                                                                                         |
|            [HideMoveGui](./1-ModAPI/接口/原生UI.md#hidemovegui)            |客户端|                                                                                                                                         隐藏游戏中左下角的移动按钮。隐藏后点击相应位置不会响应                                                                                                                                         |
|    [HideNeteaseStoreGui](./1-ModAPI/接口/原生UI.md#hideneteasestoregui)    |客户端|                                                                                                                                         隐藏游戏中的网易商店按钮。隐藏后点击相应位置不会响应                                                                                                                                          |
|           [HidePauseGUI](./1-ModAPI/接口/原生UI.md#hidepausegui)           |客户端|                                                                                                                                                 隐藏暂停按钮原生UI。                                                                                                                                                 |
|         [HideSlotBarGui](./1-ModAPI/接口/原生UI.md#hideslotbargui)         |客户端|                                                                                                                                               隐藏游戏中底部中间的物品栏界面                                                                                                                                               |
|           [HideSneakGui](./1-ModAPI/接口/原生UI.md#hidesneakgui)           |客户端|                                                                                                                                      隐藏游戏中左下角方向键的中心处潜行按钮。隐藏后点击相应位置不会响应                                                                                                                                      |
|            [HideSwimGui](./1-ModAPI/接口/原生UI.md#hideswimgui)            |客户端|                                                                                                                                          隐藏游戏中的浮潜按钮。隐藏后点击相应位置不会响应。                                                                                                                                          |
|           [HideVoiceGUI](./1-ModAPI/接口/原生UI.md#hidevoicegui)           |客户端|                                                                                                                                          隐藏语音按钮原生UI。该接口在开启新版聊天时不生效                                                                                                                                          |
|            [HideWalkGui](./1-ModAPI/接口/原生UI.md#hidewalkgui)            |客户端|                                                                                                                                          隐藏游戏中跑/走按钮。隐藏后点击相应位置不会响应                                                                                                                                           |
|            [OpenChatGui](./1-ModAPI/接口/原生UI.md#openchatgui)            |客户端|                                                                                                                                                   打开原版聊天栏                                                                                                                                                   |
|           [OpenEmoteGui](./1-ModAPI/接口/原生UI.md#openemotegui)           |客户端|                                                                                                                                                   打开表情界面                                                                                                                                                    |
|            [OpenFoldGui](./1-ModAPI/接口/原生UI.md#openfoldgui)            |客户端|                                                                                                                                                  打开原版下拉界面                                                                                                                                                   |
|       [OpenInventoryGui](./1-ModAPI/接口/原生UI.md#openinventorygui)       |客户端|                                                                                                                                        打开原版背包界面，并支持选中某个分页(支持自定义分页名称)                                                                                                                                        |
|    [OpenNeteaseStoreGui](./1-ModAPI/接口/原生UI.md#openneteasestoregui)    |客户端|                                                                                                                                              打开游戏中的网易商店购买商品界面                                                                                                                                               |
|           [OpenPauseGui](./1-ModAPI/接口/原生UI.md#openpausegui)           |客户端|                                                                                                                                                  打开原版暂停界面                                                                                                                                                   |
|          [OpenReportGui](./1-ModAPI/接口/原生UI.md#openreportgui)          |客户端|                                                                                                                                                  打开原版举报界面                                                                                                                                                   |
|  [PlayHudHeartBlinkAnim](./1-ModAPI/接口/原生UI.md#playhudheartblinkanim)  |客户端|                                                                                                                                               播放原版受伤时血量变化的动效                                                                                                                                                |
|           [SetCrossHair](./1-ModAPI/接口/原生UI.md#setcrosshair)           |客户端|                                                                                                                                                设置是否使用“准星瞄准”                                                                                                                                                 |
|         [SetEmoteSwitch](./1-ModAPI/接口/原生UI.md#setemoteswitch)         |客户端|                                                                                                                             设置是否开启表情功能，默认PC端关闭，手机端开启，且该接口只能在手机端使用，在原生UI初始化前调用设置                                                                                                                             |
|[SetHudChatStackPosition](./1-ModAPI/接口/原生UI.md#sethudchatstackposition)|客户端|                                                                                                                                              设置HUD界面左上小聊天窗口位置                                                                                                                                               |
| [SetHudChatStackVisible](./1-ModAPI/接口/原生UI.md#sethudchatstackvisible) |客户端|                                                                                                                                              设置HUD界面左上小聊天窗口可见性                                                                                                                                              |
|            [SetResponse](./1-ModAPI/接口/原生UI.md#setresponse)            |客户端|                                                                                                                                                 设置原生UI是否响应                                                                                                                                                  |
|           [SimulateJump](./1-ModAPI/接口/原生UI.md#simulatejump)           |客户端|                                                                                                                                                    模拟跳跃                                                                                                                                                     |

####  通用 ####

|                                                          接口                                                          |   |                                                  描述                                                   |
|----------------------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------------------------------|
|                [CheckCanBindUI](./1-ModAPI/接口/自定义UI/通用.md#checkcanbindui)                |客户端|检查实体是否可以绑定头顶UI，如何将UI与实体绑定详见[CreateUI](./1-ModAPI/接口/自定义UI/通用.md#createui)接口|
|                      [CreateUI](./1-ModAPI/接口/自定义UI/通用.md#createui)                      |客户端|              创建UI，详见[界面创建流程及生命周期](../../../mcguide/18-界面与交互/30-UI说明文档.html#界面创建流程及生命周期)               |
|         [EnableFontBatchRender](./1-ModAPI/接口/自定义UI/通用.md#enablefontbatchrender)         |客户端|                                               是否开启字体合批                                                |
|    [GetCustomUIControlProxyCls](./1-ModAPI/接口/自定义UI/通用.md#getcustomuicontrolproxycls)    |客户端|                                            获得原生界面自定义UI代理基类                                            |
|       [GetMiniMapScreenNodeCls](./1-ModAPI/接口/自定义UI/通用.md#getminimapscreennodecls)       |客户端|                                           获取小地图ScreenNode基类                                           |
|     [GetNativeScreenManagerCls](./1-ModAPI/接口/自定义UI/通用.md#getnativescreenmanagercls)     |客户端|                                        获得NativeScreenManager类                                         |
|              [GetScreenNodeCls](./1-ModAPI/接口/自定义UI/通用.md#getscreennodecls)              |客户端|                                             获得ScreenNode类                                             |
|                  [GetTopScreen](./1-ModAPI/接口/自定义UI/通用.md#gettopscreen)                  |客户端|                                             获取UI堆栈栈顶的UI节点                                             |
|                      [GetTopUI](./1-ModAPI/接口/自定义UI/通用.md#gettopui)                      |客户端|                                              获取UI栈顶的UI名称                                              |
|                  [GetTopUINode](./1-ModAPI/接口/自定义UI/通用.md#gettopuinode)                  |客户端|     获取Push进来的最顶层界面，包括原生界面，详见[ 界面创建流程及生命周期 ](../../../mcguide/18-界面与交互/30-UI说明文档.html#界面创建流程及生命周期)     |
|                         [GetUI](./1-ModAPI/接口/自定义UI/通用.md#getui)                         |客户端|             获取UI节点，详见[界面创建流程及生命周期](../../../mcguide/18-界面与交互/30-UI说明文档.html#界面创建流程及生命周期)              |
|           [GetUIScreenProxyCls](./1-ModAPI/接口/自定义UI/通用.md#getuiscreenproxycls)           |客户端|                                           获得原生界面Screen代理基类                                            |
|              [GetViewBinderCls](./1-ModAPI/接口/自定义UI/通用.md#getviewbindercls)              |客户端|                                             获得ViewBinder类                                             |
|         [GetViewViewRequestCls](./1-ModAPI/接口/自定义UI/通用.md#getviewviewrequestcls)         |客户端|                                            获得ViewRequest类                                             |
|       [OpenDeveloperHomeWindow](./1-ModAPI/接口/自定义UI/通用.md#opendeveloperhomewindow)       |客户端|                                     打开网易资源中心开发者主页。该接口只能在横屏版本手机端使用                                     |
|[OpenResourceCenterDetailWindow](./1-ModAPI/接口/自定义UI/通用.md#openresourcecenterdetailwindow)|客户端|                                    打开网易资源中心组件详情界面。该接口只能在横屏版本手机端使用                                     |
|                     [PopScreen](./1-ModAPI/接口/自定义UI/通用.md#popscreen)                     |客户端|                                             使用堆栈管理的方式关闭UI                                             |
|                      [PopTopUI](./1-ModAPI/接口/自定义UI/通用.md#poptopui)                      |客户端|                                               弹出UI栈顶的UI                                               |
|                    [PushScreen](./1-ModAPI/接口/自定义UI/通用.md#pushscreen)                    |客户端|                                             使用堆栈管理的方式创建UI                                             |
|                    [RegisterUI](./1-ModAPI/接口/自定义UI/通用.md#registerui)                    |客户端|注册UI，创建UI前，需要先注册UI。同一UI只需要注册一次即可。详见[界面创建流程及生命周期](../../../mcguide/18-界面与交互/30-UI说明文档.html#界面创建流程及生命周期) |
|          [RegisterUIAnimations](./1-ModAPI/接口/自定义UI/通用.md#registeruianimations)          |客户端|                                                注册UI动画                                                 |
|         [UnregisterUIAnimation](./1-ModAPI/接口/自定义UI/通用.md#unregisteruianimation)         |客户端|                                               取消UI动画的注册                                               |

####  自定义书本 ####

|                                           接口                                            |   |   描述   |
|-----------------------------------------------------------------------------------------|---|--------|
|[GetBookManager](./1-ModAPI/接口/自定义UI/自定义书本.md#getbookmanager)|客户端|获取书本管理对象|

####  自定义成就系统 ####

|                                                        接口                                                         |   |          描述          |
|-------------------------------------------------------------------------------------------------------------------|---|----------------------|
|           [AddNodeProgress](./1-ModAPI/接口/自定义UI/自定义成就系统.md#addnodeprogress)           |服务端|  增加对应玩家的对应成就节点的成就进度  |
|[GetAchievementGatePosition](./1-ModAPI/接口/自定义UI/自定义成就系统.md#getachievementgateposition)|客户端|   获取自定义成就系统的入口按钮位置   |
|           [GetChildrenNode](./1-ModAPI/接口/自定义UI/自定义成就系统.md#getchildrennode)           |服务端|获得该成就节点的下一级所有孩子节点的list|
|         [GetNodeDetailInfo](./1-ModAPI/接口/自定义UI/自定义成就系统.md#getnodedetailinfo)         |服务端|    获取对应玩家的对应节点信息     |
|[SetAchievementGatePosition](./1-ModAPI/接口/自定义UI/自定义成就系统.md#setachievementgateposition)|客户端|   设置自定义成就系统的入口按钮位置   |
|             [SetNodeFinish](./1-ModAPI/接口/自定义UI/自定义成就系统.md#setnodefinish)             |服务端|   设置对应玩家的对应成就节点完成    |

####  UI界面 ####

|                                                  接口                                                  |   |                                                                    描述                                                                     |
|------------------------------------------------------------------------------------------------------|---|-------------------------------------------------------------------------------------------------------------------------------------------|
|[BindVirtualWorldModel](./1-ModAPI/接口/自定义UI/UI界面.md#bindvirtualworldmodel)|客户端|                                                                绑定虚拟世界中的模型                                                                 |
|  [ChangeBindAutoScale](./1-ModAPI/接口/自定义UI/UI界面.md#changebindautoscale)  |客户端|设置已绑定实体的UI是否根据绑定实体与本地玩家间的距离动态缩放，**只对已绑定实体的UI界面生效，如何将UI与实体绑定详见[CreateUI](./1-ModAPI/接口/自定义UI/通用.md#CreateUI)接口**|
|   [ChangeBindEntityId](./1-ModAPI/接口/自定义UI/UI界面.md#changebindentityid)   |客户端|           修改绑定的实体id，**只对已绑定实体的UI界面生效，如何将UI与实体绑定详见[CreateUI](./1-ModAPI/接口/自定义UI/通用.md#CreateUI)接口**           |
|     [ChangeBindOffset](./1-ModAPI/接口/自定义UI/UI界面.md#changebindoffset)     |客户端|         修改与绑定实体之间的偏移量，**只对已绑定实体的UI界面生效，如何将UI与实体绑定详见[CreateUI](./1-ModAPI/接口/自定义UI/通用.md#CreateUI)接口**         |
|                [Clone](./1-ModAPI/接口/自定义UI/UI界面.md#clone)                |客户端|                   克隆一个已有的控件，修改它的名称，并将它挂接到指定的父节点上，目前文本、图片、按钮控件的克隆控件表现正常，其他复杂控件的克隆控件可能存在运行问题，建议在json编写的过程中，手动复制一份对应控件使用。                    |
|               [Create](./1-ModAPI/接口/自定义UI/UI界面.md#create)               |客户端|                                                           UI生命周期函数，当UI创建成功时调用。                                                            |
|   [CreateChildControl](./1-ModAPI/接口/自定义UI/UI界面.md#createchildcontrol)   |客户端|                                                     在当前画布中创建子控件，如果该子控件已经存在则返回已存在的子控件                                                      |
|              [Destroy](./1-ModAPI/接口/自定义UI/UI界面.md#destroy)              |客户端|                                                            UI生命周期函数，当UI销毁时调用。                                                             |
|   [GetAllChildrenPath](./1-ModAPI/接口/自定义UI/UI界面.md#getallchildrenpath)   |客户端|                                                              获取所有子节点的路径list                                                               |
|     [GetBaseUIControl](./1-ModAPI/接口/自定义UI/UI界面.md#getbaseuicontrol)     |客户端|                                                           根据路径获取BaseUIControl实例                                                           |
|     [GetBindAutoScale](./1-ModAPI/接口/自定义UI/UI界面.md#getbindautoscale)     |客户端|                                                      获取该绑定实体的UI是否动态缩放，未绑定的UI将传回默认值1                                                       |
|      [GetBindEntityId](./1-ModAPI/接口/自定义UI/UI界面.md#getbindentityid)      |客户端|                                                       获取该UI绑定的实体id，未绑定的UI将传回默认值None                                                       |
|        [GetBindOffset](./1-ModAPI/接口/自定义UI/UI界面.md#getbindoffset)        |客户端|                                                    获取该UI绑定实体的偏移量，未绑定的UI将传回默认值(0, 0, 0)                                                    |
| [GetBindWorldPosition](./1-ModAPI/接口/自定义UI/UI界面.md#getbindworldposition) |客户端|                                                    获取该UI绑定的worldPosition，未绑定返回默认值None                                                     |
|      [GetChildrenName](./1-ModAPI/接口/自定义UI/UI界面.md#getchildrenname)      |客户端|                                                               获取子节点的名称list                                                                |
|             [GetIsHud](./1-ModAPI/接口/自定义UI/UI界面.md#getishud)             |客户端|                                                                获得本界面的输入模式                                                                 |
|      [GetRichTextItem](./1-ModAPI/接口/自定义UI/UI界面.md#getrichtextitem)      |客户端|                                                                返回一个富文本控件实例                                                                |
|        [GetScreenName](./1-ModAPI/接口/自定义UI/UI界面.md#getscreenname)        |客户端|                                                                 获得本界面的名称                                                                  |
|              [GetSelf](./1-ModAPI/接口/自定义UI/UI界面.md#getself)              |客户端|                                                                 获取零件界面自身                                                                  |
|             [OnActive](./1-ModAPI/接口/自定义UI/UI界面.md#onactive)             |客户端|                                                          UI生命周期函数，当UI重新回到栈顶时调用。                                                           |
|           [OnDeactive](./1-ModAPI/接口/自定义UI/UI界面.md#ondeactive)           |客户端|                                                         UI生命周期函数，当栈顶UI有其他UI入栈时调用。                                                         |
|   [RemoveChildControl](./1-ModAPI/接口/自定义UI/UI界面.md#removechildcontrol)   |客户端|                                                                移除当前画布中的子控件                                                                |
|      [RemoveComponent](./1-ModAPI/接口/自定义UI/UI界面.md#removecomponent)      |客户端|                                                                 动态删除某一控件                                                                  |
| [SetBindWorldPosition](./1-ModAPI/接口/自定义UI/UI界面.md#setbindworldposition) |客户端|                                                           设置UI绑定的worldPosition                                                            |
|             [SetIsHud](./1-ModAPI/接口/自定义UI/UI界面.md#setishud)             |客户端|                                                                设置本界面的输入模式                                                                 |
|            [SetRemove](./1-ModAPI/接口/自定义UI/UI界面.md#setremove)            |客户端|                                                                  删除本界面节点                                                                  |
|     [SetScreenVisible](./1-ModAPI/接口/自定义UI/UI界面.md#setscreenvisible)     |客户端|                                                                 设置是否显示本界面                                                                 |
|     [SetSelectControl](./1-ModAPI/接口/自定义UI/UI界面.md#setselectcontrol)     |客户端|                                                     设置当前焦点所在的控件,当设置控件为文本输入框时会弹出系统小键盘                                                      |
|    [SetStackGridCount](./1-ModAPI/接口/自定义UI/UI界面.md#setstackgridcount)    |客户端|                                                             设置StackGrid控件的大小                                                              |
|          [SetUiEntity](./1-ModAPI/接口/自定义UI/UI界面.md#setuientity)          |客户端|               设置PaperDoll控件需要显示的生物模型,PaperDoll控件的配置方式详见[控件介绍PaperDoll](../../../mcguide/18-界面与交互/30-UI说明文档.html#paperdoll)                |
|           [SetUiModel](./1-ModAPI/接口/自定义UI/UI界面.md#setuimodel)           |客户端|                设置PaperDoll控件需要显示的模型,PaperDoll控件的配置方式详见[控件介绍PaperDoll](../../../mcguide/18-界面与交互/30-UI说明文档.html#paperdoll)                 |
|      [SetUiModelScale](./1-ModAPI/接口/自定义UI/UI界面.md#setuimodelscale)      |客户端|                                                           设置PaperDoll控件模型的缩放比例                                                            |
|               [Update](./1-ModAPI/接口/自定义UI/UI界面.md#update)               |客户端|                                                              客户端每帧调用，1秒有30帧                                                               |
|         [UpdateScreen](./1-ModAPI/接口/自定义UI/UI界面.md#updatescreen)         |客户端|                                                            刷新界面，重新计算各个控件的相关数据                                                             |

####  UI控件 ####

|                                                          接口                                                          |   |                                                         描述                                                         |
|----------------------------------------------------------------------------------------------------------------------|---|--------------------------------------------------------------------------------------------------------------------|
|              [AddEntityMarker](./1-ModAPI/接口/自定义UI/UI控件.md#addentitymarker)              |客户端|                                                      增加实体位置标记                                                      |
|          [AddEntityTextMarker](./1-ModAPI/接口/自定义UI/UI控件.md#addentitytextmarker)          |客户端|                                                   在小地图上增加实体文本标记                                                    |
|          [AddHoverEventParams](./1-ModAPI/接口/自定义UI/UI控件.md#addhovereventparams)          |客户端|                                             开启按钮的悬浮回调功能，不调用该函数则按钮无悬浮回调                                             |
|                    [AddOption](./1-ModAPI/接口/自定义UI/UI控件.md#addoption)                    |客户端|                                           添加下拉框项，若添加成功则返回True，否则返回False                                            |
|              [AddStaticMarker](./1-ModAPI/接口/自定义UI/UI控件.md#addstaticmarker)              |客户端|                                                    增加地图上静态位置的标记                                                    |
|          [AddStaticTextMarker](./1-ModAPI/接口/自定义UI/UI控件.md#addstatictextmarker)          |客户端|                                                   在小地图上增加静态文本的标记                                                   |
|          [AddTouchEventParams](./1-ModAPI/接口/自定义UI/UI控件.md#addtoucheventparams)          |客户端|                                               开启按钮回调功能，不调用该函数则按钮无回调                                                |
|                 [ClearOptions](./1-ModAPI/接口/自定义UI/UI控件.md#clearoptions)                 |客户端|                                                       清空下拉框                                                        |
|               [ClearSelection](./1-ModAPI/接口/自定义UI/UI控件.md#clearselection)               |客户端|                                                清除当前选中，使下拉框恢复未选中内容状态                                                |
|            [DisableTextShadow](./1-ModAPI/接口/自定义UI/UI控件.md#disabletextshadow)            |客户端|                                                     关闭文本控件显示阴影                                                     |
|             [EnableTextShadow](./1-ModAPI/接口/自定义UI/UI控件.md#enabletextshadow)             |客户端|                                                     使文本控件显示阴影                                                      |
|                [GetAnchorFrom](./1-ModAPI/接口/自定义UI/UI控件.md#getanchorfrom)                |客户端|                                              判断控件相对于父节点的哪个锚点来计算位置与大小                                               |
|                  [GetAnchorTo](./1-ModAPI/接口/自定义UI/UI控件.md#getanchorto)                  |客户端|                                                    获取控件自身锚点位置信息                                                    |
|               [GetChildByName](./1-ModAPI/接口/自定义UI/UI控件.md#getchildbyname)               |客户端|                                             根据子控件的名称获取BaseUIControl实例                                              |
|               [GetChildByPath](./1-ModAPI/接口/自定义UI/UI控件.md#getchildbypath)               |客户端|                                              根据相对路径获取BaseUIControl实例                                               |
|             [GetClipDirection](./1-ModAPI/接口/自定义UI/UI控件.md#getclipdirection)             |客户端|                                                    获取图片控件的裁剪方向                                                     |
|                [GetClipOffset](./1-ModAPI/接口/自定义UI/UI控件.md#getclipoffset)                |客户端|                                                    获取控件的裁剪偏移信息                                                     |
|             [GetClipsChildren](./1-ModAPI/接口/自定义UI/UI控件.md#getclipschildren)             |客户端|                                                根据控件路径返回某控件是否开启裁剪内容                                                 |
|         [GetCurrentSliceIndex](./1-ModAPI/接口/自定义UI/UI控件.md#getcurrentsliceindex)         |客户端|                获取轮盘当前选择的切片的index，一般是在SetHoverCallback和SetTouchUpCallback中使用，表示当前鼠标悬浮或者点击的轮盘切片index                 |
|                  [GetEditText](./1-ModAPI/接口/自定义UI/UI控件.md#getedittext)                  |客户端|                                          获取edit\_box输入框的文本信息，获取失败会返回None                                           |
|              [GetFullPosition](./1-ModAPI/接口/自定义UI/UI控件.md#getfullposition)              |客户端|                                                获取控件的锚点坐标，支持比例值以及绝对值                                                |
|                  [GetFullSize](./1-ModAPI/接口/自定义UI/UI控件.md#getfullsize)                  |客户端|                                                 获取控件的大小，支持百分比以及绝对值                                                 |
|            [GetGlobalPosition](./1-ModAPI/接口/自定义UI/UI控件.md#getglobalposition)            |客户端|                                                      获取控件全局坐标                                                      |
|         [GetGlobalRotateAngle](./1-ModAPI/接口/自定义UI/UI控件.md#getglobalrotateangle)         |客户端|                                            获取图片通过RotateAround函数设置进去的角度值                                            |
|         [GetGlobalRotatePoint](./1-ModAPI/接口/自定义UI/UI控件.md#getglobalrotatepoint)         |客户端|                                          获取图片通过RotateAround函数设置进去的point值                                           |
|                  [GetGridItem](./1-ModAPI/接口/自定义UI/UI控件.md#getgriditem)                  |客户端|                                                    根据网格位置获取元素控件                                                    |
|                   [GetIsModal](./1-ModAPI/接口/自定义UI/UI控件.md#getismodal)                   |客户端|                                                    判断当前面板是否为模态框                                                    |
|                 [GetIsSwallow](./1-ModAPI/接口/自定义UI/UI控件.md#getisswallow)                 |客户端|                          判断当前面板输入是否会吞噬事件，isSwallow为Ture时，点击时，点击事件不会穿透到世界。如破坏方块、镜头转向不会被响应                           |
|                   [GetMaxSize](./1-ModAPI/接口/自定义UI/UI控件.md#getmaxsize)                   |客户端|                                                   获取控件所允许的最大的大小值                                                   |
|                   [GetMinSize](./1-ModAPI/接口/自定义UI/UI控件.md#getminsize)                   |客户端|                                                   获取控件所允许的最小的大小值                                                   |
|                   [GetModelId](./1-ModAPI/接口/自定义UI/UI控件.md#getmodelid)                   |客户端|                                                    获取渲染的骨骼模型Id                                                     |
|               [GetOffsetDelta](./1-ModAPI/接口/自定义UI/UI控件.md#getoffsetdelta)               |客户端|                                                    获得点击面板的拖拽偏移量                                                    |
|               [GetOptionCount](./1-ModAPI/接口/自定义UI/UI控件.md#getoptioncount)               |客户端|                                                       获得选项数量                                                       |
|     [GetOptionIndexByShowName](./1-ModAPI/接口/自定义UI/UI控件.md#getoptionindexbyshowname)     |客户端|                                            根据展示文本查找对应下拉框项的索引位置，若找不到返回-1                                            |
|     [GetOptionShowNameByIndex](./1-ModAPI/接口/自定义UI/UI控件.md#getoptionshownamebyindex)     |客户端|                                             根据索引位置查找当前栈式文本，若找不到返回None                                              |
|               [GetOrientation](./1-ModAPI/接口/自定义UI/UI控件.md#getorientation)               |客户端|                                                 获取stackPanel的排列方向                                                  |
|                      [GetPath](./1-ModAPI/接口/自定义UI/UI控件.md#getpath)                      |客户端|                                              返回当前控件的相对路径，路径从画布节点开始算起                                               |
|                  [GetPosition](./1-ModAPI/接口/自定义UI/UI控件.md#getposition)                  |客户端|                                                    获取控件相对父节点的坐标                                                    |
|               [GetPropertyBag](./1-ModAPI/接口/自定义UI/UI控件.md#getpropertybag)               |客户端|                                                   获取PropertyBag                                                    |
|               [GetRotateAngle](./1-ModAPI/接口/自定义UI/UI控件.md#getrotateangle)               |客户端|                                                 获取图片相对自身的旋转锚点旋转的角度                                                 |
|               [GetRotatePivot](./1-ModAPI/接口/自定义UI/UI控件.md#getrotatepivot)               |客户端|                                                   获取图片相对自身的旋转锚点                                                    |
|                [GetRotateRect](./1-ModAPI/接口/自定义UI/UI控件.md#getrotaterect)                |客户端|                                                    获取图片当前的四个边角点                                                    |
|  [GetScrollViewContentControl](./1-ModAPI/接口/自定义UI/UI控件.md#getscrollviewcontentcontrol)  |客户端|                                         返回该scroll\_view内容的BaseUIControl实例                                          |
|     [GetScrollViewContentPath](./1-ModAPI/接口/自定义UI/UI控件.md#getscrollviewcontentpath)     |客户端|                                                返回该scroll\_view内容的路径                                                |
|    [GetScrollViewPercentValue](./1-ModAPI/接口/自定义UI/UI控件.md#getscrollviewpercentvalue)    |客户端|                                              获取当前scroll\_view内容的百分比位置                                              |
|             [GetScrollViewPos](./1-ModAPI/接口/自定义UI/UI控件.md#getscrollviewpos)             |客户端|                                              获得当前scroll\_view最上方内容的位置                                              |
|         [GetSelectOptionIndex](./1-ModAPI/接口/自定义UI/UI控件.md#getselectoptionindex)         |客户端|                                               获得当前选中项的索引，所无选中项则返回-1                                                |
|      [GetSelectOptionShowName](./1-ModAPI/接口/自定义UI/UI控件.md#getselectoptionshowname)      |客户端|                                             获得当前选中项的展示文本，所无选中项则返回None                                              |
|                      [GetSize](./1-ModAPI/接口/自定义UI/UI控件.md#getsize)                      |客户端|                                                      获取控件的大小                                                       |
|                [GetSliceCount](./1-ModAPI/接口/自定义UI/UI控件.md#getslicecount)                |客户端|                                                   获取轮盘可以选择的总切片数量                                                   |
|               [GetSliderValue](./1-ModAPI/接口/自定义UI/UI控件.md#getslidervalue)               |客户端|                                                   获取滑动条的值，失败返回0                                                    |
|                      [GetText](./1-ModAPI/接口/自定义UI/UI控件.md#gettext)                      |客户端|                                              获取Label的文本信息，获取失败会返回None                                              |
|             [GetTextAlignment](./1-ModAPI/接口/自定义UI/UI控件.md#gettextalignment)             |客户端|                                                   获取文本控件的文本对齐方式                                                    |
|                 [GetTextColor](./1-ModAPI/接口/自定义UI/UI控件.md#gettextcolor)                 |客户端|                                                    获取Label文本颜色                                                     |
|           [GetTextLinePadding](./1-ModAPI/接口/自定义UI/UI控件.md#gettextlinepadding)           |客户端|                                                     获取文本控件的行间距                                                     |
|               [GetToggleState](./1-ModAPI/接口/自定义UI/UI控件.md#gettogglestate)               |客户端|                                                  获取Toggle开关控件的状态                                                   |
|                    [GetUiItem](./1-ModAPI/接口/自定义UI/UI控件.md#getuiitem)                    |客户端|获取ItemRenderer控件显示的物品，ItemRenderer控件的配置方式详见[控件介绍ItemRenderer](../../../mcguide/18-界面与交互/30-UI说明文档.html#itemrenderer)|
|                   [GetVisible](./1-ModAPI/接口/自定义UI/UI控件.md#getvisible)                   |客户端|                                                  根据控件路径返回某控件是否已显示                                                  |
|  [IsAnimEndCallbackRegistered](./1-ModAPI/接口/自定义UI/UI控件.md#isanimendcallbackregistered)  |客户端|                                             控件是否对名称为animName的动画进行了注册回调                                             |
|          [IsTextShadowEnabled](./1-ModAPI/接口/自定义UI/UI控件.md#istextshadowenabled)          |客户端|                                                    判断文本控件是否显示阴影                                                    |
|               [PauseAnimation](./1-ModAPI/接口/自定义UI/UI控件.md#pauseanimation)               |客户端|                                                暂停动画，暂停后的动画会停在当前的状态                                                 |
|                [PlayAnimation](./1-ModAPI/接口/自定义UI/UI控件.md#playanimation)                |客户端|                                                 继续播放动画，从动画当前状态开始播放                                                 |
|[RegisterCloseComboBoxCallback](./1-ModAPI/接口/自定义UI/UI控件.md#registerclosecomboboxcallback)|客户端|                                                    注册关闭下拉框事件回调                                                     |
| [RegisterOpenComboBoxCallback](./1-ModAPI/接口/自定义UI/UI控件.md#registeropencomboboxcallback) |客户端|                                                    注册展开下拉框事件回调                                                     |
|   [RegisterSelectItemCallback](./1-ModAPI/接口/自定义UI/UI控件.md#registerselectitemcallback)   |客户端|                                                   注册选中下拉框内容事件回调                                                    |
|        [RemoveAnimEndCallback](./1-ModAPI/接口/自定义UI/UI控件.md#removeanimendcallback)        |客户端|                                                    移除动画播放结束后的回调                                                    |
|              [RemoveAnimation](./1-ModAPI/接口/自定义UI/UI控件.md#removeanimation)              |客户端|                                        删除单一属性的动画，删除后的值与当前状态有关，建议删除后重新设置该属性值                                        |
|           [RemoveEntityMarker](./1-ModAPI/接口/自定义UI/UI控件.md#removeentitymarker)           |客户端|                                                      删除实体位置标记                                                      |
|       [RemoveEntityTextMarker](./1-ModAPI/接口/自定义UI/UI控件.md#removeentitytextmarker)       |客户端|                                                   在小地图上删除实体文本标记                                                    |
|          [RemoveOptionByIndex](./1-ModAPI/接口/自定义UI/UI控件.md#removeoptionbyindex)          |客户端|                                       根据提供的索引移除对应下拉框项，移除成功则返回True，否则返回False                                        |
|       [RemoveOptionByShowName](./1-ModAPI/接口/自定义UI/UI控件.md#removeoptionbyshowname)       |客户端|                                      根据提供的展示文本移除对应下拉框项，移除成功则返回True，否则返回False                                       |
|           [RemoveStaticMarker](./1-ModAPI/接口/自定义UI/UI控件.md#removestaticmarker)           |客户端|                                                      删除静态位置标记                                                      |
|       [RemoveStaticTextMarker](./1-ModAPI/接口/自定义UI/UI控件.md#removestatictextmarker)       |客户端|                                                   在小地图上删除静态文本标记                                                    |
|     [RenderBlockGeometryModel](./1-ModAPI/接口/自定义UI/UI控件.md#renderblockgeometrymodel)     |客户端|                                                      渲染网格体模型                                                       |
|                 [RenderEntity](./1-ModAPI/接口/自定义UI/UI控件.md#renderentity)                 |客户端|                                                        渲染实体                                                        |
|          [RenderSkeletonModel](./1-ModAPI/接口/自定义UI/UI控件.md#renderskeletonmodel)          |客户端|                                                   渲染骨骼模型（不依赖实体）                                                    |
|               [RepaintMiniMap](./1-ModAPI/接口/自定义UI/UI控件.md#repaintminimap)               |客户端|                                                      重新绘制小地图                                                       |
|                       [Rotate](./1-ModAPI/接口/自定义UI/UI控件.md#rotate)                       |客户端|                                                  图片相对自身的旋转锚点进行旋转                                                   |
|                 [RotateAround](./1-ModAPI/接口/自定义UI/UI控件.md#rotatearound)                 |客户端|                                                图片相对全局坐标系中某个固定的点进行旋转                                                |
|                     [SetAlpha](./1-ModAPI/接口/自定义UI/UI控件.md#setalpha)                     |客户端|                                             设置节点的透明度，仅对image和label控件生效                                             |
|                [SetAnchorFrom](./1-ModAPI/接口/自定义UI/UI控件.md#setanchorfrom)                |客户端|                                                   设置控件相对于父节点的锚点                                                    |
|                  [SetAnchorTo](./1-ModAPI/接口/自定义UI/UI控件.md#setanchorto)                  |客户端|                                                     设置控件自身锚点位置                                                     |
|           [SetAnimEndCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setanimendcallback)           |客户端|                                            设置动画播放结束后的回调，每次设置都会覆盖上一次的设置                                             |
|                 [SetAnimation](./1-ModAPI/接口/自定义UI/UI控件.md#setanimation)                 |客户端|                                           给单一属性设置动画，已有重复的会设置失败，需要先remove                                           |
|     [SetButtonHoverInCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttonhoverincallback)     |客户端|                                                 设置鼠标进入按钮时触发的悬浮回调函数                                                 |
|    [SetButtonHoverOutCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttonhoveroutcallback)    |客户端|                                                 设置鼠标退出按钮时触发的悬浮回调函数                                                 |
|  [SetButtonScreenExitCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttonscreenexitcallback)  |客户端|                                             设置按钮所在画布退出时若鼠标仍未抬起时触发回调函数                                              |
| [SetButtonTouchCancelCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttontouchcancelcallback) |客户端|                                                设置触控在按钮范围外弹起时触发的回调函数                                                |
|   [SetButtonTouchDownCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttontouchdowncallback)   |客户端|                                                   设置按钮按下时触发的回调函数                                                   |
|   [SetButtonTouchMoveCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttontouchmovecallback)   |客户端|                                                 设置按下后触控移动时触发的回调函数                                                  |
| [SetButtonTouchMoveInCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttontouchmoveincallback) |客户端|                                                设置按下按钮后进入控件时触发的回调函数                                                 |
|[SetButtonTouchMoveOutCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttontouchmoveoutcallback)|客户端|                                                设置按下按钮后退出控件时触发的回调函数                                                 |
|     [SetButtonTouchUpCallback](./1-ModAPI/接口/自定义UI/UI控件.md#setbuttontouchupcallback)     |客户端|                                                 设置触控在按钮范围内弹起时的回调函数                                                 |
|             [SetClipDirection](./1-ModAPI/接口/自定义UI/UI控件.md#setclipdirection)             |客户端|                                                    设置图片控件的裁剪方向                                                     |
|                [SetClipOffset](./1-ModAPI/接口/自定义UI/UI控件.md#setclipoffset)                |客户端|                                                    设置控件的裁剪偏移信息                                                     |
|             [SetClipsChildren](./1-ModAPI/接口/自定义UI/UI控件.md#setclipschildren)             |客户端|                                                    设置控件是否开启裁剪内容                                                    |
|         [SetCurrentSliceIndex](./1-ModAPI/接口/自定义UI/UI控件.md#setcurrentsliceindex)         |客户端|                                                     设置轮盘选择的切片                                                      |
|                  [SetEditText](./1-ModAPI/接口/自定义UI/UI控件.md#setedittext)                  |客户端|                                                设置edit\_box输入框的文本信息                                                 |
|         [SetEditTextMaxLength](./1-ModAPI/接口/自定义UI/UI控件.md#setedittextmaxlength)         |客户端|                                                    设置输入框的最大输入长度                                                    |
|              [SetFullPosition](./1-ModAPI/接口/自定义UI/UI控件.md#setfullposition)              |客户端|                                             设置控件的锚点坐标（全局坐标），支持比例值以及绝对值                                             |
|                  [SetFullSize](./1-ModAPI/接口/自定义UI/UI控件.md#setfullsize)                  |客户端|                                                设置控件的大小，支持比例形式以及绝对值                                                 |
|             [SetGridDimension](./1-ModAPI/接口/自定义UI/UI控件.md#setgriddimension)             |客户端|                                                    设置Grid控件的大小                                                     |
|                  [SetHighestY](./1-ModAPI/接口/自定义UI/UI控件.md#sethighesty)                  |客户端|                                                    设置绘制地图的最大高度                                                     |
|             [SetHoverCallback](./1-ModAPI/接口/自定义UI/UI控件.md#sethovercallback)             |客户端|                                                   设置轮盘选择切片触发回调函数                                                   |
|         [SetImageAdaptionType](./1-ModAPI/接口/自定义UI/UI控件.md#setimageadaptiontype)         |客户端|                                                 设置图片控件的图片适配方式以及信息                                                  |
|                   [SetIsModal](./1-ModAPI/接口/自定义UI/UI控件.md#setismodal)                   |客户端|                                                    设置当前面板是否为模态框                                                    |
|                 [SetIsSwallow](./1-ModAPI/接口/自定义UI/UI控件.md#setisswallow)                 |客户端|                          设置当前面板输入是否会吞噬事件，isSwallow为Ture时，点击时，点击事件不会穿透到世界。如破坏方块、镜头转向不会被响应                           |
|                     [SetLayer](./1-ModAPI/接口/自定义UI/UI控件.md#setlayer)                     |客户端|                                     设置控件节点的层级，可以通过传入空字符串（""）的方式来调整整个JSON的基础层级                                      |
|                   [SetMaxSize](./1-ModAPI/接口/自定义UI/UI控件.md#setmaxsize)                   |客户端|                                                   设置控件所允许的最大的大小值                                                   |
|                   [SetMinSize](./1-ModAPI/接口/自定义UI/UI控件.md#setminsize)                   |客户端|                                                   设置控件所允许的最小的大小值                                                   |
|               [SetOffsetDelta](./1-ModAPI/接口/自定义UI/UI控件.md#setoffsetdelta)               |客户端|                                                    设置点击面板的拖拽偏移量                                                    |
|               [SetOrientation](./1-ModAPI/接口/自定义UI/UI控件.md#setorientation)               |客户端|                                                 设置stackPanel的排列方向                                                  |
|                  [SetPosition](./1-ModAPI/接口/自定义UI/UI控件.md#setposition)                  |客户端|                                                    设置控件相对父节点的坐标                                                    |
|               [SetPropertyBag](./1-ModAPI/接口/自定义UI/UI控件.md#setpropertybag)               |客户端|                                    设置PropertyBag,将使用字典中的每个值来覆盖原本PropertyBag中的值                                     |
|               [SetRotatePivot](./1-ModAPI/接口/自定义UI/UI控件.md#setrotatepivot)               |客户端|                                          设置图片自身旋转锚点，该点并不是固定的点，而是相对于自身位置的点                                          |
|    [SetScrollViewPercentValue](./1-ModAPI/接口/自定义UI/UI控件.md#setscrollviewpercentvalue)    |客户端|                                              设置当前scroll\_view内容的百分比位置                                              |
|             [SetScrollViewPos](./1-ModAPI/接口/自定义UI/UI控件.md#setscrollviewpos)             |客户端|                                               设置当前scroll\_view内容的位置                                                |
|       [SetSelectOptionByIndex](./1-ModAPI/接口/自定义UI/UI控件.md#setselectoptionbyindex)       |客户端|                                                  根据提供的索引选中对应下拉框项                                                   |
|    [SetSelectOptionByShowName](./1-ModAPI/接口/自定义UI/UI控件.md#setselectoptionbyshowname)    |客户端|                                                 根据提供的展示文本选中对应下拉框项                                                  |
|                      [SetSize](./1-ModAPI/接口/自定义UI/UI控件.md#setsize)                      |客户端|                                                      设置控件的大小                                                       |
|               [SetSliderValue](./1-ModAPI/接口/自定义UI/UI控件.md#setslidervalue)               |客户端|                                                      设置滑动条的值                                                       |
|                    [SetSprite](./1-ModAPI/接口/自定义UI/UI控件.md#setsprite)                    |客户端|                                                     给图片控件换指定贴图                                                     |
|           [SetSpriteClipRatio](./1-ModAPI/接口/自定义UI/UI控件.md#setspriteclipratio)           |客户端|                                设置图片的裁剪区域比例（不改变控件尺寸）。可以配合image控件的clip\_ratio属性控制方向。                                 |
|               [SetSpriteColor](./1-ModAPI/接口/自定义UI/UI控件.md#setspritecolor)               |客户端|                                                       设置图片颜色                                                       |
|                [SetSpriteGray](./1-ModAPI/接口/自定义UI/UI控件.md#setspritegray)                |客户端|                                           给图片控件置灰，比直接SetSprite一张灰图片效率要高                                            |
|       [SetSpritePlatformFrame](./1-ModAPI/接口/自定义UI/UI控件.md#setspriteplatformframe)       |客户端|                                              设置图片为我的世界移动端启动器当前帐号的头像框                                               |
|        [SetSpritePlatformHead](./1-ModAPI/接口/自定义UI/UI控件.md#setspriteplatformhead)        |客户端|                                               设置图片为我的世界移动端启动器当前帐号的头像                                               |
|                  [SetSpriteUV](./1-ModAPI/接口/自定义UI/UI控件.md#setspriteuv)                  |客户端|                                            设置图片的起始uv，与json中的"uv"属性作用一致                                             |
|              [SetSpriteUVSize](./1-ModAPI/接口/自定义UI/UI控件.md#setspriteuvsize)              |客户端|                                         设置图片的uv大小，与json中的"uv\_size"属性作用一致                                          |
|                      [SetText](./1-ModAPI/接口/自定义UI/UI控件.md#settext)                      |客户端|                                                    设置Label的文本信息                                                    |
|             [SetTextAlignment](./1-ModAPI/接口/自定义UI/UI控件.md#settextalignment)             |客户端|                                                   设置文本控件的文本对齐方式                                                    |
|                 [SetTextColor](./1-ModAPI/接口/自定义UI/UI控件.md#settextcolor)                 |客户端|                                                    设置Label文本的颜色                                                    |
|              [SetTextFontSize](./1-ModAPI/接口/自定义UI/UI控件.md#settextfontsize)              |客户端|                                                  设置Label中文本字体的大小                                                   |
|           [SetTextLinePadding](./1-ModAPI/接口/自定义UI/UI控件.md#settextlinepadding)           |客户端|                                                     设置文本控件的行间距                                                     |
|               [SetToggleState](./1-ModAPI/接口/自定义UI/UI控件.md#settogglestate)               |客户端|                                                   设置Toggle开关控件的值                                                   |
|               [SetTouchEnable](./1-ModAPI/接口/自定义UI/UI控件.md#settouchenable)               |客户端|                                                    设置控件是否可点击交互                                                     |
|           [SetTouchUpCallback](./1-ModAPI/接口/自定义UI/UI控件.md#settouchupcallback)           |客户端|                                              设置轮盘选择切片并且鼠标按下抬起后触发回调函数                                               |
|                    [SetUiItem](./1-ModAPI/接口/自定义UI/UI控件.md#setuiitem)                    |客户端|设置ItemRenderer控件显示的物品，ItemRenderer控件的配置方式详见[控件介绍ItemRenderer](../../../mcguide/18-界面与交互/30-UI说明文档.html#itemrenderer)|
|                     [SetValue](./1-ModAPI/接口/自定义UI/UI控件.md#setvalue)                     |客户端|                                                      设置进度条的进度                                                      |
|                   [SetVisible](./1-ModAPI/接口/自定义UI/UI控件.md#setvisible)                   |客户端|                                  根据控件路径选择是否显示某控件，可以通过传入空字符串（""）的方式来调整整个JSON的显示/隐藏                                  |
|                [StopAnimation](./1-ModAPI/接口/自定义UI/UI控件.md#stopanimation)                |客户端|                                             停止动画，动画将恢复到第一段动画片段的from状态                                              |
|                       [ZoomIn](./1-ModAPI/接口/自定义UI/UI控件.md#zoomin)                       |客户端|                                                        放大地图                                                        |
|                      [ZoomOut](./1-ModAPI/接口/自定义UI/UI控件.md#zoomout)                      |客户端|                                                        缩小地图                                                        |
|                    [ZoomReset](./1-ModAPI/接口/自定义UI/UI控件.md#zoomreset)                    |客户端|                                                    恢复地图放缩大小为默认值                                                    |
|                     [asButton](./1-ModAPI/接口/自定义UI/UI控件.md#asbutton)                     |客户端|                             将当前BaseUIControl转换为ButtonUIControl实例，如当前控件非button类型则返回None                             |
|                       [asGrid](./1-ModAPI/接口/自定义UI/UI控件.md#asgrid)                       |客户端|                               将当前BaseUIControl转换为GridUIControl实例，如当前控件非grid类型则返回None                               |
|                      [asImage](./1-ModAPI/接口/自定义UI/UI控件.md#asimage)                      |客户端|                              将当前BaseUIControl转换为ImageUIControl实例，如当前控件非image类型则返回None                              |
|                 [asInputPanel](./1-ModAPI/接口/自定义UI/UI控件.md#asinputpanel)                 |客户端|                         将当前BaseUIControl转换为InputPanelUIControl实例，如当前控件非inputPanel类型则返回None                         |
|               [asItemRenderer](./1-ModAPI/接口/自定义UI/UI控件.md#asitemrenderer)               |客户端|                              将当前BaseUIControl转换为ItemRenderer实例，如当前控件非custom类型则返回None                               |
|                      [asLabel](./1-ModAPI/接口/自定义UI/UI控件.md#aslabel)                      |客户端|                              将当前BaseUIControl转换为LabelUIControl实例，如当前控件非Label类型则返回None                              |
|                    [asMiniMap](./1-ModAPI/接口/自定义UI/UI控件.md#asminimap)                    |客户端|                              将当前BaseUIControl转换为MiniMapUIControl实例，如当前控件非小地图类型则返回None                              |
|            [asNeteaseComboBox](./1-ModAPI/接口/自定义UI/UI控件.md#asneteasecombobox)            |客户端|                         将当前BaseUIControl转换为NeteaseComboBoxUIControl实例，如当前控件非panel类型则返回None                         |
|           [asNeteasePaperDoll](./1-ModAPI/接口/自定义UI/UI控件.md#asneteasepaperdoll)           |客户端|                        将当前BaseUIControl转换为NeteasePaperDollUIControl实例，如当前控件非custom类型则返回None                        |
|                [asProgressBar](./1-ModAPI/接口/自定义UI/UI控件.md#asprogressbar)                |客户端|                           将当前BaseUIControl转换为ProgressBarUIControl实例，如当前控件非panel类型则返回None                           |
|                 [asScrollView](./1-ModAPI/接口/自定义UI/UI控件.md#asscrollview)                 |客户端|                         将当前BaseUIControl转换为ScrollViewUIControl实例，如当前控件非scrollview类型则返回None                         |
|             [asSelectionWheel](./1-ModAPI/接口/自定义UI/UI控件.md#asselectionwheel)             |客户端|                     将当前BaseUIControl转换为SelectionWheelUIControl实例，如当前控件非selectionWheel类型则返回None                     |
|                     [asSlider](./1-ModAPI/接口/自定义UI/UI控件.md#asslider)                     |客户端|                              将当前BaseUIControl转换为SliderUIControl实例，如当前控件非滑动条类型则返回None                               |
|                 [asStackPanel](./1-ModAPI/接口/自定义UI/UI控件.md#asstackpanel)                 |客户端|                         将当前BaseUIControl转换为StackPanelUIControl实例，如当前控件非stackPanel类型则返回None                         |
|               [asSwitchToggle](./1-ModAPI/接口/自定义UI/UI控件.md#asswitchtoggle)               |客户端|                      将当前BaseUIControl转换为SwitchToggleUIControl实例，如当前控件非panel类型或非toggle则返回None                       |
|                [asTextEditBox](./1-ModAPI/接口/自定义UI/UI控件.md#astexteditbox)                |客户端|                          将当前BaseUIControl转换为TextEditBoxUIControl实例，如当前控件非editbox类型则返回None                          |
|               [resetAnimation](./1-ModAPI/接口/自定义UI/UI控件.md#resetanimation)               |客户端|                                                      重置该控件的动画                                                      |

####  通用设置 ####

|                                                接口                                                |   |              描述               |
|--------------------------------------------------------------------------------------------------|---|-------------------------------|
|     [CloseSettingUI](./1-ModAPI/接口/自定义UI/通用设置.md#closesettingui)     |客户端|           关闭模组信息界面            |
|     [GetSettingInst](./1-ModAPI/接口/自定义UI/通用设置.md#getsettinginst)     |客户端|         获取当前模组的通用设置实例         |
|      [OpenSettingUI](./1-ModAPI/接口/自定义UI/通用设置.md#opensettingui)      |客户端|在模组信息界面中打开设置页面（此操作仅可访问本模组的配置选项）|
|[RegisterSettingInst](./1-ModAPI/接口/自定义UI/通用设置.md#registersettinginst)|客户端|           注册通用设置实例            |

####  音效 ####

|                                               接口                                               |   |                           描述                            |
|------------------------------------------------------------------------------------------------|---|---------------------------------------------------------|
|    [DisableOriginMusic](./1-ModAPI/接口/音效.md#disableoriginmusic)    |客户端|                        停止原生背景音乐                         |
|       [PlayCustomMusic](./1-ModAPI/接口/音效.md#playcustommusic)       |客户端|                   播放场景音效，包括原版音效及自定义音效                   |
|     [PlayCustomUIMusic](./1-ModAPI/接口/音效.md#playcustomuimusic)     |客户端|                   播放UI音效，包括原版音效及自定义音效                   |
| [PlayGlobalCustomMusic](./1-ModAPI/接口/音效.md#playglobalcustommusic) |客户端|                         播放背景音乐                          |
|    [SetCustomMusicLoop](./1-ModAPI/接口/音效.md#setcustommusicloop)    |客户端|                设定指定音乐是否循环播放，包括场景音效与背景音乐                 |
|[SetCustomMusicLoopById](./1-ModAPI/接口/音效.md#setcustommusicloopbyid)|客户端|                      设定指定音乐是否循环播放                       |
|       [StopCustomMusic](./1-ModAPI/接口/音效.md#stopcustommusic)       |客户端|停止音效，包括场景音效与背景音乐，将依据fadeOutTime触发OnMusicStopClientEvent事件|
|   [StopCustomMusicById](./1-ModAPI/接口/音效.md#stopcustommusicbyid)   |客户端|                         停止场景音效                          |

####  控制 ####

|                                                 接口                                                 |   |                                                                         描述                                                                         |
|----------------------------------------------------------------------------------------------------|---|----------------------------------------------------------------------------------------------------------------------------------------------------|
|        [AddPickBlacklist](./1-ModAPI/接口/控制.md#addpickblacklist)        |客户端|                                            添加使用camera组件（例如GetChosen接口、PickFacing接口）选取实体时的黑名单，即该实体不会被选取到                                            |
|      [ClearPickBlacklist](./1-ModAPI/接口/控制.md#clearpickblacklist)      |客户端|                                                  清除使用camera组件（例如GetChosen接口、PickFacing接口）选取实体的黑名单                                                  |
|               [GetChosen](./1-ModAPI/接口/控制.md#getchosen)               |客户端|                                                   获取屏幕点击位置的实体或方块信息，通常与GetEntityByCoordEvent配合使用                                                    |
|         [GetChosenEntity](./1-ModAPI/接口/控制.md#getchosenentity)         |客户端|                                                     获取屏幕点击位置的实体id，通常与GetEntityByCoordEvent配合使用                                                     |
|[GetHoldTimeThresholdInMs](./1-ModAPI/接口/控制.md#getholdtimethresholdinms)|客户端|                                                             获取长按判定时间，即按着屏幕多长时间会触发长按操作                                                              |
|          [GetInputVector](./1-ModAPI/接口/控制.md#getinputvector)          |客户端|                                                                   获取方向键（移动轮盘）的输入                                                                   |
|        [GetMousePosition](./1-ModAPI/接口/控制.md#getmouseposition)        |客户端|                                                                       获取鼠标位置                                                                       |
|             [GetTouchPos](./1-ModAPI/接口/控制.md#gettouchpos)             |客户端|                                   获取点击的屏幕坐标。可以监听TapBeforeClientEvent或TapOrHoldReleaseClientEvent事件，调用本API获取点击坐标。                                   |
|             [IsCanAttack](./1-ModAPI/接口/控制.md#iscanattack)             |客户端|                                                                     获取玩家是否响应攻击                                                                     |
|               [IsCanChat](./1-ModAPI/接口/控制.md#iscanchat)               |客户端|                                                                    获取玩家是否响应聊天按钮                                                                    |
|               [IsCanDrag](./1-ModAPI/接口/控制.md#iscandrag)               |客户端|                                                                    获取玩家是否响应屏幕拖动                                                                    |
|              [IsCanInair](./1-ModAPI/接口/控制.md#iscaninair)              |客户端|                                                                  获取玩家是否响应打上升下降按钮                                                                   |
|               [IsCanJump](./1-ModAPI/接口/控制.md#iscanjump)               |客户端|                                                                获取玩家是否响应跳跃（以及在水中浮起）                                                                 |
|               [IsCanMove](./1-ModAPI/接口/控制.md#iscanmove)               |客户端|                                                                     获取玩家是否响应移动                                                                     |
|            [IsCanOpenInv](./1-ModAPI/接口/控制.md#iscanopeninv)            |客户端|                                                                   获取玩家是否响应打开背包按钮                                                                   |
|              [IsCanPause](./1-ModAPI/接口/控制.md#iscanpause)              |客户端|                                                                    获取玩家是否响应暂停按钮                                                                    |
|        [IsCanPauseScreen](./1-ModAPI/接口/控制.md#iscanpausescreen)        |客户端|                                                                   获取玩家是否可以打开暂停界面                                                                   |
|        [IsCanPerspective](./1-ModAPI/接口/控制.md#iscanperspective)        |客户端|                                                                    获取玩家是否响应切换视角                                                                    |
|         [IsCanScreenShot](./1-ModAPI/接口/控制.md#iscanscreenshot)         |客户端|                                                                    获取玩家是否响应截图按钮                                                                    |
|           [IsCanWalkMode](./1-ModAPI/接口/控制.md#iscanwalkmode)           |客户端|                                                                   获取玩家是否响应切换行走模式                                                                   |
|        [IsTouchWithMouse](./1-ModAPI/接口/控制.md#istouchwithmouse)        |客户端|                                                                  获取是否正在使用鼠标点击模拟触屏                                                                  |
|         [LockInputVector](./1-ModAPI/接口/控制.md#lockinputvector)         |客户端|                                                   锁定本地玩家方向键（移动轮盘）的输入，可使本地玩家持续向指定方向前行，且不会再受玩家输入影响                                                   |
|        [LockVerticalMove](./1-ModAPI/接口/控制.md#lockverticalmove)        |客户端|                                                                 模拟上升或下降，调用后一直上升或下降                                                                 |
|              [PickFacing](./1-ModAPI/接口/控制.md#pickfacing)              |客户端|                                                                   获取准星选中的实体或者方块                                                                    |
|               [SetCanAll](./1-ModAPI/接口/控制.md#setcanall)               |客户端|同时设置SetCanMove，SetCanJump，SetCanAttack，SetCanWalkMode，SetCanPerspective，SetCanPause，SetCanChat，SetCanScreenShot，SetCanOpenInv，SetCanDrag，SetCanInair|
|            [SetCanAttack](./1-ModAPI/接口/控制.md#setcanattack)            |客户端|                                                                      设置是否响应攻击                                                                      |
|              [SetCanChat](./1-ModAPI/接口/控制.md#setcanchat)              |客户端|                                                                     设置是否响应聊天按钮                                                                     |
|              [SetCanDrag](./1-ModAPI/接口/控制.md#setcandrag)              |客户端|                                                                     设置是否响应屏幕拖动                                                                     |
|             [SetCanInair](./1-ModAPI/接口/控制.md#setcaninair)             |客户端|                                                            设置是否响应上升下降按钮（飞在空中时右下角的三个按钮）                                                             |
|              [SetCanJump](./1-ModAPI/接口/控制.md#setcanjump)              |客户端|                                                                 设置是否响应跳跃（以及在水中浮起）                                                                  |
|              [SetCanMove](./1-ModAPI/接口/控制.md#setcanmove)              |客户端|                                                                      设置是否响应移动                                                                      |
|           [SetCanOpenInv](./1-ModAPI/接口/控制.md#setcanopeninv)           |客户端|                                                                    设置是否响应打开背包按钮                                                                    |
|             [SetCanPause](./1-ModAPI/接口/控制.md#setcanpause)             |客户端|                                                                     设置是否响应暂停按钮                                                                     |
|       [SetCanPauseScreen](./1-ModAPI/接口/控制.md#setcanpausescreen)       |客户端|                                                                    设置是否可以打开暂停界面                                                                    |
|       [SetCanPerspective](./1-ModAPI/接口/控制.md#setcanperspective)       |客户端|                                                                     设置是否响应切换视角                                                                     |
|        [SetCanScreenShot](./1-ModAPI/接口/控制.md#setcanscreenshot)        |客户端|                                                                     设置是否响应截图按钮                                                                     |
|          [SetCanWalkMode](./1-ModAPI/接口/控制.md#setcanwalkmode)          |客户端|                                                                    设置是否响应切换行走模式                                                                    |
|          [SetControlMode](./1-ModAPI/接口/控制.md#setcontrolmode)          |客户端|                                                                       设置控制模式                                                                       |
|      [SetControlModeLock](./1-ModAPI/接口/控制.md#setcontrolmodelock)      |客户端|                                                                   设置控制模式是否可以被改变                                                                    |
|        [SetDeviceVibrate](./1-ModAPI/接口/控制.md#setdevicevibrate)        |客户端|                                                                       设置设备震动                                                                       |
| [SetGyroSensorReportRate](./1-ModAPI/接口/控制.md#setgyrosensorreportrate) |客户端|                                                                 设置陀螺仪传感器(上报/触发)频率                                                                  |
|    [SetHoldTimeThreshold](./1-ModAPI/接口/控制.md#setholdtimethreshold)    |客户端|                                                             设置长按判定时间，即按着屏幕多长时间会触发长按操作                                                              |
|             [SetMoveLock](./1-ModAPI/接口/控制.md#setmovelock)             |客户端|                                                            设置是否锁住移动。实际上为是否响应十字键与遥感的操作。                                                             |
|           [SetShowRideUI](./1-ModAPI/接口/控制.md#setshowrideui)           |服务端|                                                                   设置是否显示马匹的UI界面                                                                    |
|  [SimulateTouchWithMouse](./1-ModAPI/接口/控制.md#simulatetouchwithmouse)  |客户端|                                                               模拟使用鼠标控制UI（PC F11快捷键）                                                                |
|        [ToggleGyroSensor](./1-ModAPI/接口/控制.md#togglegyrosensor)        |客户端|                                                                   开启或关闭陀螺仪传感器采集                                                                    |
|      [UnLockVerticalMove](./1-ModAPI/接口/控制.md#unlockverticalmove)      |客户端|                                                                     解除上升或下降状态                                                                      |
|       [UnlockInputVector](./1-ModAPI/接口/控制.md#unlockinputvector)       |客户端|                                                                 解锁本地玩家方向键（移动轮盘）的输入                                                                 |

####  游戏设置 ####

|                                                      接口                                                      |   |        描述        |
|--------------------------------------------------------------------------------------------------------------|---|------------------|
|         [GetControllerLayout](./1-ModAPI/接口/游戏设置.md#getcontrollerlayout)         |客户端|   获取玩家控制器绑定映射    |
|       [GetGamepadKeyMappings](./1-ModAPI/接口/游戏设置.md#getgamepadkeymappings)       |客户端|   获取自定义手柄按键映射    |
|              [GetKeyMappings](./1-ModAPI/接口/游戏设置.md#getkeymappings)              |客户端|  获取指定的自定义按键映射配置  |
|             [GetSliderOption](./1-ModAPI/接口/游戏设置.md#getslideroption)             |客户端|  获得某个滑动条设置选项的值   |
|             [GetToggleOption](./1-ModAPI/接口/游戏设置.md#gettoggleoption)             |客户端|   获得某个开关设置值的接口   |
|                [GetUIProfile](./1-ModAPI/接口/游戏设置.md#getuiprofile)                |客户端|   获取"UI 档案"模式    |
|       [HighlightBoxSelection](./1-ModAPI/接口/游戏设置.md#highlightboxselection)       |客户端|镜头移动时高亮当前视角中心所指的方块|
|[RegisterCustomGamepadMapping](./1-ModAPI/接口/游戏设置.md#registercustomgamepadmapping)|客户端|   注册自定义手柄按键映射    |
|    [RegisterCustomKeyMapping](./1-ModAPI/接口/游戏设置.md#registercustomkeymapping)    |客户端|    注册自定义按键映射     |
|             [SetSliderOption](./1-ModAPI/接口/游戏设置.md#setslideroption)             |客户端|  设置某个滑动条设置选项的值   |
|    [SetSplitControlCanChange](./1-ModAPI/接口/游戏设置.md#setsplitcontrolcanchange)    |客户端|  设置是否允许使用准星瞄准按钮  |
|             [SetToggleOption](./1-ModAPI/接口/游戏设置.md#settoggleoption)             |客户端|    修改开关型设置的接口    |
|                [SetUIProfile](./1-ModAPI/接口/游戏设置.md#setuiprofile)                |客户端|   设置"UI 档案"模式    |

####  世界 ####

|                                                          接口                                                           |   |                   描述                   |
|-----------------------------------------------------------------------------------------------------------------------|---|----------------------------------------|
|             [VirtualWorldCreate](./1-ModAPI/接口/虚拟世界/世界.md#virtualworldcreate)             |客户端|创建虚拟世界，虚拟世界只允许存在一个，已经存在虚拟世界的情况下再调用此方法则无效|
|            [VirtualWorldDestroy](./1-ModAPI/接口/虚拟世界/世界.md#virtualworlddestroy)            |客户端|                 销毁虚拟世界                 |
|[VirtualWorldSetCollidersVisible](./1-ModAPI/接口/虚拟世界/世界.md#virtualworldsetcollidersvisible)|客户端|    设置虚拟世界中模型的包围盒是否显示,主要用于调试,默认为不显示     |
|      [VirtualWorldSetSkyBgColor](./1-ModAPI/接口/虚拟世界/世界.md#virtualworldsetskybgcolor)      |客户端|             设置虚拟世界中天空背景的颜色             |
|      [VirtualWorldSetSkyTexture](./1-ModAPI/接口/虚拟世界/世界.md#virtualworldsetskytexture)      |客户端|              设置虚拟世界中天空的贴图              |
|   [VirtualWorldToggleVisibility](./1-ModAPI/接口/虚拟世界/世界.md#virtualworldtogglevisibility)   |客户端|               设置虚拟世界是否显示               |

####  相机 ####

|                                              接口                                               |   |                         描述                          |
|-----------------------------------------------------------------------------------------------|---|-----------------------------------------------------|
|[CameraGetClickModel](./1-ModAPI/接口/虚拟世界/相机.md#cameragetclickmodel)|客户端|获取相机当前指向的模型的id，会返回离相机最近的，通常与GetEntityByCoordEvent配合使用|
|       [CameraGetFov](./1-ModAPI/接口/虚拟世界/相机.md#cameragetfov)       |客户端|                      获取相机视野大小                       |
|       [CameraGetPos](./1-ModAPI/接口/虚拟世界/相机.md#cameragetpos)       |客户端|                       返回相机位置                        |
|      [CameraGetZoom](./1-ModAPI/接口/虚拟世界/相机.md#cameragetzoom)      |客户端|                      获取相机的缩放值                       |
|       [CameraLookAt](./1-ModAPI/接口/虚拟世界/相机.md#cameralookat)       |客户端|                       修改相机朝向                        |
|       [CameraMoveTo](./1-ModAPI/接口/虚拟世界/相机.md#cameramoveto)       |客户端|          设置相机移动动画, 会根据当前相机状态与传入参数按时间进行插值显示          |
|       [CameraSetFov](./1-ModAPI/接口/虚拟世界/相机.md#camerasetfov)       |客户端|                      设置相机视野大小                       |
|       [CameraSetPos](./1-ModAPI/接口/虚拟世界/相机.md#camerasetpos)       |客户端|                       设置相机位置                        |
|      [CameraSetZoom](./1-ModAPI/接口/虚拟世界/相机.md#camerasetzoom)      |客户端|                       设置相机缩放                        |
|  [CameraStopActions](./1-ModAPI/接口/虚拟世界/相机.md#camerastopactions)  |客户端|                      停止相机移动动画                       |

####  模型 ####

|                                                             接口                                                              |   |                                                                     描述                                                                      |
|-----------------------------------------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------------------------------------------------------------------------|
|            [ModelCancelAllBoneMask](./1-ModAPI/接口/虚拟世界/模型.md#modelcancelallbonemask)            |客户端|                                                                取消动画中的所有骨骼屏蔽。                                                                |
|        [ModelCreateMinecraftObject](./1-ModAPI/接口/虚拟世界/模型.md#modelcreateminecraftobject)        |客户端|                                                               在虚拟世界中创建微软原版模型                                                                |
|                 [ModelCreateObject](./1-ModAPI/接口/虚拟世界/模型.md#modelcreateobject)                 |客户端|                                                               在虚拟世界中创建网易骨骼模型                                                                |
|                       [ModelGetPos](./1-ModAPI/接口/虚拟世界/模型.md#modelgetpos)                       |客户端|                                                                   获取模型的坐标                                                                   |
|                       [ModelGetRot](./1-ModAPI/接口/虚拟世界/模型.md#modelgetrot)                       |客户端|                                                                  返回模型的旋转角度                                                                  |
|                    [ModelIsVisible](./1-ModAPI/接口/虚拟世界/模型.md#modelisvisible)                    |客户端|                                                                   返回模型可见性                                                                   |
|                       [ModelMoveTo](./1-ModAPI/接口/虚拟世界/模型.md#modelmoveto)                       |客户端|                                                                  设置模型平移运动                                                                   |
|                [ModelPlayAnimation](./1-ModAPI/接口/虚拟世界/模型.md#modelplayanimation)                |客户端|                                                    模型播放动画，支持动作融合，其功能与模型接口ModelPlayAni相同。                                                    |
|   [ModelRegisterAnim1DControlParam](./1-ModAPI/接口/虚拟世界/模型.md#modelregisteranim1dcontrolparam)   |客户端|                       当同时播放多个骨骼动画时，新建用于控制动画进行1D线性混合的参数。目前线性混合仅支持对两个动画进行混合。新建的参数值范围为[0,1]。指定的骨骼将会按照这个参数的值对两个动画进行线性混合。                        |
|                       [ModelRemove](./1-ModAPI/接口/虚拟世界/模型.md#modelremove)                       |客户端|                                                                 销毁虚拟世界中的模型                                                                  |
|                       [ModelRotate](./1-ModAPI/接口/虚拟世界/模型.md#modelrotate)                       |客户端|                                                                 模型绕某个轴旋转多少度                                                                 |
|                     [ModelRotateTo](./1-ModAPI/接口/虚拟世界/模型.md#modelrotateto)                     |客户端|                                                                  设置模型旋转运动                                                                   |
|        [ModelSetAnim1DControlParam](./1-ModAPI/接口/虚拟世界/模型.md#modelsetanim1dcontrolparam)        |客户端|                                                        新建动画的1D控制参数后，使用该接口对相应的参数进行控制。                                                        |
|           [ModelSetAnimAllBoneMask](./1-ModAPI/接口/虚拟世界/模型.md#modelsetanimallbonemask)           |客户端|设置是否屏蔽动画中所有骨骼的动画，若开启骨骼屏蔽后，该骨骼将不再播放该动画中的动作。该接口会对该动画中所有骨骼生效，可通过参数ignoreBoneList来指定不受影响的骨骼名称。通过屏蔽指定骨骼的动画可实现同一个骨骼模型同时在不同骨骼上播放不同的动作动画，从而实现快捷的动作融合。|
|              [ModelSetAnimBoneMask](./1-ModAPI/接口/虚拟世界/模型.md#modelsetanimbonemask)              |客户端|                       设置是否屏蔽动画中指定的骨骼的动画，若开启骨骼屏蔽后，该骨骼将不再播放该动画中的动作。通过屏蔽指定骨骼的动画可实现同一个骨骼模型同时在不同骨骼上播放不同的动作动画，从而实现快捷的动作融合。                        |
|                 [ModelSetAnimLayer](./1-ModAPI/接口/虚拟世界/模型.md#modelsetanimlayer)                 |客户端|                                      设置骨骼动画的层级，动画层级越大，则优先度越高，骨骼模型的骨骼优先播放优先度最高的动画，相同层级的动画则优先播放率先播放的动画。                                       |
|               [ModelSetBoxCollider](./1-ModAPI/接口/虚拟世界/模型.md#modelsetboxcollider)               |客户端|                                                                  设置模型的包围盒                                                                   |
|                       [ModelSetPos](./1-ModAPI/接口/虚拟世界/模型.md#modelsetpos)                       |客户端|                                                                   设置模型坐标                                                                    |
|                       [ModelSetRot](./1-ModAPI/接口/虚拟世界/模型.md#modelsetrot)                       |客户端|                                                                  设置模型的旋转角度                                                                  |
|                     [ModelSetScale](./1-ModAPI/接口/虚拟世界/模型.md#modelsetscale)                     |客户端|                                                                  设置模型的缩放值                                                                   |
|                   [ModelSetVisible](./1-ModAPI/接口/虚拟世界/模型.md#modelsetvisible)                   |客户端|                                                                   设置模型可见性                                                                   |
|                  [ModelStopActions](./1-ModAPI/接口/虚拟世界/模型.md#modelstopactions)                  |客户端|                                                                停止模型的移动和旋转运动                                                                 |
|                [ModelStopAnimation](./1-ModAPI/接口/虚拟世界/模型.md#modelstopanimation)                |客户端|                                                                停止播放指定的模型动画。                                                                 |
|[ModelUpdateAnimationMolangVariable](./1-ModAPI/接口/虚拟世界/模型.md#modelupdateanimationmolangvariable)|客户端|                                                           更新微软原版模型表达式变量，可控制动作的改变                                                            |

####  其它对象 ####

|                                              接口                                               |   |                             描述                             |
|-----------------------------------------------------------------------------------------------|---|------------------------------------------------------------|
|         [BindModel](./1-ModAPI/接口/虚拟世界/其它对象.md#bindmodel)         |客户端|               把对象绑定到模型上, 支持绑定序列帧，粒子，文本和其它模型                |
|[MoveToVirtualWorld](./1-ModAPI/接口/虚拟世界/其它对象.md#movetovirtualworld)|客户端|把对象从主世界移到虚拟世界, 非绑定的序列帧，文本，粒子需要调用该方法后才会出现在虚拟世界中，绑定的可以省略调用该方法。|

####  渐晕 ####

|                                                接口                                                |   |                             描述                             |
|--------------------------------------------------------------------------------------------------|---|------------------------------------------------------------|
| [CheckVignetteEnabled](./1-ModAPI/接口/后处理/渐晕.md#checkvignetteenabled) |客户端|                  检测是否开启了屏幕渐晕（Vignette）效果。                  |
|    [SetEnableVignette](./1-ModAPI/接口/后处理/渐晕.md#setenablevignette)    |客户端|设置是否开启屏幕渐晕（Vignette）效果，开启后玩家屏幕周围将出现渐晕，可通过Vignette其他接口设置效果参数。|
|    [SetVignetteCenter](./1-ModAPI/接口/后处理/渐晕.md#setvignettecenter)    |客户端|             设置渐晕（Vignette）的渐晕中心位置，可改变屏幕渐晕的位置。              |
|       [SetVignetteRGB](./1-ModAPI/接口/后处理/渐晕.md#setvignettergb)       |客户端|              设置渐晕（Vignette）的渐晕颜色，可改变屏幕渐晕的颜色。               |
|    [SetVignetteRadius](./1-ModAPI/接口/后处理/渐晕.md#setvignetteradius)    |客户端|          设置渐晕（Vignette）的渐晕半径，半径越大，渐晕越小，玩家的视野范围越大。          |
|[SetVignetteSmoothness](./1-ModAPI/接口/后处理/渐晕.md#setvignettesmoothness)|客户端|       设置渐晕（Vignette）的渐晕模糊系数，模糊系数越大，则渐晕边缘越模糊，模糊的范围也越大       |

####  模糊 ####

|                                                   接口                                                   |   |                     描述                     |
|--------------------------------------------------------------------------------------------------------|---|--------------------------------------------|
|[CheckGaussianBlurEnabled](./1-ModAPI/接口/后处理/模糊.md#checkgaussianblurenabled)|客户端|               检测是否开启了高斯模糊效果。               |
|   [SetEnableGaussianBlur](./1-ModAPI/接口/后处理/模糊.md#setenablegaussianblur)   |客户端|设置是否开启高斯模糊效果，开启后玩家屏幕周围被模糊，可通过高斯模糊其他接口设置效果参数。|
|   [SetGaussianBlurRadius](./1-ModAPI/接口/后处理/模糊.md#setgaussianblurradius)   |客户端|    设置高斯模糊效果的模糊半径，半径越大，模糊程度越大，反之则模糊程度越小。    |

####  色彩 ####

|                                                       接口                                                       |   |                        描述                        |
|----------------------------------------------------------------------------------------------------------------|---|--------------------------------------------------|
| [CheckColorAdjustmentEnabled](./1-ModAPI/接口/后处理/色彩.md#checkcoloradjustmentenabled) |客户端|                  检测是否开启了色彩校正效果。                  |
|[SetColorAdjustmentBrightness](./1-ModAPI/接口/后处理/色彩.md#setcoloradjustmentbrightness)|客户端|            调整屏幕色彩亮度，亮度值越大，屏幕越亮，反之则越暗。            |
|  [SetColorAdjustmentContrast](./1-ModAPI/接口/后处理/色彩.md#setcoloradjustmentcontrast)  |客户端|      调整屏幕色彩对比度，屏幕对比度值越大，色彩差异则越明显，反之则色彩差异越小。      |
|[SetColorAdjustmentSaturation](./1-ModAPI/接口/后处理/色彩.md#setcoloradjustmentsaturation)|客户端|        调整屏幕色彩饱和度，屏幕饱和度值越大，色彩则越明显，反之则越灰暗。         |
|      [SetColorAdjustmentTint](./1-ModAPI/接口/后处理/色彩.md#setcoloradjustmenttint)      |客户端|调整屏幕色彩的色调，根据输入的色调和强度来调整屏幕色彩，当强度越大时，屏幕整体颜色越偏向输入的色调。|
|    [SetEnableColorAdjustment](./1-ModAPI/接口/后处理/色彩.md#setenablecoloradjustment)    |客户端|  设置是否开启色彩校正效果，开启后可进行屏幕色彩调整，可通过色彩校正效果其他接口设置效果参数。  |

####  镜头效果 ####

|                                                         接口                                                         |   |                                                                             描述                                                                             |
|--------------------------------------------------------------------------------------------------------------------|---|------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     [CheckDepthOfFieldEnabled](./1-ModAPI/接口/后处理/镜头效果.md#checkdepthoffieldenabled)     |客户端|                                                                        检测是否开启了景深效果。                                                                        |
|        [CheckLensStainEnabled](./1-ModAPI/接口/后处理/镜头效果.md#checklensstainenabled)        |客户端|                                                                       检测是否开启了镜头污迹效果。                                                                       |
|        [ResetLensStainTexture](./1-ModAPI/接口/后处理/镜头效果.md#resetlensstaintexture)        |客户端|                                                                    重置污迹效果使用的贴图为系统默认贴图。                                                                     |
|    [SetDepthOfFieldBlurRadius](./1-ModAPI/接口/后处理/镜头效果.md#setdepthoffieldblurradius)    |客户端|                                                              调整景深效果模糊半径，模糊半径越大，模糊程度越大，反之则越小。                                                               |
|  [SetDepthOfFieldFarBlurScale](./1-ModAPI/接口/后处理/镜头效果.md#setdepthoffieldfarblurscale)  |客户端|                            调整景深效果远景模糊大小，远景模糊大小越大，远景的模糊程度越大，反之则越小。注意，远景模糊程度的调节依赖于焦点距离，如果焦点处于较近的距离，那么此时远景处于较清晰的状态，模糊程度大小调节不会很明显。                             |
| [SetDepthOfFieldFocusDistance](./1-ModAPI/接口/后处理/镜头效果.md#setdepthoffieldfocusdistance) |客户端|                                           调整景深效果焦点距离，距离越小，则远处模糊，近处清晰；距离越大，则远处清晰，近处模糊。该距离为实际距离，即以玩家相机为起点的世界坐标距离。                                            |
| [SetDepthOfFieldNearBlurScale](./1-ModAPI/接口/后处理/镜头效果.md#setdepthoffieldnearblurscale) |客户端|                            调整景深效果近景模糊大小，近景模糊大小越大，近景的模糊程度越大，反之则越小。注意，近景模糊程度的调节依赖于焦点距离，如果焦点处于较近的距离，那么此时近景处于较清晰的状态，模糊程度大小调节不会很明显。                             |
|[SetDepthOfFieldUseCenterFocus](./1-ModAPI/接口/后处理/镜头效果.md#setdepthoffieldusecenterfocus)|客户端|设置景深效果是否开启屏幕中心聚焦模式，开启后聚焦距离将被自动设置为屏幕中心所对应的物体所在的距离。在第一人称视角下，聚焦距离将被自动设置为屏幕准心所对应的物体与相机的距离，即自动聚焦准心所对应的物体。在第三人称视角下，由于屏幕中心总是对应着玩家，因此聚焦距离将被自动设置为玩家与相机的距离，即自动聚焦在玩家自己。|
|        [SetEnableDepthOfField](./1-ModAPI/接口/后处理/镜头效果.md#setenabledepthoffield)        |客户端|                                                   设置是否开启景深效果，开启后屏幕出现景深效果，根据焦点距离呈现远处模糊近处清晰或者近处模糊远处清晰的效果。                                                    |
|           [SetEnableLensStain](./1-ModAPI/接口/后处理/镜头效果.md#setenablelensstain)           |客户端|                                                         设置是否开启镜头污迹效果，开启后镜头出现污迹效果，可改变使用的污迹贴图及污迹颜色。                                                          |
|            [SetLensStainColor](./1-ModAPI/接口/后处理/镜头效果.md#setlensstaincolor)            |客户端|                                                      调整镜头污迹颜色，根据输入的颜色和强度来调整污迹色彩，当强度越大时，污迹颜色越偏向输入的颜色。                                                       |
|        [SetLensStainIntensity](./1-ModAPI/接口/后处理/镜头效果.md#setlensstainintensity)        |客户端|                                                                调整镜头污迹强度，强度越大，污迹越明显，反之则越透明。                                                                 |
|          [SetLensStainTexture](./1-ModAPI/接口/后处理/镜头效果.md#setlensstaintexture)          |客户端|                                             开启镜头污迹效果后，污迹效果使用的为系统默认贴图。该接口可改变镜头污迹所使用的贴图。注意贴图最好使用透明背景，否则屏幕将被贴图覆盖。                                             |

####  自定义 ####

|                                                    接口                                                     |   |                                                                                                                                                            描述                                                                                                                                                             |
|-----------------------------------------------------------------------------------------------------------|---|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|           [AddPostProcess](./1-ModAPI/接口/后处理/自定义.md#addpostprocess)           |客户端|                                                                                                                                添加后处理效果，与graphics\_settings/post\_process.json定义的process等效                                                                                                                                 |
|       [CheckEnabledByName](./1-ModAPI/接口/后处理/自定义.md#checkenabledbyname)       |客户端|                                                                                                                                                      查询是否开启了自定义后处理效果                                                                                                                                                      |
|             [GetParameter](./1-ModAPI/接口/后处理/自定义.md#getparameter)             |客户端|                                                                                                                                                      获取指定自定义后处理参数的值                                                                                                                                                       |
|      [GetPostProcessOrder](./1-ModAPI/接口/后处理/自定义.md#getpostprocessorder)      |客户端|                                                                                                                                                       获取后处理效果的渲染顺序                                                                                                                                                        |
|  [InsertPassToPostprocess](./1-ModAPI/接口/后处理/自定义.md#insertpasstopostprocess)  |客户端|往自定义后处理的多pass中的指定位置插入自定义pass。多pass指定的是graphics\_settings/post\_process.json中的"pass\_array"渲染pass数组。这个后处理会按照这个数组所定义的pass来逐个渲染，每个pass之间的像素输入输出相互连接，即pass数组中第一个pass所使用的fragment shader中的TEXTURE\_0为游戏原始输出到屏幕的像素信息。下一个pass所使用的fragment shader中的TEXTURE\_0为上一个Pass的fragment shader的输出。最后一个pass的fragment shader的输出即为输出到游戏屏幕的像素信息。|
| [PopBackPassInPostprocess](./1-ModAPI/接口/后处理/自定义.md#popbackpassinpostprocess) |客户端|  删除自定义后处理的多pass的最末尾的pass。多pass指定的是graphics\_settings/post\_process.json中的"pass\_array"渲染pass数组。这个后处理会按照这个数组所定义的pass来逐个渲染，每个pass之间的像素输入输出相互连接，即pass数组中第一个pass所使用的fragment shader中的TEXTURE\_0为游戏原始输出到屏幕的像素信息。下一个pass所使用的fragment shader中的TEXTURE\_0为上一个Pass的fragment shader的输出。最后一个pass的fragment shader的输出即为输出到游戏屏幕的像素信息。   |
|[PostPassResultToOtherPass](./1-ModAPI/接口/后处理/自定义.md#postpassresulttootherpass)|客户端|                                                                                                                                     将自定义pass的纹理结果传递到其他自定义pass的fragmentShader指定纹理单元槽位                                                                                                                                      |
|[PushBackPassToPostprocess](./1-ModAPI/接口/后处理/自定义.md#pushbackpasstopostprocess)|客户端| 往自定义后处理的多pass最末尾插入自定义pass。多pass指定的是graphics\_settings/post\_process.json中的"pass\_array"渲染pass数组。这个后处理会按照这个数组所定义的pass来逐个渲染，每个pass之间的像素输入输出相互连接，即pass数组中第一个pass所使用的fragment shader中的TEXTURE\_0为游戏原始输出到屏幕的像素信息。下一个pass所使用的fragment shader中的TEXTURE\_0为上一个Pass的fragment shader的输出。最后一个pass的fragment shader的输出即为输出到游戏屏幕的像素信息。  |
|  [RemovePassInPostprocess](./1-ModAPI/接口/后处理/自定义.md#removepassinpostprocess)  |客户端|  删除自定义后处理的多pass中指定位置的pass。多pass指定的是graphics\_settings/post\_process.json中的"pass\_array"渲染pass数组。这个后处理会按照这个数组所定义的pass来逐个渲染，每个pass之间的像素输入输出相互连接，即pass数组中第一个pass所使用的fragment shader中的TEXTURE\_0为游戏原始输出到屏幕的像素信息。下一个pass所使用的fragment shader中的TEXTURE\_0为上一个Pass的fragment shader的输出。最后一个pass的fragment shader的输出即为输出到游戏屏幕的像素信息。  |
|          [SetEnableByName](./1-ModAPI/接口/后处理/自定义.md#setenablebyname)          |客户端|                                                                                                                                                      设置是否开启自定义后处理效果                                                                                                                                                       |
|             [SetParameter](./1-ModAPI/接口/后处理/自定义.md#setparameter)             |客户端|                                                                                                                                                   设置自定义后处理shader的自定义参数值                                                                                                                                                   |

####  联机大厅 ####

|                                                    接口                                                    |   |         描述         |
|----------------------------------------------------------------------------------------------------------|---|--------------------|
|              [GetPlayerUid](./1-ModAPI/接口/联机大厅.md#getplayeruid)              |服务端|获取玩家的uid。只有在线玩家才可获取 |
|           [LobbyGetStorage](./1-ModAPI/接口/联机大厅.md#lobbygetstorage)           |服务端|  获取存储的数据。仅联机大厅可用   |
|     [LobbyGetStorageBySort](./1-ModAPI/接口/联机大厅.md#lobbygetstoragebysort)     |服务端| 排序获取存储的数据。仅联机大厅可用  |
|[LobbySetStorageAndUserItem](./1-ModAPI/接口/联机大厅.md#lobbysetstorageanduseritem)|服务端|设置订单已发货或者存数据。仅联机大厅可用|
|        [QueryLobbyUserItem](./1-ModAPI/接口/联机大厅.md#querylobbyuseritem)        |服务端| 查询还没发货的订单。仅联机大厅可用  |

####  成就 ####

|                                                   接口                                                   |   |     描述      |
|--------------------------------------------------------------------------------------------------------|---|-------------|
|[LobbyGetAchievementStorage](./1-ModAPI/接口/成就.md#lobbygetachievementstorage)|服务端|获取成就节点的存储的数据。|
|[LobbySetAchievementStorage](./1-ModAPI/接口/成就.md#lobbysetachievementstorage)|服务端| 添加成就节点的进度。  |

####  商城 ####

|                                             接口                                             |   |               描述                |
|--------------------------------------------------------------------------------------------|---|---------------------------------|
|     [CloseShopWindow](./1-ModAPI/接口/商城.md#closeshopwindow)     |客户端|            关闭网易商城窗口             |
|        [HideShopGate](./1-ModAPI/接口/商城.md#hideshopgate)        |客户端|            隐藏网易商城入口             |
|[OpenItemDetailWindow](./1-ModAPI/接口/商城.md#openitemdetailwindow)|客户端|           打开特定商品的详情界面           |
|      [OpenShopWindow](./1-ModAPI/接口/商城.md#openshopwindow)      |客户端|打开网易商城窗口。PC端无效（Apollo的PC端请使用商城插件）|
|        [ShowShopGate](./1-ModAPI/接口/商城.md#showshopgate)        |客户端|            显示网易商城入口             |

####  山头服务器 ####

|                                          接口                                           |   |     描述      |
|---------------------------------------------------------------------------------------|---|-------------|
|[GetHostPlayerUid](./1-ModAPI/接口/山头服务器.md#gethostplayeruid)|服务端|获取服务器拥有者的uid。|

####  渲染 ####

|                                       接口                                       |   |                   描述                    |
|--------------------------------------------------------------------------------|---|-----------------------------------------|
| [AddArrowShape](./1-ModAPI/接口/渲染.md#addarrowshape) |客户端|                 新建箭头形状                  |
|   [AddBoxShape](./1-ModAPI/接口/渲染.md#addboxshape)   |客户端|                 新建盒子形状                  |
|[AddCircleShape](./1-ModAPI/接口/渲染.md#addcircleshape)|客户端|                  新建圆形状                  |
|  [AddLineShape](./1-ModAPI/接口/渲染.md#addlineshape)  |客户端|                 新建线条形状                  |
|[AddSphereShape](./1-ModAPI/接口/渲染.md#addsphereshape)|客户端|                  新建球形状                  |
|  [AddTextShape](./1-ModAPI/接口/渲染.md#addtextshape)  |客户端|                 新建文本形状                  |
|   [GetBoxScale](./1-ModAPI/接口/渲染.md#getboxscale)   |客户端|              获取BoxShape的大小              |
|      [GetColor](./1-ModAPI/接口/渲染.md#getcolor)      |客户端|               获取Shape的颜色                |
|     [GetEndPos](./1-ModAPI/接口/渲染.md#getendpos)     |客户端|       获取LineShape或ArrowShape的结束位置       |
|     [GetLength](./1-ModAPI/接口/渲染.md#getlength)     |客户端|            获取ArrowShape的头部长度            |
|        [GetPos](./1-ModAPI/接口/渲染.md#getpos)        |客户端|               获取Shape的位置                |
|   [GetPriority](./1-ModAPI/接口/渲染.md#getpriority)   |客户端|               获取Shape的优先级               |
|     [GetRadius](./1-ModAPI/接口/渲染.md#getradius)     |客户端| 获取CircleShape或ArrowShape或SphereShape的半径 |
|   [GetSegments](./1-ModAPI/接口/渲染.md#getsegments)   |客户端|     获取CircleShape或ArrowShape头部的分段数      |
|       [GetText](./1-ModAPI/接口/渲染.md#gettext)       |客户端|             获取TextShape的文本              |
|       [GetType](./1-ModAPI/接口/渲染.md#gettype)       |客户端|               获取Shape的类型                |
|    [GetVisible](./1-ModAPI/接口/渲染.md#getvisible)    |客户端|               获取Shape是否可见               |
|        [Remove](./1-ModAPI/接口/渲染.md#remove)        |客户端|                 删除Shape                 |
|     [RemoveAll](./1-ModAPI/接口/渲染.md#removeall)     |客户端|               删除当前所有Shape               |
|   [SetBoxScale](./1-ModAPI/接口/渲染.md#setboxscale)   |客户端|              设置BoxShape的大小              |
|      [SetColor](./1-ModAPI/接口/渲染.md#setcolor)      |客户端|               设置Shape的颜色                |
|     [SetEndPos](./1-ModAPI/接口/渲染.md#setendpos)     |客户端|       设置LineShape或ArrowShape的结束位置       |
|     [SetLength](./1-ModAPI/接口/渲染.md#setlength)     |客户端|           设置组成ArrowShape头部的长度           |
|        [SetPos](./1-ModAPI/接口/渲染.md#setpos)        |客户端|               设置Shape的位置                |
|   [SetPriority](./1-ModAPI/接口/渲染.md#setpriority)   |客户端|设置Shape的渲染优先级, 同一像素点处优先渲染优先级高的Shape, 默认为0|
|     [SetRadius](./1-ModAPI/接口/渲染.md#setradius)     |客户端| 设置CircleShape或ArrowShape或SphereShape的半径 |
|   [SetSegments](./1-ModAPI/接口/渲染.md#setsegments)   |客户端|       设置组成ArrowShape头部的网格数量, 最小为3       |
|       [SetText](./1-ModAPI/接口/渲染.md#settext)       |客户端|            设置TextShape的文本内容             |
|    [SetVisible](./1-ModAPI/接口/渲染.md#setvisible)    |客户端|               设置Shape是否可见               |