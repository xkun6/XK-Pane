 RenderLayer
==========

class in mod.common.minecraftEnum

* 描述

  方块渲染时的材质类型

* 备注

  * 目前自定义方块只支持使用部分材质，具体见[ 自定义方块json组件 ](../../../mcguide/20-玩法开发/15-自定义游戏内容/2-自定义方块/1-JSON组件.html)由于联机大厅和apollo存在部分材质缺少定义，所以枚举值在联机大厅和apollo环境下，整体-2
    如：Blend = 5 变成 Blend = 3 ; Opaque = 6 变成 Opaque = 4，依此类推

```
class RenderLayer(object):
	DOUBLE_SIDED = 0 # 双面
	BLEND_WATER = 1 # 半透明水面
	ALPHATEST_MICRO_BLOCK = 2 # 全透明微缩方块
	RAY_TRACED_WATER = 3 # 原版光线追踪水面
	DEFERRED_WATER = 4 # 原版延迟渲染水面
	BLEND = 5 # 半透明
	BLEND_TO_OPAQUE = 6 # 半透明转不透明(远距离渲染为不透明)
	OPAQUE = 7 # 不透明
	LIGHT_SOURCE = 8 # 原版发光方块
	OPTIONAL_ALPHATEST = 9 # 全透明转不透明(远距离渲染为不透明)
	ALPHATEST = 10 # 全透明
	SEASONS_OPAQUE = 11 # 原版用于渲染不透明树叶
	SEASONS_OPTIONAL_ALPHATEST = 12 # 原版季节性全透明转不透明方块
	ALPHATEST_SINGLE_SIDE = 13 # 单面全透明
	ALPHATEST_SINGLE_SIDE_TO_OPAQUE = 14 # 单面全透明转不透明(远距离渲染为不透明)
	ENDPORTAL = 15 # 原版末地传送门
	BARRIER = 16 # 原版屏障
	LIGHT = 17 # 原版光源
	STRUCTURE_VOID = 18 # 原版结构空位

```